// ==========================================
// 文件：SmartPanel.java
// 长按后的各种莫兰迪弹窗 UI
// ==========================================
import android.app.*;
import android.content.*;
import android.view.*;
import android.widget.*;
import android.graphics.*;
import android.graphics.drawable.*;
import java.io.*;
import java.util.*;

GradientDrawable createAeroGlass(Context ctx, String bgColorHex, String strokeColorHex, int radiusDp) {
    GradientDrawable glass = new GradientDrawable();
    glass.setColor(Color.parseColor(bgColorHex));
    glass.setCornerRadius(dp(ctx, radiusDp));
    glass.setStroke(dp(ctx, 1), Color.parseColor(strokeColorHex));
    return glass;
}

StateListDrawable createPressableAeroGlass(Context ctx, String normalBg, String pressedBg, String strokeColor, int radiusDp) {
    StateListDrawable res = new StateListDrawable();
    res.addState(new int[]{android.R.attr.state_pressed}, createAeroGlass(ctx, pressedBg, strokeColor, radiusDp));
    res.addState(new int[]{}, createAeroGlass(ctx, normalBg, strokeColor, radiusDp));
    return res;
}

GradientDrawable createAuroraSpaceBg(Context ctx, int radiusDp) {
    int[] colors = new int[]{ Color.parseColor("#A18CD1"), Color.parseColor("#FBC2EB") };
    GradientDrawable auroraBg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
    auroraBg.setCornerRadius(dp(ctx, radiusDp));
    return auroraBg;
}

Dialog globalLoadingDialog = null;
TextView globalLoadingText = null; 

void showGlassLoading(Activity act, String text) {
    if (act == null || act.isFinishing()) return;
    act.runOnUiThread(new Runnable() {
        public void run() {
            try {
                if (globalLoadingDialog != null && globalLoadingDialog.isShowing()) {
                    if (globalLoadingText != null) globalLoadingText.setText(text);
                    return;
                }
                
                globalLoadingDialog = new Dialog(act);
                globalLoadingDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                globalLoadingDialog.setCancelable(false); 
                globalLoadingDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));

                LinearLayout root = new LinearLayout(act);
                root.setOrientation(LinearLayout.VERTICAL);
                root.setBackground(createAeroGlass(act, "#33FFFFFF", "#80FFFFFF", 20)); 
                root.setPadding(dp(act, 40), dp(act, 40), dp(act, 40), dp(act, 40));
                root.setGravity(Gravity.CENTER);

                ProgressBar pb = new ProgressBar(act);
                try { pb.getIndeterminateDrawable().setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN); } catch(Exception e){}
                root.addView(pb);

                globalLoadingText = new TextView(act);
                globalLoadingText.setText(text);
                globalLoadingText.setTextColor(Color.parseColor("#FFFFFF"));
                globalLoadingText.setTextSize(14f);
                globalLoadingText.getPaint().setFakeBoldText(true);
                globalLoadingText.setGravity(Gravity.CENTER);
                globalLoadingText.setPadding(0, dp(act, 20), 0, 0);
                root.addView(globalLoadingText);

                globalLoadingDialog.setContentView(root);
                globalLoadingDialog.show();
            } catch (Exception e) {}
        }
    });
}

void hideGlassLoading() {
    Activity act = getThreadActivity();
    if (act == null) return;
    act.runOnUiThread(new Runnable() {
        public void run() {
            try {
                if (globalLoadingDialog != null && globalLoadingDialog.isShowing()) {
                    globalLoadingDialog.dismiss();
                    globalLoadingDialog = null;
                    globalLoadingText = null;
                }
            } catch (Exception e) {}
        }
    });
}

TextView makePrimaryGlassBtn(Context ctx, String text) {
    TextView btn = new TextView(ctx);
    btn.setText(text);
    btn.setTextSize(16);
    btn.setTextColor(Color.parseColor("#A18CD1"));
    btn.getPaint().setFakeBoldText(true);
    btn.setGravity(Gravity.CENTER);
    btn.setBackground(createPressableAeroGlass(ctx, "#E6FFFFFF", "#CCCCCC", "#FFFFFF", 50));
    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(ctx, 50));
    lp.bottomMargin = dp(ctx, 15);
    btn.setLayoutParams(lp);
    return btn;
}

void buildSmartActionPanel(String title, String subTitle, View[] buttons, Object msgRecord) {
    Activity act = getThreadActivity();
    if (act == null || act.isFinishing()) return;

    act.runOnUiThread(new Runnable() {
        public void run() {
            try {
                Dialog d = new Dialog(act);
                d.requestWindowFeature(1);
                d.getWindow().setBackgroundDrawable(new ColorDrawable(0));

                FrameLayout outer = new FrameLayout(act);
                int m = dp(act, 24);
                outer.setPadding(m, m, m, m);

                LinearLayout bgLayout = new LinearLayout(act);
                bgLayout.setOrientation(LinearLayout.VERTICAL);
                bgLayout.setBackground(createAuroraSpaceBg(act, 24));
                bgLayout.setPadding(dp(act, 20), dp(act, 40), dp(act, 20), dp(act, 40));

                LinearLayout glassCard = new LinearLayout(act);
                glassCard.setOrientation(LinearLayout.VERTICAL);
                glassCard.setBackground(createAeroGlass(act, "#33FFFFFF", "#80FFFFFF", 20));
                glassCard.setPadding(dp(act, 24), dp(act, 30), dp(act, 24), dp(act, 30));

                TextView head = new TextView(act);
                head.setText(title + " "); 
                head.setTextSize(24);
                head.setTextColor(Color.parseColor("#FFFFFF"));
                head.getPaint().setFakeBoldText(true);
                head.setGravity(Gravity.CENTER);
                
                head.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        d.dismiss();
                        showMakeFacePanel(msgRecord);
                    }
                });
                glassCard.addView(head);

                TextView subHead = new TextView(act);
                subHead.setText(subTitle/* + "\n(点击上方标题展开恶搞画廊)"*/);
                subHead.setTextSize(12);
                subHead.setTextColor(Color.parseColor("#E6FFFFFF"));
                subHead.setGravity(Gravity.CENTER);
                subHead.setPadding(0, dp(act, 6), 0, dp(act, 30));
                glassCard.addView(subHead);

                ScrollView scroll = new ScrollView(act);
                scroll.setVerticalScrollBarEnabled(false);
                LinearLayout list = new LinearLayout(act);
                list.setOrientation(LinearLayout.VERTICAL);
                for (int i = 0; i < buttons.length; i++) {
                    View btn = buttons[i];
                    final View.OnClickListener originalListener = (View.OnClickListener) btn.getTag();
                    btn.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {
                            d.dismiss();
                            if (originalListener != null) originalListener.onClick(v);
                        }
                    });
                    list.addView(btn);
                }
                scroll.addView(list);
                
                LinearLayout.LayoutParams lpScroll = new LinearLayout.LayoutParams(-1, -2);
                lpScroll.weight = 1.0f;
                scroll.setLayoutParams(lpScroll);
                glassCard.addView(scroll);

                TextView btnCancel = new TextView(act);
                btnCancel.setText("取消");
                btnCancel.setTextSize(15);
                btnCancel.setTextColor(Color.parseColor("#FFFFFF"));
                btnCancel.setGravity(Gravity.CENTER);
                btnCancel.setBackground(createPressableAeroGlass(act, "#1A000000", "#33000000", "#4DFFFFFF", 50));
                LinearLayout.LayoutParams lpCancel = new LinearLayout.LayoutParams(-1, dp(act, 44));
                lpCancel.topMargin = dp(act, 10);
                btnCancel.setLayoutParams(lpCancel);
                btnCancel.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) { d.dismiss(); }
                });
                glassCard.addView(btnCancel);

                bgLayout.addView(glassCard);
                outer.addView(bgLayout);
                d.setContentView(outer);
                d.getWindow().setLayout((int)(act.getResources().getDisplayMetrics().widthPixels * 0.90), -2);
                d.show();
            } catch (Exception e) {}
        }
    });
}

void showTextActionPanel(Object msgRecord) {
    Activity act = getThreadActivity();
    if (act == null) return;
    
    TextView btn1 = makePrimaryGlassBtn(act, "生成极光卡片");
    btn1.setTag(new View.OnClickListener() { public void onClick(View v) { processTextToGlassCard(msgRecord); } });
    
    buildSmartActionPanel("文本处理", "已提取文本内容，请选择操作", new View[]{btn1}, msgRecord);
}

void showImageActionPanel(Object msgRecord) {
    Activity act = getThreadActivity();
    if (act == null) return;
    
    TextView btn1 = makePrimaryGlassBtn(act, "保存表情包");
    btn1.setTag(new View.OnClickListener() { public void onClick(View v) { saveEmoticon(msgRecord); } });
    
    TextView btn2 = makePrimaryGlassBtn(act, "生成极光卡片");
    btn2.setTag(new View.OnClickListener() { public void onClick(View v) { processImageToGlassCard(msgRecord); } });
    
    buildSmartActionPanel("图片处理", "检测到图像，请选择进阶操作", new View[]{btn1, btn2}, msgRecord);
}

void showVoiceActionPanel(Object msgRecord) {
    Activity act = getThreadActivity();
    if (act == null) return;
    
    TextView btn1 = makePrimaryGlassBtn(act, "保存语音");
    btn1.setTag(new View.OnClickListener() { public void onClick(View v) { saveVoice(msgRecord); } });
    
    TextView btn2 = makePrimaryGlassBtn(act, "生成极光视频");
    btn2.setTag(new View.OnClickListener() { public void onClick(View v) { voiceToAuroraVideo(msgRecord); } });
    
    buildSmartActionPanel("语音处理", "已截获音频流，准备执行进阶操作", new View[]{btn1, btn2}, msgRecord);
}


void showVideoActionPanel(Object msgRecord) {
    Activity act = getThreadActivity();
    if (act == null) return;
    
    // 【修改点】名称改为保存视频，并跳转到保存弹窗
    TextView btn1 = makePrimaryGlassBtn(act, "保存视频");
    btn1.setTag(new View.OnClickListener() { public void onClick(View v) { showSaveVideoDialog(msgRecord); } });
    
    // 原有的：生成极光视频
    TextView btn2 = makePrimaryGlassBtn(act, "生成极光视频");
    btn2.setTag(new View.OnClickListener() { public void onClick(View v) { videoToAuroraVideo(msgRecord); } });
    
    buildSmartActionPanel("视频处理", "请选择操作", new View[]{btn1, btn2}, msgRecord);
}

// ========== 恢复被误删的图文混合长按菜单 ==========
void showImageTextActionPanel(Object msgRecord) {
    Activity act = getThreadActivity();
    if (act == null) return;
    
    TextView btn1 = makePrimaryGlassBtn(act, "生成极光卡片");
    btn1.setTag(new View.OnClickListener() { 
        public void onClick(View v) { processImageTextToGlassCard(msgRecord); } 
    });
    
    buildSmartActionPanel("图文提取", "检测到图文混合排版，请选择操作", new View[]{btn1}, msgRecord);
}



// ========== 替换 2：修改重命名弹窗为“保存视频”专属弹窗 ==========
void showSaveVideoDialog(Object msgRecord) {
    Activity act = getThreadActivity();
    if (act == null || act.isFinishing()) return;

    act.runOnUiThread(new Runnable() {
        public void run() {
            try {
                Dialog d = new Dialog(act);
                d.requestWindowFeature(1);
                d.getWindow().setBackgroundDrawable(new ColorDrawable(0));

                FrameLayout outer = new FrameLayout(act);
                outer.setPadding(dp(act, 24), dp(act, 24), dp(act, 24), dp(act, 24));

                LinearLayout bgLayout = new LinearLayout(act);
                bgLayout.setOrientation(LinearLayout.VERTICAL);
                bgLayout.setBackground(createAuroraSpaceBg(act, 24));
                bgLayout.setPadding(dp(act, 20), dp(act, 35), dp(act, 20), dp(act, 35));

                LinearLayout glassCard = new LinearLayout(act);
                glassCard.setOrientation(LinearLayout.VERTICAL);
                glassCard.setBackground(createAeroGlass(act, "#33FFFFFF", "#80FFFFFF", 20));
                glassCard.setPadding(dp(act, 24), dp(act, 25), dp(act, 24), dp(act, 25));

                TextView head = new TextView(act);
                head.setText("保存视频"); // 修改标题
                head.setTextSize(20);
                head.setTextColor(Color.parseColor("#FFFFFF"));
                head.getPaint().setFakeBoldText(true);
                head.setGravity(Gravity.CENTER);
                glassCard.addView(head);

                TextView subHead = new TextView(act);
                subHead.setText("为保存的视频重命名 (将存入 yy 目录)"); // 修改副标题
                subHead.setTextSize(12);
                subHead.setTextColor(Color.parseColor("#E6FFFFFF"));
                subHead.setGravity(Gravity.CENTER);
                subHead.setPadding(0, dp(act, 4), 0, dp(act, 20));
                glassCard.addView(subHead);

                EditText etInput = new EditText(act);
                etInput.setHint("输入名称");
                etInput.setTextSize(14);
                etInput.setTextColor(Color.parseColor("#FFFFFF"));
                etInput.setHintTextColor(Color.parseColor("#99FFFFFF"));
                etInput.setBackground(createAeroGlass(act, "#1A000000", "#4DFFFFFF", 12));
                etInput.setPadding(dp(act, 16), dp(act, 16), dp(act, 16), dp(act, 16));
                etInput.setSingleLine(true);
                glassCard.addView(etInput);

                View space = new View(act);
                space.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(act, 25)));
                glassCard.addView(space);

                LinearLayout btnRow = new LinearLayout(act);
                btnRow.setOrientation(LinearLayout.HORIZONTAL);

                TextView btnCancel = new TextView(act);
                btnCancel.setText("取消");
                btnCancel.setTextSize(15);
                btnCancel.setTextColor(Color.parseColor("#FFFFFF"));
                btnCancel.setGravity(Gravity.CENTER);
                btnCancel.setBackground(createPressableAeroGlass(act, "#1A000000", "#33000000", "#4DFFFFFF", 50));
                LinearLayout.LayoutParams lpCancel = new LinearLayout.LayoutParams(0, dp(act, 44), 1.0f);
                lpCancel.rightMargin = dp(act, 10);
                btnCancel.setLayoutParams(lpCancel);
                btnCancel.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { d.dismiss(); } });
                btnRow.addView(btnCancel);

                TextView btnSave = new TextView(act);
                btnSave.setText("开始保存"); // 修改按钮文字
                btnSave.setTextSize(15);
                btnSave.setTextColor(Color.parseColor("#A18CD1"));
                btnSave.getPaint().setFakeBoldText(true);
                btnSave.setGravity(Gravity.CENTER);
                btnSave.setBackground(createPressableAeroGlass(act, "#E6FFFFFF", "#CCCCCC", "#FFFFFF", 50));
                LinearLayout.LayoutParams lpSave = new LinearLayout.LayoutParams(0, dp(act, 44), 1.0f);
                btnSave.setLayoutParams(lpSave);
                btnSave.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        String name = etInput.getText().toString().trim();
                        if (name.equals("")) { Toast("请输入名称"); return; }
                        d.dismiss();
                        // 【修改点】调用全新的保存方法
                        saveVideoToYyFolder(msgRecord, name);
                    }
                });
                btnRow.addView(btnSave);

                glassCard.addView(btnRow);
                bgLayout.addView(glassCard);
                outer.addView(bgLayout);
                d.setContentView(outer);
                d.getWindow().setLayout((int)(act.getResources().getDisplayMetrics().widthPixels * 0.90), -2);
                d.show();
            } catch (Exception e) {}
        }
    });
}

// ========== 替换 3：核心保存逻辑（多线程复制防卡死） ==========
void saveVideoToYyFolder(Object msgRecord, String name) {
    new Thread(new Runnable() {
        public void run() {
            try {
                // 调用引擎内置的获取视频路径的方法
                String videoPath = getVideoFilePathFromMsg(msgRecord); 
                
                if (videoPath == null || videoPath.equals("")) {
                    Activity act = getThreadActivity();
                    if(act != null) act.runOnUiThread(new Runnable() { public void run() { Toast("获取视频路径失败，该视频可能未下载完"); }});
                    return;
                }

                // 确保脚本目录下的 yy 文件夹存在
                String yyDir = getScriptPath() + "/yy";
                File dirFile = new File(yyDir);
                if (!dirFile.exists()) {
                    dirFile.mkdirs();
                }

                // 自动补全 .mp4 后缀
                if (!name.toLowerCase().endsWith(".mp4")) {
                    name += ".mp4";
                }

                String targetPath = yyDir + "/" + name;
                
                // 使用 FFmpeg.java 里内置的全局 copyFile 方法极速复制
                copyFile(videoPath, targetPath);

                Activity act = getThreadActivity();
                if(act != null) {
                    act.runOnUiThread(new Runnable() {
                        public void run() {
                            if (new File(targetPath).exists()) {
                                Toast("✅ 视频已成功保存至: yy/" + name);
                            } else {
                                Toast("❌ 视频保存失败，请检查存储权限");
                            }
                        }
                    });
                }
            } catch (Exception e) {
                final String err = e.toString();
                Activity act = getThreadActivity();
                if(act != null) act.runOnUiThread(new Runnable() { public void run() { Toast("保存视频异常: " + err); }});
            }
        }
    }).start();
}







void showMakeFacePanel(Object msgRecord) {
    Activity act = getThreadActivity();
    if (act == null || act.isFinishing()) return;

    String[] catNames = getMakeFaceCategories();
    Map catData = getMakeFaceData();

    act.runOnUiThread(new Runnable() {
        public void run() {
            try {
                Dialog d = new Dialog(act);
                d.requestWindowFeature(1);
                d.getWindow().setBackgroundDrawable(new ColorDrawable(0));

                FrameLayout outer = new FrameLayout(act);
                outer.setPadding(dp(act, 20), dp(act, 24), dp(act, 20), dp(act, 24));

                LinearLayout bgLayout = new LinearLayout(act);
                bgLayout.setOrientation(LinearLayout.VERTICAL);
                bgLayout.setBackground(createAuroraSpaceBg(act, 24));
                bgLayout.setPadding(dp(act, 15), dp(act, 20), dp(act, 15), dp(act, 20));

                LinearLayout glassCard = new LinearLayout(act);
                glassCard.setOrientation(LinearLayout.VERTICAL);
                glassCard.setBackground(createAeroGlass(act, "#33FFFFFF", "#80FFFFFF", 20));
                glassCard.setPadding(dp(act, 15), dp(act, 15), dp(act, 15), dp(act, 15));

                TextView head = new TextView(act);
                head.setText("恶搞画廊");
                head.setTextSize(22);
                head.setTextColor(Color.WHITE);
                head.getPaint().setFakeBoldText(true);
                head.setGravity(Gravity.CENTER);
                glassCard.addView(head);

                TextView subHead = new TextView(act);
                subHead.setText("将生成以对方为主角的盲盒动图卡片");
                subHead.setTextSize(12);
                subHead.setTextColor(Color.parseColor("#E6FFFFFF"));
                subHead.setGravity(Gravity.CENTER);
                subHead.setPadding(0, dp(act, 4), 0, dp(act, 15));
                glassCard.addView(subHead);

                HorizontalScrollView tabScroll = new HorizontalScrollView(act);
                tabScroll.setHorizontalScrollBarEnabled(false);
                LinearLayout tabContainer = new LinearLayout(act);
                tabContainer.setOrientation(LinearLayout.HORIZONTAL);
                tabScroll.addView(tabContainer);
                
                LinearLayout.LayoutParams lpTabScroll = new LinearLayout.LayoutParams(-1, -2);
                lpTabScroll.bottomMargin = dp(act, 15);
                glassCard.addView(tabScroll, lpTabScroll);

                ScrollView contentScroll = new ScrollView(act);
                contentScroll.setVerticalScrollBarEnabled(false);
                LinearLayout gridContainer = new LinearLayout(act);
                gridContainer.setOrientation(LinearLayout.VERTICAL);
                contentScroll.addView(gridContainer);
                
                LinearLayout.LayoutParams lpContent = new LinearLayout.LayoutParams(-1, -2);
                glassCard.addView(contentScroll, lpContent);

                String[] currentCategory = { catNames[0] };

                Runnable refreshGrid = new Runnable() {
                    public void run() {
                        gridContainer.removeAllViews();
                        String[][] items = (String[][]) catData.get(currentCategory[0]);
                        
                        int cols = 3;
                        LinearLayout row = null;
                        
                        for (int i = 0; i < items.length; i++) {
                            if (i % cols == 0) {
                                row = new LinearLayout(act);
                                row.setOrientation(LinearLayout.HORIZONTAL);
                                LinearLayout.LayoutParams lpRow = new LinearLayout.LayoutParams(-1, -2);
                                lpRow.bottomMargin = dp(act, 10);
                                row.setLayoutParams(lpRow);
                                gridContainer.addView(row);
                            }
                            
                            String itemName = items[i][0];
                            String itemId = items[i][1];

                            TextView btn = new TextView(act);
                            btn.setText(itemName);
                            btn.setTextSize(13);
                            btn.setTextColor(Color.parseColor("#111111"));
                            btn.setGravity(Gravity.CENTER);
                            btn.setSingleLine(true);
                            btn.setBackground(createPressableAeroGlass(act, "#E6FFFFFF", "#CCCCCC", "#FFFFFF", 12));
                            btn.setPadding(0, dp(act, 10), 0, dp(act, 10));
                            
                            LinearLayout.LayoutParams lpBtn = new LinearLayout.LayoutParams(0, -2, 1.0f);
                            if (i % cols != cols - 1) lpBtn.rightMargin = dp(act, 10); 
                            btn.setLayoutParams(lpBtn);
                            
                            btn.setOnClickListener(new View.OnClickListener() {
                                public void onClick(View v) {
                                    d.dismiss();
                                    processMakeFace(msgRecord, itemId, itemName);
                                }
                            });
                            
                            row.addView(btn);
                        }
                        
                        int remainder = items.length % cols;
                        if (remainder != 0 && row != null) {
                            for (int k = 0; k < cols - remainder; k++) {
                                View empty = new View(act);
                                LinearLayout.LayoutParams lpEmpty = new LinearLayout.LayoutParams(0, -2, 1.0f);
                                if (k != (cols - remainder - 1)) lpEmpty.rightMargin = dp(act, 10);
                                empty.setLayoutParams(lpEmpty);
                                row.addView(empty);
                            }
                        }
                    }
                };

                Runnable refreshTabs = new Runnable() {
                    public void run() {
                        tabContainer.removeAllViews();
                        for (int i = 0; i < catNames.length; i++) {
                            String catName = catNames[i];
                            boolean isSelected = currentCategory[0].equals(catName);

                            TextView tab = new TextView(act);
                            tab.setText(catName);
                            tab.setTextSize(13);
                            tab.setPadding(dp(act, 12), dp(act, 6), dp(act, 12), dp(act, 6));
                            tab.setGravity(Gravity.CENTER);
                            
                            LinearLayout.LayoutParams lpTab = new LinearLayout.LayoutParams(-2, -2);
                            lpTab.rightMargin = dp(act, 8);
                            tab.setLayoutParams(lpTab);

                            if (isSelected) {
                                tab.setTextColor(Color.WHITE);
                                tab.setTypeface(Typeface.DEFAULT_BOLD);
                                tab.setBackground(createAeroGlass(act, "#66000000", "#99FFFFFF", 50));
                            } else {
                                tab.setTextColor(Color.parseColor("#99FFFFFF"));
                                tab.setTypeface(Typeface.DEFAULT);
                                tab.setBackground(createAeroGlass(act, "#1A000000", "#33FFFFFF", 50));
                            }

                            tab.setOnClickListener(new View.OnClickListener() {
                                public void onClick(View v) {
                                    currentCategory[0] = catName;
                                    refreshTabs.run();
                                    refreshGrid.run();
                                }
                            });
                            tabContainer.addView(tab);
                        }
                    }
                };

                refreshTabs.run();
                refreshGrid.run();

                TextView btnCancel = new TextView(act);
                btnCancel.setText("关闭画廊");
                btnCancel.setTextSize(14);
                btnCancel.setTextColor(Color.WHITE);
                btnCancel.setGravity(Gravity.CENTER);
                btnCancel.setBackground(createPressableAeroGlass(act, "#1A000000", "#33000000", "#4DFFFFFF", 50));
                LinearLayout.LayoutParams lpCancel = new LinearLayout.LayoutParams(-1, dp(act, 44));
                lpCancel.topMargin = dp(act, 15);
                btnCancel.setLayoutParams(lpCancel);
                btnCancel.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { d.dismiss(); } });
                glassCard.addView(btnCancel);

                bgLayout.addView(glassCard);
                outer.addView(bgLayout);
                d.setContentView(outer);
                
                d.getWindow().setLayout((int)(act.getResources().getDisplayMetrics().widthPixels * 0.90), -2);
                d.show();
            } catch (Exception e) {}
        }
    });
}


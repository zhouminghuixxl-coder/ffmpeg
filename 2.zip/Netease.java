// ==========================================
// 文件：Netease.java
// 极光音乐引擎：网易云解析、VIP直链、语音/卡片满血发送
// 修改：播放按钮样式与播放库统一
// ==========================================
import org.json.JSONObject;
import org.json.JSONArray;
import java.net.URLEncoder;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.SeekBar;
import android.app.Activity;
import android.app.Dialog;
import android.graphics.drawable.ColorDrawable;
import android.content.DialogInterface;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ByteArrayOutputStream;
import java.net.URL;
import java.net.HttpURLConnection;
import com.tencent.common.app.BaseApplicationImpl;
import com.tencent.qphone.base.remote.ToServiceMsg;
import android.os.SystemClock;
import mqq.manager.TicketManager;
import mqq.app.AppRuntime;

String getRealMusicUrl(String songId) {
    String musicUrl = null;
    try {
        if (GLOBAL_COOKIE == null) GLOBAL_COOKIE = "";
        
        // 【核心修复】优先使用 Linux API 获取真实链接（可获取 VIP 歌曲）
        String linuxUrl = "https://music.163.com/api/song/enhance/player/url";
        String body = "ids=[" + songId + "]&br=320000"; 
        String resp = httpPost(linuxUrl, body, GLOBAL_COOKIE);
        JSONObject json = new JSONObject(resp);
        
        if (json.has("data")) {
            JSONArray data = json.getJSONArray("data");
            if (data.length() > 0) {
                JSONObject item = data.getJSONObject(0);
                int code = item.optInt("code");
                String url = item.optString("url");
                
                // Linux API 返回的 code=200 表示有版权且可播放
                if (code == 200 && url != null && url.length() > 10) {
                    musicUrl = url;
                    android.util.Log.i("Music", "Linux API 获取成功：" + musicUrl);
                }
            }
        }
        
        // 如果 Linux API 失败，尝试 weapi 接口
        if (musicUrl == null || musicUrl.length() < 10) {
            try {
                String weapiUrl = "https://music.163.com/weapi/song/enhance/player/url";
                JSONObject params = new JSONObject();
                params.put("ids", new JSONArray("[" + songId + "]"));
                params.put("br", 320000);
                
                String[] enc = weapiEncrypt(params.toString());
                String weapiBody = "params=" + URLEncoder.encode(enc[0], "UTF-8") + "&encSecKey=" + URLEncoder.encode(enc[1], "UTF-8");
                String weapiResp = httpPost(weapiUrl, weapiBody, GLOBAL_COOKIE);
                JSONObject weapiJson = new JSONObject(weapiResp);
                
                if (weapiJson.has("data")) {
                    JSONArray weapiData = weapiJson.getJSONArray("data");
                    if (weapiData.length() > 0) {
                        JSONObject weapiItem = weapiData.getJSONObject(0);
                        String weapiUrlResult = weapiItem.optString("url");
                        if (weapiUrlResult != null && weapiUrlResult.length() > 10) {
                            musicUrl = weapiUrlResult;
                            android.util.Log.i("Music", "Weapi 获取成功：" + musicUrl);
                        }
                    }
                }
            } catch (Exception e) {
                android.util.Log.e("Music", "Weapi 失败：" + e.getMessage());
            }
        }
        
        // 最后才使用外网播放（试听）
        if (musicUrl == null || musicUrl.length() < 10) {
            musicUrl = "https://music.163.com/song/media/outer/url?id=" + songId + ".mp3";
            android.util.Log.w("Music", "使用试听链接：" + musicUrl);
        }
        
        // 强制转为 HTTPS
        if (musicUrl.startsWith("http://")) {
            musicUrl = musicUrl.replace("http://", "https://");
        }
        
        return musicUrl;
    } catch (Exception e) {
        android.util.Log.e("Music", "获取链接异常：" + e.getMessage());
        return "https://music.163.com/song/media/outer/url?id=" + songId + ".mp3";
    }
}

boolean performQQLogin() {
    try {
        AppRuntime app = (AppRuntime) BaseApplicationImpl.getApplication().getRuntime();
        String currentUin = app.getAccount();
        TicketManager tm = (TicketManager) app.getManager(2);
        
        String clientKey = tm.getStweb(currentUin);
        if (clientKey == null) clientKey = tm.getSkey(currentUin);
        if (clientKey == null) return false;

        String authorizeUrl = "https://music.163.com/api/sns/authorize?snsType=5&clientType=web2&callbackType=Login&forcelogin=true";
        URL url = new URL(authorizeUrl);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setInstanceFollowRedirects(false);
        conn.setRequestProperty("User-Agent", "Mozilla/5.0");
        conn.connect();
        String redirectUrl = conn.getHeaderField("Location");
        if (redirectUrl == null) redirectUrl = authorizeUrl;
        
        int idx = redirectUrl.indexOf("https://music.163.com/");
        String re = (idx != -1) ? redirectUrl.substring(idx) : redirectUrl;
        
        String ptUrl = "https://ssl.ptlogin2.qq.com/jump?u1=https%3A%2F%2Fconnect.qq.com&pt_report=1&daid=383&style=35&pt_3rd_aid=100495085&pt_openlogin_data=appid%3D716027609%26daid%3D383%26pt_skey_valid%3D0%26style%3D35%26s_url%3Dhttps%253A%252F%252Fconnect.qq.com%26refer_cgi%3Dauthorize%26which%3D%26sdkp%3Dpcweb%26sdkv%3Dv1.0%26loginty%3D3%26client_id%3D100495085%26response_type%3Dcode%26redirect_uri%3D" + URLEncoder.encode(re, "UTF-8") + "&keyindex=19y&clientuin=" + currentUin + "&clientkey=" + clientKey;

        String u = httpGet(ptUrl);
        int i = u.indexOf("var _data={");
        int i2 = u.lastIndexOf("}");
        
        if (i != -1 && i2 != -1) {
            String jsonStr = u.substring(i + 10, i2 + 1);
            JSONObject json = new JSONObject(jsonStr);
            if (json.has("token")) {
                GLOBAL_COOKIE = "MUSIC_U=" + json.getString("token") + "; os=pc; appver=2.9.7; channel=netease;";
                try {
                    File f = new File(getScriptPath() + "/" + COOKIE_FILE);
                    FileOutputStream fos = new FileOutputStream(f);
                    fos.write(GLOBAL_COOKIE.getBytes());
                    fos.close();
                } catch(Exception e){}
                CURRENT_UID = null; 
                ensureUid(); 
                return true;
            }
        }
    } catch (Exception e) {}
    return false;
}

void ensureUid() {
    try {
        String resp = httpPost("https://music.163.com/api/nuser/account/get", "", GLOBAL_COOKIE);
        JSONObject json = new JSONObject(resp);
        if (json.has("account") && !json.isNull("account")) {
             CURRENT_UID = String.valueOf(json.getJSONObject("account").optInt("id"));
        } else if (json.has("profile") && !json.isNull("profile")) { 
             CURRENT_UID = String.valueOf(json.getJSONObject("profile").optInt("userId"));
        }
    } catch(Exception e) {}
}

ArrayList getUserPlaylists(String uid) {
    ArrayList list = new ArrayList();
    try {
        String resp = httpGetWithCookie("https://music.163.com/api/user/playlist?offset=0&limit=50&uid=" + uid, GLOBAL_COOKIE);
        JSONObject json = new JSONObject(resp);
        if (json.has("playlist")) {
            JSONArray playlist = json.getJSONArray("playlist");
            for (int i=0; i<playlist.length(); i++) {
                JSONObject p = playlist.getJSONObject(i);
                HashMap map = new HashMap();
                map.put("id", String.valueOf(p.optLong("id")));
                map.put("name", p.optString("name"));
                map.put("count", String.valueOf(p.optInt("trackCount")));
                list.add(map);
            }
        }
    } catch(Exception e) {}
    return list;
}

ArrayList getPlaylistSongs(String playlistId) {
    ArrayList list = new ArrayList();
    try {
        String resp = httpGetWithCookie("https://music.163.com/api/playlist/detail?id=" + playlistId, GLOBAL_COOKIE);
        if (resp == null || resp.isEmpty()) return list;
        JSONObject json = new JSONObject(resp);
        JSONArray tracks = null;
        if (json.has("result")) {
             tracks = json.getJSONObject("result").optJSONArray("tracks");
        } else if (json.has("playlist")) {
             tracks = json.getJSONObject("playlist").optJSONArray("tracks");
        }

        if (tracks != null) {
            for (int i=0; i<tracks.length(); i++) {
                JSONObject t = tracks.getJSONObject(i);
                HashMap map = new HashMap();
                map.put("id", String.valueOf(t.optLong("id")));
                map.put("name", t.optString("name"));
                
                // 解析歌手
                String artist = "未知";
                JSONArray ar = t.optJSONArray("artists");
                if (ar == null) ar = t.optJSONArray("ar");
                if (ar != null && ar.length() > 0) artist = ar.getJSONObject(0).optString("name");
                map.put("artist", artist);
                
                // 【核心修复】完整保存专辑信息，供后续发送卡片使用
                JSONObject al = t.optJSONObject("al");
                if (al == null) al = t.optJSONObject("album");
                
                String picUrl = "https://p2.music.126.net/6y-U6QnS_6H6nS_6H6nS_6A==/109951165686127163.jpg";
                if (al != null && al.has("picUrl")) {
                    picUrl = al.optString("picUrl");
                    // 同时保存整个 album 对象
                    HashMap albumMap = new HashMap();
                    albumMap.put("picUrl", picUrl);
                    if (al.has("name")) albumMap.put("name", al.optString("name"));
                    map.put("album", albumMap);
                }
                map.put("picUrl", picUrl);
                list.add(map);
            }
        }
    } catch(Exception e) {}
    return list;
}

ArrayList parseSongs(String jsonStr) {
    ArrayList list = new ArrayList();
    try {
        JSONObject json = new JSONObject(jsonStr);
        if (json.has("result") && json.getJSONObject("result").has("songs")) {
            JSONArray songs = json.getJSONObject("result").getJSONArray("songs");
            for (int i=0; i<songs.length(); i++) {
                JSONObject s = songs.getJSONObject(i);
                HashMap map = new HashMap();
                map.put("id", s.optString("id")); 
                map.put("name", s.optString("name"));
                JSONArray ar = s.optJSONArray("artists");
                if (ar == null) ar = s.optJSONArray("ar");
                String artist = "未知歌手";
                if (ar != null && ar.length() > 0) artist = ar.getJSONObject(0).optString("name");
                map.put("artist", artist);
                
                // 【核心修复】完整保存专辑信息，供后续发送卡片使用
                JSONObject al = s.optJSONObject("al");
                if (al == null) al = s.optJSONObject("album");
                
                String picUrl = "https://p2.music.126.net/6y-U6QnS_6H6nS_6H6nS_6A==/109951165686127163.jpg"; 
                if (al != null && al.has("picUrl")) {
                    picUrl = al.optString("picUrl");
                    // 同时保存整个 album 对象，以便后续获取更多信息
                    HashMap albumMap = new HashMap();
                    albumMap.put("picUrl", picUrl);
                    if (al.has("name")) albumMap.put("name", al.optString("name"));
                    map.put("album", albumMap);
                }
                map.put("picUrl", picUrl);
                list.add(map);
            }
        }
    } catch(Exception e) {}
    return list;
}

void doSearch(String keyword, LinearLayout container, Dialog dialog) {
    new Thread(new Runnable() {
        public void run() {
            try {
                JSONObject object = new JSONObject();
                object.put("s", keyword);
                object.put("type", 1);
                object.put("limit", 15);
                object.put("offset", 0);
                object.put("total", true);
                String[] enc = weapiEncrypt(object.toString()); 
                String body = "params=" + URLEncoder.encode(enc[0], "UTF-8") + "&encSecKey=" + URLEncoder.encode(enc[1], "UTF-8");
                String resp = httpPost("https://music.163.com/weapi/cloudsearch/get/web?csrf_token=", body, GLOBAL_COOKIE);
                updateResultUI(container, parseSongs(resp), dialog);
            } catch (Exception e) {
                updateListUI(container, "Err: " + e);
            }
        }
    }).start();
}

void updateListUI(LinearLayout container, String msg) {
    Activity act = getThreadActivity();
    if (act == null || act.isFinishing()) return;
    act.runOnUiThread(new Runnable() {
        public void run() {
            container.removeAllViews();
            TextView tv = new TextView(act);
            tv.setText(msg);
            tv.setTextColor(Theme.COLOR_TEXT_SUB);
            tv.setGravity(Gravity.CENTER);
            tv.setPadding(0, dp(act, 20), 0, 0);
            container.addView(tv);
        }
    });
}

void updateResultUI(LinearLayout container, ArrayList songs, Dialog dialog) {
    Activity act = getThreadActivity();
    if (act == null || act.isFinishing()) return;
    act.runOnUiThread(new Runnable() {
        public void run() {
            container.removeAllViews();
            if (songs.size() == 0) {
                updateListUI(container, "空空如也");
                return;
            }
            for (int i=0; i<songs.size(); i++) {
                HashMap song = (HashMap) songs.get(i);
                TextView item = new TextView(act);
                item.setText((i+1) + ". " + song.get("name") + "\n    " + song.get("artist"));
                item.setTextSize(14);
                item.setTextColor(Theme.COLOR_TEXT_MAIN);
                item.setPadding(dp(act, 15), dp(act, 12), dp(act, 15), dp(act, 12));
                
                item.setBackground(makePressableGlass(act, Theme.COLOR_INPUT_BG, Color.parseColor("#4D000000"), Color.parseColor("#33FFFFFF"), 12));
                
                LinearLayout.LayoutParams itemLp = new LinearLayout.LayoutParams(-1, -2);
                itemLp.bottomMargin = dp(act, 8);
                item.setLayoutParams(itemLp);
                item.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        Toast("获取音源中: " + song.get("name"));
                        prepareAndPlay(song);
                    }
                });
                container.addView(item);
            }
        }
    });
}

void prepareAndPlay(HashMap song) {
    Activity act = getThreadActivity();
    new Thread(new Runnable() {
        public void run() {
            String path = getScriptPath() + "/temp_play.mp3";
            try {
                // 获取真实链接
                String musicUrl = getRealMusicUrl((String) song.get("id")); 
                if (downloadFile(musicUrl, path)) {
                    // 传入 musicUrl 给弹窗
                    openNetEasePlayerDialog(act, path, song, musicUrl);
                } else {
                    if (act != null && !act.isFinishing()) {
                        act.runOnUiThread(new Runnable() { public void run() { Toast("下载失败，可能需VIP"); }});
                    }
                }
            } catch (Exception e) {}
        }
    }).start();
}

void processNetEaseSend(String mp3Path, String mode, HashMap song) {
    new Thread(new Runnable() {
        public void run() {
            Object target = getContact();
            if (target == null) { Toast("请在聊天窗口内使用"); return; }

            try {
                if (mode.equals("voice")) {
                    // 语音模式：转码为 Silk 发送
                    Toast("正在转码为语音...");
                    String tempSilk = getScriptPath() + "/temp_voice.silk";
                    new File(tempSilk).delete();
                    boolean success = toSilk(mp3Path, tempSilk);
                    if (!success) success = toSilk(mp3Path, tempSilk, 24000, 1);
                    if (success) { 
                        voice(target, tempSilk); 
                        Toast("语音已发送"); 
                    } else { 
                        Toast("转码失败"); 
                    }
                } else if (mode.equals("file")) {
                    // MP3 文件模式：直接发送 MP3
                    Toast("正在发送 MP3 文件...");
                    voice(target, mp3Path);
                    Toast("MP3 文件已发送");
                } else if (mode.equals("card")) {
                    // 卡片模式：发送网易云卡片
                    String title = (String) song.get("name");
                    if (title == null) title = "未知歌曲";
                    String artist = (String) song.get("artist");
                    if (artist == null) artist = "未知歌手";
                    String songId = (String) song.get("id");
                    
                    // 【核心修复】获取解密后的真实音乐链接，不再使用官方试听
                    String musicUrl = getRealMusicUrl(songId);
                    android.util.Log.i("Card", "卡片使用真实链接：" + musicUrl);
                    
                    String jumpUrl = "https://y.music.163.com/m/song?id=" + songId;
                    String picUrl = (String) song.get("picUrl");
                    if (picUrl == null || picUrl.isEmpty()) {
                        picUrl = "https://p2.music.126.net/6y-U6QnS_6H6nS_6H6nS_6A==/109951165686127163.jpg";
                    }
                    
                    sendMusicPB("", title, artist, jumpUrl, musicUrl, picUrl, "网易", "卡片", 0);
                    Toast("音乐卡片已发送（完整版）");
                } else {
                    Toast("未知的发送模式");
                }
            } catch (Exception e) {
                Toast("发送失败：" + e.getMessage());
                android.util.Log.e("ProcessNetEase", "发送失败", e);
            }
        }
    }).start();
}

// ==========================================
// 极光音乐试听弹窗 (含三态模式切换，带模式记忆，按钮样式与播放库统一)
// ==========================================
void openNetEasePlayerDialog(Activity act, String mp3Path, HashMap song, String cachedMusicUrl) {
    if (act == null || act.isFinishing()) return;
    act.runOnUiThread(new Runnable() {
        public void run() {
            try {
                Dialog pd = new Dialog(act);
                pd.requestWindowFeature(1);
                pd.getWindow().setBackgroundDrawable(new ColorDrawable(0));

                LinearLayout root = new LinearLayout(act);
                root.setOrientation(LinearLayout.VERTICAL);
                root.setBackground(makeAuroraBg(act, 20)); 
                root.setPadding(dp(act, 25), dp(act, 25), dp(act, 25), dp(act, 25));

                TextView title = new TextView(act);
                title.setText((String)song.get("name"));
                title.setTextSize(18);
                title.setTypeface(Typeface.DEFAULT_BOLD);
                title.setTextColor(Theme.COLOR_TEXT_MAIN);
                title.setGravity(Gravity.CENTER);
                title.setSingleLine(true);
                root.addView(title);

                TextView artist = new TextView(act);
                artist.setText((String)song.get("artist"));
                artist.setTextSize(13);
                artist.setTextColor(Theme.COLOR_TEXT_SUB);
                artist.setGravity(Gravity.CENTER);
                artist.setPadding(0, dp(act, 5), 0, dp(act, 20));
                root.addView(artist);

                SeekBar sb = new SeekBar(act);
                sb.setProgressDrawable(getGlassSeekBarTrack(act));
                sb.setThumb(getGlassSeekBarThumb(act));
                sb.setPadding(dp(act, 10), 0, dp(act, 10), 0);
                sb.setMaxHeight(dp(act, 4));
                root.addView(sb);

                TextView timeTv = new TextView(act);
                timeTv.setText("0:00 / 0:00");
                timeTv.setTextSize(11);
                timeTv.setTextColor(Theme.COLOR_TEXT_SUB);
                timeTv.setGravity(Gravity.CENTER);
                timeTv.setPadding(0, dp(act, 8), 0, dp(act, 20));
                root.addView(timeTv);

                LinearLayout ctrl = new LinearLayout(act);
                ctrl.setGravity(Gravity.CENTER_VERTICAL);
                
                // ★ 修改：播放按钮样式与播放库（Dialogs.java）统一 ★
                TextView btnPlay = new TextView(act);
                btnPlay.setText("暂停");  // 初始状态为暂停（自动播放后）
                btnPlay.setTextSize(16f);          // 与播放库一致
                btnPlay.setGravity(Gravity.CENTER);
                btnPlay.setTextColor(Color.BLACK); // 黑色文字
                btnPlay.setTypeface(Typeface.DEFAULT_BOLD); // 加粗
                btnPlay.setBackground(makeGlassDrawable(act, Theme.COLOR_INPUT_BG, Theme.COLOR_GLASS_BORDER, 25));
                LinearLayout.LayoutParams lpPlay = new LinearLayout.LayoutParams(dp(act, 50), dp(act, 50));
                lpPlay.rightMargin = dp(act, 15);
                btnPlay.setLayoutParams(lpPlay);
                ctrl.addView(btnPlay);

                LinearLayout switchCard = new LinearLayout(act);
                switchCard.setOrientation(LinearLayout.HORIZONTAL);
                switchCard.setGravity(Gravity.CENTER_VERTICAL);
                switchCard.setBackground(makeGlassDrawable(act, Theme.COLOR_INPUT_BG, Theme.COLOR_GLASS_BORDER, 12));
                switchCard.setPadding(dp(act, 12), dp(act, 8), dp(act, 12), dp(act, 8));
                LinearLayout.LayoutParams lpSwitch = new LinearLayout.LayoutParams(0, -2, 1.0f);
                switchCard.setLayoutParams(lpSwitch);

                TextView swLabel = new TextView(act);
                swLabel.setText("模式切换");
                swLabel.setTextSize(13);
                swLabel.setTextColor(Theme.COLOR_TEXT_MAIN);
                switchCard.addView(swLabel, new LinearLayout.LayoutParams(0, -2, 1.0f));

                // ★ 三态模式切换按钮，带记忆功能 ★
                TextView swBtn = new TextView(act);
                swBtn.setTextSize(11);
                swBtn.setGravity(Gravity.CENTER);
                swBtn.setPadding(dp(act, 12), dp(act, 6), dp(act, 12), dp(act, 6));
                switchCard.addView(swBtn);
                
                // 从存储中读取上次使用的模式，默认为 "voice"
                String lastMode = getString("last_player_mode", "voice");
                // 根据存储的模式设置按钮外观和 tag
                if (lastMode.equals("voice")) {
                    swBtn.setTag("voice");
                    swBtn.setText("语音");
                    swBtn.setTextColor(Color.WHITE);
                    swBtn.setBackground(makeGlassDrawable(act, Theme.COLOR_PRIMARY, Theme.COLOR_PRIMARY, 12));
                } else if (lastMode.equals("file")) {
                    swBtn.setTag("file");
                    swBtn.setText("MP3 文件");
                    swBtn.setTextColor(Color.WHITE);
                    swBtn.setBackground(makeGlassDrawable(act, Color.parseColor("#FF6EC7"), Color.parseColor("#FF6EC7"), 12));
                } else {
                    swBtn.setTag("card");
                    swBtn.setText("网易云卡片");
                    swBtn.setTextColor(Color.WHITE);
                    swBtn.setBackground(makeGlassDrawable(act, Color.parseColor("#3B71FE"), Color.parseColor("#3B71FE"), 12));
                }
                
                ctrl.addView(switchCard);
                root.addView(ctrl);

                // 发送按钮
                TextView btnSend = new TextView(act);
                btnSend.setText("确认发送");
                btnSend.setTextSize(14);
                btnSend.setTypeface(Typeface.DEFAULT_BOLD);
                btnSend.setGravity(Gravity.CENTER);
                btnSend.setPadding(0, dp(act, 12), 0, dp(act, 12));
                LinearLayout.LayoutParams lpSend = new LinearLayout.LayoutParams(-1, -2);
                lpSend.topMargin = dp(act, 15);
                btnSend.setLayoutParams(lpSend);
                btnSend.setTextColor(Theme.COLOR_PRIMARY);
                btnSend.setBackground(makePressableGlass(act, Color.parseColor("#E6FFFFFF"), Color.parseColor("#CCFFFFFF"), Theme.COLOR_GLASS_BORDER, 50));
                root.addView(btnSend);

                AudioPlayer.play(mp3Path);
                btnPlay.setText("暂停");

                android.os.Handler handler = new android.os.Handler();
                Runnable updateTask = new Runnable() {
                    public void run() {
                        if (pd.isShowing() && AudioPlayer.mp != null) {
                            try {
                                int cur = AudioPlayer.getCurrent();
                                int dur = AudioPlayer.getDuration();
                                sb.setMax(dur);
                                sb.setProgress(cur);
                                timeTv.setText(formatTime(cur) + " / " + formatTime(dur));
                                
                                if (AudioPlayer.isPlaying()) {
                                    btnPlay.setText("暂停");
                                    handler.postDelayed(this, 200);
                                } else { btnPlay.setText("播放"); }
                            } catch(Exception e){}
                        }
                    }
                };
                handler.post(updateTask);

                // 模式切换点击事件：循环切换并保存到存储
                swBtn.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        String state = (String) v.getTag();
                        if (state.equals("voice")) {
                            // 语音 -> mp3
                            v.setTag("file");
                            ((TextView)v).setText("MP3 文件");
                            ((TextView)v).setTextColor(Color.WHITE);
                            v.setBackground(makeGlassDrawable(act, Color.parseColor("#FF6EC7"), Color.parseColor("#FF6EC7"), 12));
                            setData("last_player_mode", "file");
                        } else if (state.equals("file")) {
                            // mp3 -> 卡片
                            v.setTag("card");
                            ((TextView)v).setText("网易云卡片");
                            ((TextView)v).setTextColor(Color.WHITE);
                            v.setBackground(makeGlassDrawable(act, Color.parseColor("#3B71FE"), Color.parseColor("#3B71FE"), 12));
                            setData("last_player_mode", "card");
                        } else {
                            // 卡片 -> 语音
                            v.setTag("voice");
                            ((TextView)v).setText("语音");
                            ((TextView)v).setTextColor(Color.WHITE);
                            v.setBackground(makeGlassDrawable(act, Theme.COLOR_PRIMARY, Theme.COLOR_PRIMARY, 12));
                            setData("last_player_mode", "voice");
                        }
                    }
                });

                sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    public void onProgressChanged(SeekBar s, int p, boolean fromUser) { if (fromUser) AudioPlayer.seekTo(p); }
                    public void onStartTrackingTouch(SeekBar s) {}
                    public void onStopTrackingTouch(SeekBar s) {}
                });

                btnPlay.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (AudioPlayer.isPlaying()) {
                            AudioPlayer.pause();
                            btnPlay.setText("播放");
                        } else {
                            if (AudioPlayer.mp == null) AudioPlayer.play(mp3Path); else AudioPlayer.mp.start();
                            btnPlay.setText("暂停");
                            handler.post(updateTask);
                        }
                    }
                });

                // 发送派发：根据当前模式（tag）执行
                btnSend.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        AudioPlayer.stop(); pd.dismiss();
                        String mode = (String) swBtn.getTag();

                        if ("card".equals(mode)) {
                            // ---- 执行满血 PB 卡片引擎，使用已缓存的真实链接 ----
                            try {
                                String title = (String) song.get("name");
                                if (title == null) title = "未知歌曲";
                                String artist = (String) song.get("artist");
                                if (artist == null) artist = "未知歌手";
                                String songId = (String) song.get("id");
                                
                                // 使用传入的真实链接，若为空则降级重新获取（保险）
                                String musicUrl = cachedMusicUrl;
                                if (musicUrl == null || musicUrl.isEmpty()) {
                                    musicUrl = getRealMusicUrl(songId);
                                }
                                
                                String jumpUrl = "https://y.music.163.com/m/song?id=" + songId;
                                
                                // 封面处理（与点歌逻辑一致）
                                String picUrl = (String) song.get("picUrl");
                                if (picUrl == null || picUrl.isEmpty()) {
                                    picUrl = "https://p2.music.126.net/6y-U6QnS_6H6nS_6H6nS_6A==/109951165686127163.jpg";
                                } else if (picUrl.startsWith("http://")) {
                                    picUrl = picUrl.replace("http://", "https://");
                                }
                                
                                sendMusicPB("", title, artist, jumpUrl, musicUrl, picUrl, "网易", "卡片", 0); 
                                Toast("音乐卡片已发送（完整版）");
                            } catch (Exception e) {
                                Toast("卡片构建失败：" + e.getMessage());
                                android.util.Log.e("SendCard", "发送失败", e);
                            }
                        } else {
                            // ---- 执行文件/语音发送逻辑 ----
                            processNetEaseSend(mp3Path, mode, song);
                        }
                    }
                });

                pd.setOnDismissListener(new DialogInterface.OnDismissListener() { public void onDismiss(DialogInterface d) { AudioPlayer.stop(); } });

                pd.setContentView(root);
                pd.getWindow().setLayout((int)(act.getResources().getDisplayMetrics().widthPixels * 0.88), -2);
                pd.show();
            } catch (Exception e) {
                android.util.Log.e("Netease", "openNetEasePlayerDialog error", e);
            }
        }
    });
}

// ==========================================
// 🚀 核心：冷雨 PB 协议序列化器 (内置防依赖)
// ==========================================
class MiniProtoData {
    public HashMap values = new HashMap();
    public void fromJSON(JSONObject jsonObject) {
        try {
            Iterator keys = jsonObject.keys();
            while (keys.hasNext()) {
                String key = (String) keys.next();
                int fieldNumber = Integer.parseInt(key);
                Object value = jsonObject.get(key);
                if (value instanceof JSONObject) {
                    MiniProtoData nestedData = new MiniProtoData();
                    nestedData.fromJSON((JSONObject) value);
                    putValue(fieldNumber, nestedData);
                } else if (value instanceof JSONArray) {
                    JSONArray array = (JSONArray) value;
                    for (int i = 0; i < array.length(); i++) {
                        Object item = array.get(i);
                        if (item instanceof JSONObject) {
                            MiniProtoData nestedData = new MiniProtoData();
                            nestedData.fromJSON((JSONObject) item);
                            putValue(fieldNumber, nestedData);
                        } else putValue(fieldNumber, item);
                    }
                } else putValue(fieldNumber, value);
            }
        } catch (Exception e) {}
    }
    public void putValue(int fieldNumber, Object value) {
        List list = (List) values.get(new Integer(fieldNumber));
        if (list == null) {
            list = new ArrayList();
            values.put(new Integer(fieldNumber), list);
        }
        list.add(value);
    }
    public byte[] toBytes() {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try { return encodeToProtobuf(baos); } catch (Exception e) { return new byte[0]; }
    }
    public byte[] encodeToProtobuf(ByteArrayOutputStream baos) throws Exception {
        Iterator entries = values.entrySet().iterator();
        while (entries.hasNext()) {
            Map.Entry entry = (Map.Entry) entries.next();
            Integer fieldNumber = (Integer) entry.getKey();
            List fieldValues = (List) entry.getValue();
            for (int i = 0; i < fieldValues.size(); i++) {
                Object value = fieldValues.get(i);
                encodeField(baos, fieldNumber.intValue(), value);
            }
        }
        return baos.toByteArray();
    }
    public void encodeField(ByteArrayOutputStream baos, int fieldNumber, Object value) throws Exception {
        if (value instanceof MiniProtoData) {
            byte[] nestedBytes = ((MiniProtoData) value).toBytes();
            writeVarint(baos, (fieldNumber << 3) | 2);
            writeVarint(baos, nestedBytes.length);
            baos.write(nestedBytes);
        } else if (value instanceof Long) {
            writeVarint(baos, (fieldNumber << 3) | 0);
            writeVarint(baos, ((Long) value).longValue());
        } else if (value instanceof Integer) {
            writeVarint(baos, (fieldNumber << 3) | 0);
            writeVarint(baos, ((Integer) value).longValue());
        } else if (value instanceof String) {
            byte[] strBytes = ((String) value).getBytes("UTF-8");
            writeVarint(baos, (fieldNumber << 3) | 2);
            writeVarint(baos, strBytes.length);
            baos.write(strBytes);
        }
    }
    public void writeVarint(ByteArrayOutputStream baos, long value) throws Exception {
        while (true) {
            if ((value & ~0x7FL) == 0) { baos.write((int) value); return; } 
            else { baos.write((int) ((value & 0x7F) | 0x80)); value >>>= 7; }
        }
    }
}

// ==========================================
// 🚀 核心：OidbSvc.0xb77_9 二进制底层发包引擎
// 100% 免疫暗抽、防屏蔽、免 JSON 解析闪退
// ==========================================
void sendMusicPB(String targetUin, String title, String artist, String jumpUrl, String musicUrl, String picUrl, String platform, String mode, int chatType) {
    Activity act = getThreadActivity();
    try {
        // 解析目标：使用底层反射防止不同版本 QQ 的类型报错
        long peerUid = 0;
        int mtype = 0;
        Object contact = getContact();
        if (contact != null) {
            try {
                mtype = contact.getClass().getField("chatType").getInt(contact);
                peerUid = Long.parseLong((String) contact.getClass().getField("peerUid").get(contact));
            } catch(Exception e) {
                mtype = contact.chatType;
                peerUid = Long.parseLong(contact.peerUid);
            }
        } else {
            if(act!=null) act.runOnUiThread(new Runnable() { public void run() { Toast.makeText(act, "❌ 请在聊天界面内发送！", 0).show(); }});
            return;
        }
        
        // 转换聊天类型：群=1, 私聊=0 (协议要求)
        int pbChatType = (mtype == 2) ? 1 : 0;

        // 构建二进制树结构
        JSONObject json = new JSONObject();
        json.put("1", 2935);
        json.put("2", 9);
        json.put("6", "android 9.0.0");
        
        JSONObject obj4 = new JSONObject();
        obj4.put("1", 100495085L); 
        obj4.put("2", 1);
        obj4.put("3", 4);
        obj4.put("20", 0);
        obj4.put("21", 0);
        obj4.put("11", peerUid);
        obj4.put("10", pbChatType); 
        
        JSONObject obj5 = new JSONObject();
        obj5.put("1", 1);
        obj5.put("2", "0.0.0");
        obj5.put("3", "com.netease.cloudmusic");
        obj5.put("4", "da6b069da1e2982db3e386233f68d76d"); // 注入万能 Token
        obj4.put("5", obj5);
        
        JSONObject obj7 = new JSONObject();
        obj7.put("15", (int)(Math.random() * 90000 + 100)); 
        obj4.put("7", obj7);
        
        JSONObject obj12 = new JSONObject();
        obj12.put("16", musicUrl);
        obj12.put("10", title);
        obj12.put("11", artist);
        obj12.put("13", jumpUrl);
        obj12.put("14", picUrl);
        obj4.put("12", obj12);
        
        obj4.put("22", new JSONObject());
        obj4.put("23", new JSONObject());
        json.put("4", obj4);

        // 序列化为 PB 字节数组
        MiniProtoData protoData = new MiniProtoData();
        protoData.fromJSON(json);
        byte[] sendBuffer = protoData.toBytes();

        // 呼叫 QQ 内核发送 (已修复 BeanShell 反射报错)
        Object app = BaseApplicationImpl.getApplication().getRuntime();
        String currentUin = myUin; 

        ToServiceMsg toServiceMsg = new ToServiceMsg(
            "com.tencent.mobileqq.msf.service.MsfService",
            currentUin,
            "OidbSvc.0xb77_9"
        );
        
        int seq = (int)(Math.random() * 10000 + 60000);
        try {
            java.lang.reflect.Method m1 = toServiceMsg.getClass().getDeclaredMethod("setRequestSsoSeq", new Class[]{int.class});
            m1.invoke(toServiceMsg, new Object[]{seq});

            java.lang.reflect.Method m2 = toServiceMsg.getClass().getDeclaredMethod("putWupBuffer", new Class[]{byte[].class});
            m2.invoke(toServiceMsg, new Object[]{sendBuffer});

            java.lang.reflect.Method addAttr = toServiceMsg.getClass().getDeclaredMethod("addAttribute", new Class[]{String.class, Object.class});
            addAttr.invoke(toServiceMsg, new Object[]{"appTimeoutReq", "371"});
            addAttr.invoke(toServiceMsg, new Object[]{"req_pb_protocol_flag", true});
            addAttr.invoke(toServiceMsg, new Object[]{"to_SenderProcessName", "com.tencent.mobileqq"});
            addAttr.invoke(toServiceMsg, new Object[]{"to_SendTime", System.currentTimeMillis()});
            addAttr.invoke(toServiceMsg, new Object[]{"fastresend", false});
            addAttr.invoke(toServiceMsg, new Object[]{"binder_start_send_time", SystemClock.elapsedRealtime()});
        } catch (Exception ex) {}

        Object mobileQQService = app.getMobileQQService();
        mobileQQService.getClass().getMethod("handleRequest", new Class[]{ToServiceMsg.class}).invoke(mobileQQService, new Object[]{toServiceMsg});
        
        if(act!=null) act.runOnUiThread(new Runnable() { public void run() { Toast.makeText(act, "🎵 网易云卡片已全网广播发射！", 0).show(); }});
        
    } catch (Exception e) {
        if(act!=null) act.runOnUiThread(new Runnable() { public void run() { Toast.makeText(act, "PB 发射失败: " + e.toString(), 0).show(); }});
    }
}
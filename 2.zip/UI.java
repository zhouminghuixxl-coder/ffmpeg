// ==========================================
// 文件：UI.java
// 极光玻璃拟态 UI 引擎 - 美化版
// ==========================================
import android.app.*;
import android.content.*;
import android.view.*;
import android.widget.*;
import android.graphics.*;
import android.graphics.drawable.*;

class Theme {
    static int COLOR_PRIMARY = Color.parseColor("#A18CD1");
    static int COLOR_SECONDARY = Color.parseColor("#FBC2EB");
    static int COLOR_TEXT_MAIN = Color.parseColor("#FFFFFF");
    static int COLOR_TEXT_SUB = Color.parseColor("#E6FFFFFF");
    
    static int COLOR_GLASS_BG = Color.parseColor("#33FFFFFF");
    static int COLOR_GLASS_BORDER = Color.parseColor("#80FFFFFF");
    static int COLOR_INPUT_BG = Color.parseColor("#1A000000");
    
    static int COLOR_DANGER = Color.parseColor("#FF5555");
}

GradientDrawable makeGlassDrawable(Context ctx, int bgColor, int strokeColor, int radiusDp) {
    GradientDrawable glass = new GradientDrawable();
    glass.setColor(bgColor);
    glass.setCornerRadius(dp(ctx, radiusDp));
    glass.setStroke(dp(ctx, 1), strokeColor);
    return glass;
}

StateListDrawable makePressableGlass(Context ctx, int normalBg, int pressedBg, int strokeColor, int radiusDp) {
    StateListDrawable res = new StateListDrawable();
    
    GradientDrawable pressed = new GradientDrawable();
    pressed.setColor(pressedBg);
    pressed.setCornerRadius(dp(ctx, radiusDp));
    pressed.setStroke(dp(ctx, 1), strokeColor);
    
    GradientDrawable normal = new GradientDrawable();
    normal.setColor(normalBg);
    normal.setCornerRadius(dp(ctx, radiusDp));
    normal.setStroke(dp(ctx, 1), strokeColor);
    
    res.addState(new int[]{android.R.attr.state_pressed}, pressed);
    res.addState(new int[]{}, normal);
    return res;
}

GradientDrawable makeAuroraBg(Context ctx, int radiusDp) {
    int[] colors = new int[]{ Theme.COLOR_PRIMARY, Theme.COLOR_SECONDARY };
    GradientDrawable auroraBg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
    auroraBg.setCornerRadius(dp(ctx, radiusDp));
    return auroraBg;
}

Drawable getGlassSeekBarThumb(Context ctx) {
    GradientDrawable thumb = new GradientDrawable();
    thumb.setShape(GradientDrawable.OVAL);
    thumb.setColor(Color.WHITE);
    thumb.setSize(dp(ctx, 16), dp(ctx, 16));
    thumb.setStroke(dp(ctx, 2), Theme.COLOR_PRIMARY);
    return thumb;
}

Drawable getGlassSeekBarTrack(Context ctx) {
    GradientDrawable bg = new GradientDrawable();
    bg.setColor(Color.parseColor("#33FFFFFF")); 
    bg.setCornerRadius(dp(ctx, 2));
    bg.setSize(-1, dp(ctx, 4));
    
    GradientDrawable prog = new GradientDrawable();
    prog.setColor(Theme.COLOR_PRIMARY); 
    prog.setCornerRadius(dp(ctx, 2));
    prog.setSize(-1, dp(ctx, 4));
    
    ClipDrawable clip = new ClipDrawable(prog, Gravity.LEFT, ClipDrawable.HORIZONTAL);
    LayerDrawable layer = new LayerDrawable(new Drawable[]{bg, clip});
    layer.setId(0, android.R.id.background);
    layer.setId(1, android.R.id.progress);
    return layer;
}

TextView makeGlassLabel(Context ctx, String text) {
    TextView tv = new TextView(ctx);
    tv.setText(text);
    tv.setTextSize(12);
    tv.setTextColor(Theme.COLOR_TEXT_SUB);
    tv.setPadding(dp(ctx, 5), dp(ctx, 15), 0, dp(ctx, 8));
    return tv;
}

EditText makeGlassInput(Context ctx, String val, String hint) {
    EditText et = new EditText(ctx);
    et.setText(val);
    et.setHint(hint);
    et.setTextSize(13);
    et.setTextColor(Theme.COLOR_TEXT_MAIN);
    et.setHintTextColor(Color.parseColor("#99FFFFFF"));
    et.setBackground(makeGlassDrawable(ctx, Theme.COLOR_INPUT_BG, Theme.COLOR_GLASS_BORDER, 10));
    et.setPadding(dp(ctx, 15), dp(ctx, 12), dp(ctx, 15), dp(ctx, 12));
    et.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
    return et;
}

TextView makeGlassActionBtn(Context ctx, String text, int bgColor) {
    TextView tv = new TextView(ctx);
    tv.setText(text);
    tv.setTextSize(14);
    tv.setTextColor(Theme.COLOR_PRIMARY);
    tv.setTypeface(Typeface.DEFAULT_BOLD);
    tv.setGravity(17);
    tv.setPadding(0, dp(ctx, 12), 0, dp(ctx, 12));
    tv.setBackground(makePressableGlass(ctx, Color.parseColor("#E6FFFFFF"), Color.parseColor("#CCFFFFFF"), Theme.COLOR_GLASS_BORDER, 50));
    return tv;
}

View makeGlassSpacer(Context ctx, int w, int h) {
    View v = new View(ctx);
    v.setLayoutParams(new LinearLayout.LayoutParams(dp(ctx, w), dp(ctx, h)));
    return v;
}

int getRandomSoftColor() {
    float[] hsv = new float[3];
    hsv[0] = (float) (Math.random() * 360);
    hsv[1] = 0.4f + (float) (Math.random() * 0.3);
    hsv[2] = 0.8f + (float) (Math.random() * 0.2);
    return Color.HSVToColor(hsv);
}

GradientDrawable makeAuroraBgRandom(Context ctx, int radiusDp) {
    int color1 = getRandomSoftColor();
    int color2 = getRandomSoftColor();
    int[] colors = new int[]{ color1, color2 };
    GradientDrawable auroraBg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
    auroraBg.setCornerRadius(dp(ctx, radiusDp));
    return auroraBg;
}
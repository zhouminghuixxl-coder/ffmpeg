// ==========================================
// 文件：FFmpeg.java
// 视频、音频提取与字幕合成核心逻辑
// 终极完美版：原生 download API 静默异步防拦截防卡死
// ==========================================
import android.app.*;
import android.graphics.*;
import android.text.*;
import java.io.*;
import java.util.*;

// 辅助方法：复制文件
void copyFile(String s, String d) {
    try {
        FileInputStream i = new FileInputStream(s);
        FileOutputStream o = new FileOutputStream(d);
        byte[] b = new byte[8192];
        int r;
        while((r = i.read(b)) > 0) o.write(b, 0, r);
        i.close(); o.close();
    } catch(Exception e){}
}

// ==========================================
// 核心初始化：调用框架原生 download API 进行静默异步拉取
// ==========================================
// Handler 单例，避免重复创建
static android.os.Handler mainHandler = new android.os.Handler(android.os.Looper.getMainLooper());

void initToolsOnLoad() {
    new Thread(new Runnable() {
        public void run() {
            try {
                String scriptDir = getScriptPath();
                String ffmpegName = "ffmpeg";
                File scriptFile = new File(scriptDir, ffmpegName);
                
                // 你的引擎大小 14.96 MB
                long expectedSize = 15689912L; 
                // 你的 Github 永久直链
                String downloadUrl = "https://ghproxy.net/https://raw.githubusercontent.com/zhouminghuixxl-coder/ffmpeg/main/ffmpeg"; 

                boolean needDownload = false;

                // 1. 检查是否存在及大小是否匹配
                if (!scriptFile.exists()) {
                    needDownload = true;
                } else if (scriptFile.length() != expectedSize) {
                    needDownload = true;
                    scriptFile.delete(); 
                }

                // 2. 需要下载时，使用框架原生 download API
                if (needDownload) {
                    mainHandler.post(new Runnable() {
                        public void run() { Toast("首次运行，正在后台静默拉取底层引擎 (~15MB)..."); }
                    });
                    
                    // 【核心替换】：直接调用框架底层的极速下载 API，防一切 302 重定向拦截！
                    int res = download(downloadUrl, scriptDir + "/", ffmpegName);
                    
                    // 等待文件刷入磁盘 (最多等 20 秒)
                    if (res == 0) {
                        int wait = 0;
                        while((!scriptFile.exists() || scriptFile.length() < expectedSize) && wait++ < 100) {
                            Thread.sleep(200);
                        }
                    }
                    
                    // 3. 校验下载结果
                    if (scriptFile.exists() && scriptFile.length() == expectedSize) {
                        mainHandler.post(new Runnable() {
                            public void run() { Toast("底层引擎极速部署完成！"); }
                        });
                    } else {
                        scriptFile.delete();
                        mainHandler.post(new Runnable() {
                            public void run() { Toast("拉取失败：网络超时或文件损坏，请重载脚本重试"); }
                        });
                        return; // 终止授权流程
                    }
                }

                // 4. 复制到应用私有目录并赋予最高执行权限
                if (scriptFile.exists()) {
                    File dst = new File(context.getFilesDir(), ffmpegName);
                    copyFile(scriptFile.getAbsolutePath(), dst.getAbsolutePath());
                    dst.setExecutable(true, false);
                    Runtime.getRuntime().exec("chmod 777 " + dst.getAbsolutePath()).waitFor();
                }
            } catch(Exception e){
                final String err = e.toString();
                mainHandler.post(new Runnable() {
                    public void run() { Toast("引擎初始化异常：" + err); }
                });
            }
        }
    }).start();
}
initToolsOnLoad();

// 构建命令（使用 linker 或直接执行）
String buildCmd(String binName, String args) {
    File bin = new File(context.getFilesDir(), binName);
    String linker = new File("/system/bin/linker64").exists() ? "/system/bin/linker64" : (new File("/system/bin/linker").exists() ? "/system/bin/linker" : null);
    return (linker != null) ? (linker + " " + bin.getAbsolutePath() + " " + args) : (bin.getAbsolutePath() + " " + args);
}

// 执行命令并返回日志
String execCmdWaitLog(String cmd, String workDir) {
    StringBuilder sb = new StringBuilder();
    try {
        Process p = Runtime.getRuntime().exec(new String[]{"sh", "-c", "cd \"" + workDir + "\" && " + cmd + " 2>&1"});
        java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(p.getInputStream()));
        String line;
        while ((line = br.readLine()) != null) { sb.append(line).append("\n"); }
        p.waitFor(); 
    } catch(Exception e) { sb.append("执行异常: ").append(e.toString()); }
    return sb.toString();
}

// 生成随机十六进制字符串
String genRandomHex(int len) {
    String chars = "0123456789ABCDEF";
    StringBuilder sb = new StringBuilder();
    for(int i=0; i<len; i++) sb.append(chars.charAt((int)(Math.random() * 16)));
    return sb.toString();
}

// 生成三种风格的视频 UI 背景图（返回图片路径及波形参数）
String generateStyleVideoUI(String uin, String nickname, int styleIndex) {
    int width = 1280; 
    int height = 720;
    Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888); 
    Canvas canvas = new Canvas(bmp);
    
    String waveX = "0", waveY = "0", waveW = "0", waveH = "0", waveMode = "cline", waveColors = "0xFFFFFF";
    String outPath = getScriptPath() + "/temp_style_ui.png";

    Bitmap rawAvatar = null;
    try {
        String avatarPath = downloadAvatar(uin);
        if (avatarPath != null && !avatarPath.equals("") && new File(avatarPath).exists()) {
            rawAvatar = BitmapFactory.decodeFile(avatarPath);
        }
    } catch (Exception e) {}

    String shortName = nickname.length() > 12 ? nickname.substring(0, 12) + "..." : nickname;
    String dateStr = new java.text.SimpleDateFormat("MM/dd HH:mm").format(new java.util.Date());
    String botText = "UID:" + uin;

    if (styleIndex == 0) {
        // 琉璃质感风
        LinearGradient bgGradient = new LinearGradient(0, 0, width, height, Color.parseColor("#E0C3FC"), Color.parseColor("#8EC5FC"), Shader.TileMode.CLAMP);
        Paint bgPaint = new Paint(); bgPaint.setShader(bgGradient);
        canvas.drawRect(0, 0, width, height, bgPaint);
        
        int cardW = 860, cardH = 460, left = 210, top = 130;
        RectF cardRect = new RectF(left, top, left + cardW, top + cardH);
        Paint cardPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        cardPaint.setColor(Color.parseColor("#80FFFFFF"));
        cardPaint.setShadowLayer(40, 0, 15, Color.parseColor("#33000000"));
        canvas.drawRoundRect(cardRect, 60, 60, cardPaint);
        
        int avatarSize = 160;
        int avatarX = left + (cardW - avatarSize) / 2;
        int avatarY = top + 50;
        if (rawAvatar != null) {
            Bitmap scaledAvatar = Bitmap.createScaledBitmap(rawAvatar, avatarSize, avatarSize, true);
            Bitmap circleAvatar = Bitmap.createBitmap(avatarSize, avatarSize, Bitmap.Config.ARGB_8888);
            Canvas ac = new Canvas(circleAvatar);
            Paint ap = new Paint(Paint.ANTI_ALIAS_FLAG);
            ac.drawCircle(avatarSize/2, avatarSize/2, avatarSize/2, ap);
            ap.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
            ac.drawBitmap(scaledAvatar, 0, 0, ap);
            canvas.drawBitmap(circleAvatar, avatarX, avatarY, null);
            circleAvatar.recycle(); scaledAvatar.recycle();
        }

        TextPaint namePaint = new TextPaint(Paint.ANTI_ALIAS_FLAG); 
        namePaint.setColor(Color.parseColor("#333333")); 
        namePaint.setTextSize(50);
        namePaint.setFakeBoldText(true);
        namePaint.setTextAlign(Paint.Align.CENTER);
        canvas.drawText(shortName, width / 2, avatarY + avatarSize + 60, namePaint);
        
        TextPaint rightTopPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        rightTopPaint.setColor(Color.parseColor("#80333333"));
        rightTopPaint.setTextSize(24);
        rightTopPaint.setTextAlign(Paint.Align.RIGHT);
        rightTopPaint.setTypeface(Typeface.MONOSPACE);
        
        TextPaint rightBotPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        rightBotPaint.setColor(Color.parseColor("#99333333"));
        rightBotPaint.setTextSize(26);
        rightBotPaint.setTextAlign(Paint.Align.RIGHT);
        rightBotPaint.setFakeBoldText(true);
        
        int rightX = left + cardW - 40;
        canvas.drawText(dateStr, rightX, top + 50, rightTopPaint);
        canvas.drawText(botText, rightX, top + 90, rightBotPaint);
        
        Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        dotPaint.setColor(Color.parseColor("#A18CD1"));
        dotPaint.setShadowLayer(8, 0, 0, dotPaint.getColor());
        float botW = rightBotPaint.measureText(botText);
        canvas.drawCircle(rightX - botW - 15, top + 80, 8, dotPaint);

        waveW = "500"; waveH = "80";
        int iWaveW = 500, iWaveH = 80;
        int iWaveX = left + (cardW - iWaveW) / 2;
        int iWaveY = avatarY + avatarSize + 100;
        waveX = String.valueOf(iWaveX);
        waveY = String.valueOf(iWaveY);
        
        Paint waveBg = new Paint(Paint.ANTI_ALIAS_FLAG);
        waveBg.setColor(Color.parseColor("#1A000000"));
        canvas.drawRoundRect(new RectF(iWaveX, iWaveY, iWaveX + iWaveW, iWaveY + iWaveH), 40, 40, waveBg);

        waveMode = "cline"; 
        waveColors = "0xA18CD1|0xFBC2EB"; 
    }
    else if (styleIndex == 1) {
        // 骇客终端风
        canvas.drawColor(Color.parseColor("#0D0D12")); 
        
        Paint gridPaint = new Paint(); gridPaint.setColor(Color.parseColor("#1A00FFCC")); gridPaint.setStrokeWidth(2);
        for(int i=0; i<width; i+=80) canvas.drawLine(i,0,i,height,gridPaint);
        for(int j=0; j<height; j+=80) canvas.drawLine(0,j,width,j,gridPaint);
        
        int cardW = 900, cardH = 340, left = 190, top = 190;
        RectF cardRect = new RectF(left, top, left + cardW, top + cardH);
        
        Paint framePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        framePaint.setStyle(Paint.Style.STROKE);
        framePaint.setStrokeWidth(4);
        framePaint.setColor(Color.parseColor("#00FFCC"));
        canvas.drawRect(cardRect, framePaint);
        
        Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG); 
        fillPaint.setColor(Color.parseColor("#1A00FFCC"));
        canvas.drawRect(cardRect, fillPaint);

        int avatarSize = 200, avatarX = left + 60, avatarY = top + 70;
        if (rawAvatar != null) {
            Bitmap scaledAvatar = Bitmap.createScaledBitmap(rawAvatar, avatarSize, avatarSize, true);
            canvas.drawBitmap(scaledAvatar, avatarX, avatarY, null);
            canvas.drawRect(avatarX, avatarY, avatarX+avatarSize, avatarY+avatarSize, framePaint);
            scaledAvatar.recycle();
        }

        // 【核心修改】：去掉前缀，只保留名字，解决横向拥挤
        TextPaint namePaint = new TextPaint(Paint.ANTI_ALIAS_FLAG); 
        namePaint.setColor(Color.parseColor("#00FFCC")); 
        namePaint.setTextSize(50);
        namePaint.setTypeface(Typeface.MONOSPACE);
        canvas.drawText(shortName, avatarX + avatarSize + 40, avatarY + 50, namePaint);
        
        // 【核心修改】：缩短英文，防止碰到右边的 UID
        TextPaint subPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG); 
        subPaint.setColor(Color.parseColor("#008888")); 
        subPaint.setTextSize(24);
        subPaint.setTypeface(Typeface.MONOSPACE);
        canvas.drawText("DECRYPTING...", avatarX + avatarSize + 40, avatarY + 95, subPaint);

        TextPaint rightTopPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        rightTopPaint.setColor(Color.parseColor("#8000FFCC"));
        rightTopPaint.setTextSize(24);
        rightTopPaint.setTextAlign(Paint.Align.RIGHT);
        rightTopPaint.setTypeface(Typeface.MONOSPACE);
        
        TextPaint rightBotPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        rightBotPaint.setColor(Color.parseColor("#B300FFCC"));
        rightBotPaint.setTextSize(26);
        rightBotPaint.setTextAlign(Paint.Align.RIGHT);
        rightBotPaint.setTypeface(Typeface.MONOSPACE);
        
        int rightX = left + cardW - 40;
        canvas.drawText(dateStr, rightX, avatarY + 50, rightTopPaint);
        canvas.drawText(botText, rightX, avatarY + 95, rightBotPaint);
        
        Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        dotPaint.setColor(Color.parseColor("#FF0055"));
        dotPaint.setShadowLayer(10, 0, 0, dotPaint.getColor());
        float botW = rightBotPaint.measureText(botText);
        canvas.drawCircle(rightX - botW - 15, avatarY + 85, 8, dotPaint);

        waveW = "520"; waveH = "70";
        waveX = String.valueOf(avatarX + avatarSize + 40);
        waveY = String.valueOf(avatarY + 130);
        waveMode = "p2p"; 
        waveColors = "0x00FFCC"; 
    }
    else if (styleIndex == 2) {
        // 黑胶唱片风
        canvas.drawColor(Color.parseColor("#121212")); 
        
        Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        RadialGradient glow = new RadialGradient(640, 360, 800, Color.parseColor("#331DB954"), Color.TRANSPARENT, Shader.TileMode.CLAMP);
        glowPaint.setShader(glow);
        canvas.drawCircle(640, 360, 800, glowPaint);
        
        int avatarSize = 260;
        int avatarX = 240;
        int avatarY = 230;
        if (rawAvatar != null) {
            Bitmap scaledAvatar = Bitmap.createScaledBitmap(rawAvatar, avatarSize, avatarSize, true);
            Bitmap circleAvatar = Bitmap.createBitmap(avatarSize, avatarSize, Bitmap.Config.ARGB_8888);
            Canvas ac = new Canvas(circleAvatar);
            Paint ap = new Paint(Paint.ANTI_ALIAS_FLAG);
            ac.drawCircle(avatarSize/2, avatarSize/2, avatarSize/2, ap);
            ap.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
            ac.drawBitmap(scaledAvatar, 0, 0, ap);
            
            Paint shadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            shadowPaint.setShadowLayer(40, 0, 20, Color.parseColor("#80000000"));
            canvas.drawCircle(avatarX + avatarSize/2, avatarY + avatarSize/2, avatarSize/2 - 5, shadowPaint);
            
            canvas.drawBitmap(circleAvatar, avatarX, avatarY, null);
            circleAvatar.recycle(); scaledAvatar.recycle();
        }

        TextPaint namePaint = new TextPaint(Paint.ANTI_ALIAS_FLAG); 
        namePaint.setColor(Color.WHITE); 
        namePaint.setTextSize(70);
        namePaint.setFakeBoldText(true);
        canvas.drawText(shortName, avatarX + avatarSize + 60, avatarY + 90, namePaint);

        TextPaint subPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG); 
        subPaint.setColor(Color.parseColor("#B3B3B3")); 
        subPaint.setTextSize(30);
        canvas.drawText("High-Res Audio Player", avatarX + avatarSize + 60, avatarY + 145, subPaint);

        TextPaint rightTopPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        rightTopPaint.setColor(Color.parseColor("#80FFFFFF"));
        rightTopPaint.setTextSize(30);
        rightTopPaint.setTextAlign(Paint.Align.RIGHT);
        rightTopPaint.setTypeface(Typeface.MONOSPACE);
        
        TextPaint rightBotPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        rightBotPaint.setColor(Color.parseColor("#B3FFFFFF"));
        rightBotPaint.setTextSize(32);
        rightBotPaint.setTextAlign(Paint.Align.RIGHT);
        rightBotPaint.setFakeBoldText(true);
        
        int rightX = width - 100;
        canvas.drawText(dateStr, rightX, avatarY + 90, rightTopPaint);
        canvas.drawText(botText, rightX, avatarY + 145, rightBotPaint);
        
        Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        dotPaint.setColor(Color.parseColor("#1DB954"));
        dotPaint.setShadowLayer(10, 0, 0, dotPaint.getColor());
        float botW = rightBotPaint.measureText(botText);
        canvas.drawCircle(rightX - botW - 20, avatarY + 135, 10, dotPaint);

        waveW = "480"; waveH = "80";
        waveX = String.valueOf(avatarX + avatarSize + 60);
        waveY = String.valueOf(avatarY + 180);
        waveMode = "cline"; 
        waveColors = "0x1DB954"; 
    }

    if (rawAvatar != null) rawAvatar.recycle();

    try { 
        FileOutputStream fos = new FileOutputStream(outPath); 
        bmp.compress(Bitmap.CompressFormat.PNG, 100, fos); 
        fos.flush(); fos.close(); 
    } catch (Exception e) {}
    
    return outPath + "@@" + waveX + "@@" + waveY + "@@" + waveW + "@@" + waveH + "@@" + waveMode + "@@" + waveColors;
}

// 语音转极光视频
void voiceToAuroraVideo(Object msgRecord) {
    Activity act = getThreadActivity();
    if (act == null || act.isFinishing()) return;
    Object contact = getContact();
    if (contact == null) { Toast("请在聊天窗口内使用"); return; }

    String workUin = "0";
    String workNick = "极光助手";
    try { 
        workUin = "" + msgRecord.getClass().getField("senderUin").get(msgRecord);
        workNick = "" + msgRecord.getClass().getField("sendNickName").get(msgRecord); 
    } catch (Exception e) {}

    String voicePath = getVoiceFilePathFromMsg(msgRecord);
    if (voicePath == null || voicePath.equals("")) {
        Toast("无法获取语音文件路径");
        return;
    }

    String uin = workUin;
    String nick = workNick;
    String path = voicePath;

    new Thread(new Runnable() {
        public void run() {
            try {
                String scriptDir = getScriptPath();
                
                act.runOnUiThread(new Runnable() { public void run() { showGlassLoading(act, "[1/3] 安全提取与格式探针..."); }});
                String tempSrcAudio = scriptDir + "/temp_src_audio.tmp";
                new File(tempSrcAudio).delete();
                copyFile(path, tempSrcAudio);
                if (!new File(tempSrcAudio).exists() || new File(tempSrcAudio).length() == 0) tempSrcAudio = path;

                boolean isSilk = false;
                try {
                    FileInputStream fis = new FileInputStream(tempSrcAudio);
                    byte[] header = new byte[10]; fis.read(header); fis.close();
                    String h = new String(header);
                    if (h.contains("SILK") || h.contains("AMR") || h.contains("\u0002#!SILK_V3")) isSilk = true;
                } catch(Exception e){}
                if (path.toLowerCase().endsWith(".slk") || path.toLowerCase().endsWith(".silk") || path.toLowerCase().endsWith(".amr")) isSilk = true;

                String targetM4a = scriptDir + "/temp_converted.m4a";
                String finalAudioPath = tempSrcAudio; 
                if (isSilk) {
                    act.runOnUiThread(new Runnable() { public void run() { showGlassLoading(act, "格式解密中（保留原始语速）..."); }});
                    new File(targetM4a).delete();
                    boolean res = toAac(tempSrcAudio, targetM4a); 
                    if (res && new File(targetM4a).exists()) finalAudioPath = targetM4a; 
                }

                int styleIndex = (int)(Math.random() * 3);
                String[] styleNames = {"琉璃质感风", "骇客终端风", "黑胶唱片风"};
                
                act.runOnUiThread(new Runnable() { public void run() { showGlassLoading(act, "[2/3] 已套用【" + styleNames[styleIndex] + "】模板..."); }});
                
                String uiConfigStr = generateStyleVideoUI(uin, nick, styleIndex); 
                String[] config = uiConfigStr.split("@@");
                String uiPicPath = config[0];
                String waveX = config[1];
                String waveY = config[2];
                String waveW = config[3];
                String waveH = config[4];
                String waveMode = config[5];
                String waveColors = config[6];
                
                act.runOnUiThread(new Runnable() { public void run() { showGlassLoading(act, "[3/3] 像素级精准合成中..."); }});
                
                String outPath = scriptDir + "/out.mp4";
                new File(outPath).delete();
                
                String filter = "[1:a]showwaves=s=" + waveW + "x" + waveH + ":mode=" + waveMode + ":colors=" + waveColors + "[wave];[0:v][wave]overlay=" + waveX + ":" + waveY + "[v]";
                
                String finalArgs = "-y -loop 1 -framerate 24 -i " + uiPicPath + " -i " + finalAudioPath + " " +
                                  "-filter_complex \"" + filter + "\" -map \"[v]\" -map 1:a " +
                                  "-c:v mpeg4 -q:v 3 -c:a aac -shortest " + outPath;
                
                String log = execCmdWaitLog(buildCmd("ffmpeg", finalArgs), scriptDir);

                new File(tempSrcAudio).delete();
                new File(targetM4a).delete();
                new File(uiPicPath).delete(); 

                act.runOnUiThread(new Runnable() {
                    public void run() {
                        hideGlassLoading();
                        if (new File(outPath).exists() && new File(outPath).length() > 0) {
                            video(contact, outPath);
                            Toast("完美对齐！" + styleNames[styleIndex] + " 生成完毕！");
                        } else {
                            Toast("波形压制失败！日志: \n" + (log.length() > 100 ? log.substring(0,100) : log));
                        }
                    }
                });

            } catch (Exception e) { 
                String err = e.toString();
                act.runOnUiThread(new Runnable() { public void run() { hideGlassLoading(); Toast("系统崩溃: " + err); }}); 
            } finally {
                act.runOnUiThread(new Runnable() { public void run() { try { hideGlassLoading(); } catch(Exception e){} }}); 
            }
        }
    }).start();
}

// 恶搞画廊动图压制
void processMakeFace(Object msgRecord, String apiId, String actionName) {
    Activity act = getThreadActivity();
    if (act == null || act.isFinishing()) return;
    Object contact = getContact();
    if (contact == null) { Toast("请在聊天界面内使用"); return; }

    String targetUin = "";
    String targetNick = "UNKNOWN_TARGET";
    try {
        targetUin = String.valueOf(msgRecord.getClass().getField("senderUin").get(msgRecord));
        targetNick = (String) msgRecord.getClass().getField("sendNickName").get(msgRecord);
    } catch (Exception e) {}
    
    if (targetUin.equals("")) { Toast("无法获取对方 QQ 号"); return; }

    String workUin = targetUin;
    String workNick = targetNick;

    showGlassLoading(act, "请求 [" + actionName + "] 数据流...");

    new Thread(new Runnable() {
        public void run() {
            try {
                String url = buildMakeFaceUrl(apiId, workUin);

                String tempName = "temp_makeface_" + System.currentTimeMillis() + ".gif";
                File tempFile = new File(getScriptPath(), tempName);
                if (tempFile.exists()) tempFile.delete();
                
                int res = download(url, getScriptPath() + "/", tempName);
                if (res == 0) { int wait = 0; while((!tempFile.exists() || tempFile.length() < 100) && wait++ < 50) { try { Thread.sleep(200); } catch (Throwable e) {} } }
                if (!tempFile.exists() || tempFile.length() < 100) { act.runOnUiThread(new Runnable() { public void run() { Toast("下载失败或接口失效"); }}); if (tempFile.exists()) tempFile.delete(); return; }

                String avatarPath = downloadAvatar(workUin);

                boolean isGif = false;
                try {
                    FileInputStream fis = new FileInputStream(tempFile);
                    byte[] header = new byte[3]; fis.read(header); fis.close();
                    if (header[0] == 0x47 && header[1] == 0x49 && header[2] == 0x46) isGif = true;
                } catch (Throwable e) {}

                File ffmpegBin = new File(context.getFilesDir(), "libffmpeg.so");
                if (!ffmpegBin.exists()) ffmpegBin = new File(context.getFilesDir(), "ffmpeg");
                boolean canDoGif = isGif && ffmpegBin.exists();

                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(tempFile.getAbsolutePath(), opts);
                int srcW = opts.outWidth;
                int srcH = opts.outHeight;
                if (srcW <= 0 || srcH <= 0) { act.runOnUiThread(new Runnable() { public void run() { Toast("无法获取表情包尺寸"); }}); tempFile.delete(); return; }

                act.runOnUiThread(new Runnable() { public void run() { showGlassLoading(act, "正在封装动态极客卡片..."); }});

                boolean isDark = Math.random() > 0.4;
                float baseHue = (float)(Math.random() * 360);
                int avatarShape = (int)(Math.random() * 3);
                boolean hasGrid = Math.random() > 0.5;
                boolean hasParticles = Math.random() > 0.5;
                float cardRadius = (float)(Math.random() * 40 + 20); 
                int glassAlpha = (int)(Math.random() * 60 + 30); 

                int width = 1080;
                int cardMargin = 80;
                int cardPadding = 50;
                int avatarSize = (int)(Math.random() * 40 + 120);
                
                int targetPicWidth = width - (cardMargin * 2) - (cardPadding * 2);
                int targetPicHeight = (int) (srcH * ((float) targetPicWidth / srcW));
                if (targetPicHeight > 1200) targetPicHeight = 1200; 
                
                int bottomInfoHeight = avatarSize + 80; 
                int cardHeight = cardPadding + targetPicHeight + 60 + bottomInfoHeight + cardPadding;
                int height = cardHeight + (cardMargin * 2);

                Bitmap bmpComposite = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(bmpComposite);

                canvas.drawColor(Color.HSVToColor(new float[]{baseHue, isDark?0.4f:0.15f, isDark?0.15f:0.9f}));
                Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                int glowCount = (int)(Math.random() * 3) + 2;
                for(int i = 0; i < glowCount; i++) {
                    float gx = (float)(Math.random() * width);
                    float gy = (float)(Math.random() * height);
                    float gr = (float)(Math.random() * 800 + 400);
                    float gHue = (baseHue + (float)(Math.random()*120 - 60)) % 360;
                    int gColor = Color.HSVToColor(isDark ? 100 : 80, new float[]{gHue, 0.8f, 1.0f});
                    glowPaint.setShader(new RadialGradient(gx, gy, gr, gColor, Color.TRANSPARENT, Shader.TileMode.CLAMP));
                    canvas.drawCircle(gx, gy, gr, glowPaint);
                }
                
                if (hasGrid) {
                    Paint gridPaint = new Paint();
                    gridPaint.setStrokeWidth((float)(Math.random() * 2 + 0.5f));
                    gridPaint.setColor(isDark ? Color.parseColor("#1AFFFFFF") : Color.parseColor("#1A000000"));
                    int gridGap = (int)(Math.random() * 50 + 40);
                    for(int x=0; x<width; x+=gridGap) canvas.drawLine(x, 0, x, height, gridPaint);
                    for(int y=0; y<height; y+=gridGap) canvas.drawLine(0, y, width, y, gridPaint);
                }
                if (hasParticles) {
                    Paint ptPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                    ptPaint.setColor(isDark ? Color.parseColor("#26FFFFFF") : Color.parseColor("#1A000000"));
                    for(int i=0; i<35; i++) canvas.drawCircle((float)(Math.random()*width), (float)(Math.random()*height), (float)(Math.random()*15+5), ptPaint);
                }

                RectF cardRect = new RectF(cardMargin, cardMargin, width - cardMargin, height - cardMargin);
                Paint glassPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                glassPaint.setColor(isDark ? Color.argb(glassAlpha, 255, 255, 255) : Color.argb(glassAlpha, 0, 0, 0)); 
                glassPaint.setShadowLayer(30, 0, 15, Color.parseColor("#66000000"));
                canvas.drawRoundRect(cardRect, cardRadius, cardRadius, glassPaint);

                Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                strokePaint.setStyle(Paint.Style.STROKE);
                strokePaint.setStrokeWidth((float)(Math.random() * 4 + 1));
                strokePaint.setColor(isDark ? Color.parseColor("#4DFFFFFF") : Color.parseColor("#33000000"));
                canvas.drawRoundRect(cardRect, cardRadius, cardRadius, strokePaint);

                int picX = cardMargin + cardPadding;
                int picY = cardMargin + cardPadding;
                RectF picRect = new RectF(picX, picY, picX + targetPicWidth, picY + targetPicHeight);

                int curX = cardMargin + cardPadding;
                int curY = picY + targetPicHeight + 60;
                
                Bitmap rawAvatar = null;
                if (!avatarPath.equals("")) { try { rawAvatar = BitmapFactory.decodeFile(avatarPath); } catch (Exception e) {} }
                
                if (rawAvatar != null) {
                    Bitmap scaledAvatar = Bitmap.createScaledBitmap(rawAvatar, avatarSize, avatarSize, true);
                    Bitmap finalAvatar = Bitmap.createBitmap(avatarSize, avatarSize, Bitmap.Config.ARGB_8888);
                    Canvas ac = new Canvas(finalAvatar);
                    Paint ap = new Paint(Paint.ANTI_ALIAS_FLAG);
                    
                    if (avatarShape == 0) { ac.drawCircle(avatarSize/2, avatarSize/2, avatarSize/2, ap); }
                    else if (avatarShape == 1) { ac.drawRoundRect(new RectF(0,0,avatarSize,avatarSize), 20, 20, ap); }
                    else { 
                        Path p = new Path(); int cut = 30;
                        p.moveTo(cut, 0); p.lineTo(avatarSize-cut, 0); p.lineTo(avatarSize, cut); p.lineTo(avatarSize, avatarSize-cut);
                        p.lineTo(avatarSize-cut, avatarSize); p.lineTo(cut, avatarSize); p.lineTo(0, avatarSize-cut); p.lineTo(0, cut); p.close();
                        ac.drawPath(p, ap);
                    }
                    ap.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
                    ac.drawBitmap(scaledAvatar, 0, 0, ap);
                    canvas.drawBitmap(finalAvatar, curX, curY, null);
                    
                    Paint avatarStroke = new Paint(Paint.ANTI_ALIAS_FLAG);
                    avatarStroke.setStyle(Paint.Style.STROKE);
                    avatarStroke.setStrokeWidth((float)(Math.random()*4 + 2));
                    avatarStroke.setColor(Color.HSVToColor(new float[]{baseHue, 0.6f, isDark?1.0f:0.3f}));
                    if (avatarShape == 0) canvas.drawCircle(curX+avatarSize/2, curY+avatarSize/2, avatarSize/2, avatarStroke);
                    
                    scaledAvatar.recycle(); finalAvatar.recycle(); rawAvatar.recycle();
                }

                TextPaint namePaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                namePaint.setColor(isDark ? Color.WHITE : Color.parseColor("#111111"));
                namePaint.setTextSize(46);
                namePaint.setFakeBoldText(true);
                namePaint.setShadowLayer(2, 0, 1, isDark ? Color.parseColor("#4D000000") : Color.TRANSPARENT);

                TextPaint tagTextPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                tagTextPaint.setColor(Color.HSVToColor(new float[]{(baseHue+180)%360, 0.8f, isDark?1.0f:0.4f}));
                tagTextPaint.setTextSize(22);
                tagTextPaint.setFakeBoldText(true);

                TextPaint rightTopPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                rightTopPaint.setColor(isDark ? Color.parseColor("#80FFFFFF") : Color.parseColor("#66000000"));
                rightTopPaint.setTextSize(26);
                rightTopPaint.setTextAlign(Paint.Align.RIGHT);
                rightTopPaint.setTypeface(Typeface.MONOSPACE);

                TextPaint rightBotPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                rightBotPaint.setColor(isDark ? Color.parseColor("#B3FFFFFF") : Color.parseColor("#99000000"));
                rightBotPaint.setTextSize(28);
                rightBotPaint.setTextAlign(Paint.Align.RIGHT);
                rightBotPaint.setFakeBoldText(true);

                String dateStr = new java.text.SimpleDateFormat("yyyy/MM/dd HH:mm").format(new java.util.Date());
                String botText = "TGT:" + workUin;
                String randomTag = "ACT: " + actionName; 

                float rightTopW = rightTopPaint.measureText(dateStr);
                float rightBotW = rightBotPaint.measureText(botText);
                float maxRightW = Math.max(rightTopW, rightBotW) + 40; 
                int rightX = width - cardMargin - cardPadding; 
                int nameStartX = curX + avatarSize + 35;
                
                float maxNameW = rightX - nameStartX - maxRightW - 30; 
                if (maxNameW < 10) maxNameW = 10;
                String safeName = TextUtils.ellipsize(workNick, namePaint, maxNameW, TextUtils.TruncateAt.END).toString();

                float blockCenterY = curY + avatarSize / 2f;
                float nameY = blockCenterY - 10;
                float tagY = blockCenterY + 35;

                canvas.drawText(safeName, nameStartX, nameY, namePaint);

                Paint badgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                badgePaint.setColor(isDark ? Color.parseColor("#33FFFFFF") : Color.parseColor("#1A000000"));
                float tagTextW = tagTextPaint.measureText(randomTag);
                canvas.drawRoundRect(new RectF(nameStartX, tagY - 25, nameStartX + tagTextW + 20, tagY + 10), 8, 8, badgePaint);
                canvas.drawText(randomTag, nameStartX + 10, tagY - 2, tagTextPaint);

                canvas.drawText(dateStr, rightX, nameY - 5, rightTopPaint); 
                canvas.drawText(botText, rightX, tagY, rightBotPaint); 

                Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                dotPaint.setColor(Color.parseColor("#FF0055")); 
                dotPaint.setShadowLayer(10, 0, 0, dotPaint.getColor());
                canvas.drawCircle(rightX - rightBotW - 20, tagY - 10, 8, dotPaint);

                if (canDoGif) {
                    Bitmap bmpFrame = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                    Canvas canvasFrame = new Canvas(bmpFrame);
                    Paint alphaPaint = new Paint();
                    alphaPaint.setAlpha((int)(Math.random()*50 + 200)); 
                    canvasFrame.drawBitmap(bmpComposite, 0, 0, alphaPaint);

                    Paint clearPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                    clearPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
                    canvasFrame.drawRoundRect(picRect, 20, 20, clearPaint);
                    canvasFrame.drawRoundRect(picRect, 20, 20, strokePaint); 

                    String framePath = getScriptPath() + "/temp_frame.png";
                    FileOutputStream fosFrame = new FileOutputStream(framePath);
                    bmpFrame.compress(Bitmap.CompressFormat.PNG, 100, fosFrame);
                    fosFrame.flush(); fosFrame.close();
                    bmpFrame.recycle(); bmpComposite.recycle();

                    String outGif = getScriptPath() + "/temp_makeface_final.gif";
                    new File(outGif).delete();

                    String linker = new File("/system/bin/linker64").exists() ? "/system/bin/linker64 " : (new File("/system/bin/linker").exists() ? "/system/bin/linker " : "");
                    String filter = "[0:v]scale=" + targetPicWidth + ":" + targetPicHeight + "[sg];" +
                                    "[sg]pad=" + width + ":" + height + ":" + picX + ":" + picY + ":color=black@0[pg];" +
                                    "[pg][1:v]overlay=0:0[comp];" +
                                    "[comp]split[a][b];" +
                                    "[a]palettegen=max_colors=256:stats_mode=diff[p];" +
                                    "[b][p]paletteuse=dither=bayer:bayer_scale=5:diff_mode=rectangle";
                    
                    String cmd = linker + ffmpegBin.getAbsolutePath() + " -y -i " + tempFile.getAbsolutePath() + " -i " + framePath + " -filter_complex \"" + filter + "\" -loop 0 " + outGif;

                    try {
                        Process p = Runtime.getRuntime().exec(new String[]{"sh", "-c", cmd});
                        new Thread(new Runnable(){public void run(){try{BufferedReader r=new BufferedReader(new InputStreamReader(p.getInputStream())); while(r.readLine()!=null);}catch(Throwable e){}}}).start();
                        new Thread(new Runnable(){public void run(){try{BufferedReader r=new BufferedReader(new InputStreamReader(p.getErrorStream())); while(r.readLine()!=null);}catch(Throwable e){}}}).start();
                        p.waitFor();
                    } catch (Throwable e) {}

                    new File(framePath).delete();
                    tempFile.delete();

                    act.runOnUiThread(new Runnable() {
                        public void run() {
                            hideGlassLoading();
                            if (new File(outGif).exists() && new File(outGif).length() > 0) {
                                send(contact, "[pic=" + outGif + "]");
                                Toast("恶搞画廊动图已发送！");
                            } else { Toast("动图底层压制失败"); }
                        }
                    });

                } else {
                    int inSampleSize = 1;
                    int maxDim = Math.max(srcW, srcH);
                    while ((maxDim / inSampleSize) > 1500) { inSampleSize *= 2; }
                    
                    BitmapFactory.Options loadOpts = new BitmapFactory.Options();
                    loadOpts.inSampleSize = inSampleSize;
                    Bitmap sourcePic = BitmapFactory.decodeFile(tempFile.getAbsolutePath(), loadOpts);
                    if (sourcePic != null) {
                        Bitmap scaledPic = Bitmap.createScaledBitmap(sourcePic, targetPicWidth, targetPicHeight, true);
                        Paint picPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                        BitmapShader picShader = new BitmapShader(scaledPic, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
                        Matrix matrix = new Matrix();
                        matrix.postTranslate(picX, picY);
                        picShader.setLocalMatrix(matrix);
                        picPaint.setShader(picShader);
                        canvas.drawRoundRect(picRect, 20, 20, picPaint); 
                        scaledPic.recycle(); sourcePic.recycle();
                    }
                    canvas.drawRoundRect(picRect, 20, 20, strokePaint);

                    Bitmap bmpFinal = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                    Canvas canvasFinal = new Canvas(bmpFinal);
                    Paint alphaPaint = new Paint();
                    alphaPaint.setAlpha((int)(Math.random()*50 + 200)); 
                    canvasFinal.drawBitmap(bmpComposite, 0, 0, alphaPaint);

                    String outPath = getScriptPath() + "/temp_makeface_final.png";
                    FileOutputStream fos = new FileOutputStream(outPath);
                    bmpFinal.compress(Bitmap.CompressFormat.PNG, 100, fos);
                    fos.flush(); fos.close();
                    
                    bmpComposite.recycle(); bmpFinal.recycle(); 
                    tempFile.delete();

                    act.runOnUiThread(new Runnable() {
                        public void run() {
                            hideGlassLoading();
                            send(contact, "[pic=" + outPath + "]");
                            Toast("静态恶搞卡片已发送！");
                        }
                    });
                }

            } catch (Exception e) {
                act.runOnUiThread(new Runnable() { public void run() { hideGlassLoading(); Toast("生成失败：" + e.getMessage()); }});
            }
        }
    }).start();
}

// ==========================================
// 文件：FaceConfig.java
// 恶搞表情包的指令库、分类字典与 API 路由
// ==========================================
import java.util.*;

String[] getMakeFaceCategories() {
    return new String[]{
        "热门互动", 
        "猫猫虫", 
        "二次元梗", 
        "沙雕搞怪"
    };
}

Map getMakeFaceData() {
    Map catData = new HashMap();
    
    catData.put("猫猫虫", new String[][]{ 
        {"举", "33"}, {"指", "34"}, {"撕", "35"}, {"蹭", "36"}, 
        {"煮", "38"}, {"砸", "39"}, {"顶", "102"}, {"吃", "246"}, {"寄生", "262"} 
    });
    
    catData.put("热门互动", new String[][]{ 
        {"撅", "Jue"}, {"锤", "100"}, {"抓", "96"}, {"敲", "129"}, 
        {"拍", "181"}, {"搓", "270"}, {"洗", "279"}, {"摸头", "184"}, 
        {"咬", "suck"}, {"舔", "200"}, {"丢", "95"}, {"踩", "242"} 
    });
    
    catData.put("二次元梗", new String[][]{ 
        {"波奇手稿", "29"}, {"智乃扔", "47"}, {"群青", "55"}, {"芙莉莲送", "87"}, 
        {"阿尼娅喜欢", "13"}, {"阿罗娜传递", "15"}, {"普拉娜吃", "188"}, {"原神启动", "91"}, 
        {"胡桃吃", "90"}, {"胡桃啃", "109"}, {"凉宫举", "101"}, {"穹妹", "212"} 
    });
    
    catData.put("沙雕搞怪", new String[][]{ 
        {"垃圾桶", "89"}, {"寻狗启事", "143"}, {"小丑", "50"}, {"急急国王", "116"}, 
        {"杰瑞盯", "114"}, {"毒瘾发作", "6"}, {"灰飞烟灭", "73"}, {"哈哈镜", "88"}, 
        {"验证码", "94"}, {"卖掉了", "236"}, {"致电", "297"}, {"防拐", "12"} 
    });
    
    return catData;
}

String buildMakeFaceUrl(String apiId, String targetUin) {
    if (apiId.equals("Jue")) {
        String selfUin = myUin != null ? myUin : "10000"; 
        return "https://api.xunhuisi.store/API/Face/Jue.php?touOne=" + selfUin + "&touTwo=" + targetUin;
    } 
    else if (apiId.equals("suck")) {
        return "https://api.bi71t5.cn/api/face_suck.php?QQ=" + targetUin;
    } 
    else {
        return "https://api.xunhuisi.store/API/Face/MakeFace.php?id=" + apiId + "&photo=" + targetUin;
    }
}
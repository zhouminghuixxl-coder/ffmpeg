import android.app.*;
import android.graphics.*;
import android.text.*;
import java.io.*;
import java.net.*;
import java.util.*;

String genRandomHex(int len) {
    String chars = "0123456789ABCDEF";
    StringBuilder sb = new StringBuilder();
    for(int i=0; i<len; i++) sb.append(chars.charAt((int)(Math.random() * 16)));
    return sb.toString();
}

// ========== 多路激进嗅探引擎 ==========
Bitmap fetchAnimeBackground(int targetW, int targetH) {
    ArrayList apiList = new ArrayList();
    apiList.add("https://t.alcy.cc/ycy");
    apiList.add("https://api.dujin.org/pic/ACG/");
    apiList.add("https://t.mwm.moe/pc");
    apiList.add("https://www.loliapi.com/acg/pc/");
    
    Collections.shuffle(apiList);
    
    for (int i = 0; i < apiList.size(); i++) {
        try {
            String apiUrl = (String) apiList.get(i);
            URL url = new URL(apiUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(2000); 
            conn.setReadTimeout(3000);    
            conn.setInstanceFollowRedirects(false); 
            conn.setRequestProperty("User-Agent", "Mozilla/5.0");
            
            int status = conn.getResponseCode();
            int redirects = 0;
            
            while ((status == 301 || status == 302 || status == 303 || status == 307 || status == 308) && redirects < 4) {
                String newUrl = conn.getHeaderField("Location");
                if (newUrl == null) break;
                if (newUrl.startsWith("//")) newUrl = "https:" + newUrl;
                
                url = new URL(newUrl);
                conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(2500);
                conn.setReadTimeout(4000);
                conn.setInstanceFollowRedirects(false);
                conn.setRequestProperty("User-Agent", "Mozilla/5.0");
                status = conn.getResponseCode();
                redirects++;
            }
            
            if (status == 200 || status == 206) {
                File tempFile = new File(getScriptPath(), "temp_api_bg_" + System.currentTimeMillis() + ".jpg");
                InputStream is = conn.getInputStream();
                FileOutputStream fos = new FileOutputStream(tempFile);
                byte[] buf = new byte[8192];
                int len;
                while((len = is.read(buf)) != -1) {
                    fos.write(buf, 0, len);
                }
                fos.close(); is.close();
                
                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(tempFile.getAbsolutePath(), opts);
                
                opts.inSampleSize = 1;
                if (opts.outHeight > targetH || opts.outWidth > targetW) {
                    int halfH = opts.outHeight / 2;
                    int halfW = opts.outWidth / 2;
                    while ((halfH / opts.inSampleSize) >= targetH && (halfW / opts.inSampleSize) >= targetW) {
                        opts.inSampleSize *= 2;
                    }
                }
                
                opts.inJustDecodeBounds = false;
                Bitmap bmp = BitmapFactory.decodeFile(tempFile.getAbsolutePath(), opts);
                tempFile.delete();
                
                if (bmp != null) return bmp; 
            }
        } catch (Exception e) {}
    }
    return null; 
}

void drawAnimeOrAuroraBackground(Canvas canvas, int width, int height, boolean isDark, float baseHue, boolean hasGrid, boolean hasParticles, Bitmap bgBitmap) {
    if (bgBitmap != null) {
        float scale = Math.max((float) width / bgBitmap.getWidth(), (float) height / bgBitmap.getHeight());
        Matrix matrix = new Matrix();
        matrix.postScale(scale, scale);
        matrix.postTranslate((width - bgBitmap.getWidth() * scale) / 2f, (height - bgBitmap.getHeight() * scale) / 2f);
        
        Paint bmpPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
        canvas.drawBitmap(bgBitmap, matrix, bmpPaint);
        
        Paint overlay = new Paint();
        overlay.setColor(isDark ? Color.parseColor("#99000000") : Color.parseColor("#4DFFFFFF"));
        canvas.drawRect(0, 0, width, height, overlay);
    } else {
        canvas.drawColor(Color.HSVToColor(new float[]{baseHue, isDark?0.5f:0.15f, isDark?0.1f:0.95f}));
        int glowCount = (int)(Math.random() * 4) + 2; 
        Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        for(int i = 0; i < glowCount; i++) {
            float gx = (float)(Math.random() * width);
            float gy = (float)(Math.random() * height);
            float gr = (float)(Math.random() * 600 + 400);
            float gHue = (baseHue + (float)(Math.random()*120 - 60)) % 360;
            int gColor = Color.HSVToColor(isDark ? 110 : 90, new float[]{gHue, 0.8f, 1.0f});
            glowPaint.setShader(new RadialGradient(gx, gy, gr, gColor, Color.TRANSPARENT, Shader.TileMode.CLAMP));
            canvas.drawCircle(gx, gy, gr, glowPaint);
        }
    }
    
    if (hasGrid) {
        Paint gridPaint = new Paint();
        gridPaint.setStrokeWidth((float)(Math.random() * 2 + 0.5f));
        gridPaint.setColor(isDark ? Color.parseColor("#1AFFFFFF") : Color.parseColor("#1A000000"));
        int gridGap = (int)(Math.random() * 60 + 40);
        for(int x=0; x<width; x+=gridGap) canvas.drawLine(x, 0, x, height, gridPaint);
        for(int y=0; y<height; y+=gridGap) canvas.drawLine(0, y, width, y, gridPaint);
    }
    if (hasParticles) {
        Paint ptPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        ptPaint.setColor(isDark ? Color.parseColor("#26FFFFFF") : Color.parseColor("#1A000000"));
        for(int i=0; i<40; i++) canvas.drawCircle((float)(Math.random()*width), (float)(Math.random()*height), (float)(Math.random()*15+5), ptPaint);
    }
}

// ========== 通用圆角头像绘制（无描边） ==========
void drawRoundedAvatar(Canvas canvas, Bitmap avatar, int x, int y, int size, int cornerRadius) {
    if (avatar == null) return;
    Bitmap scaledAvatar = Bitmap.createScaledBitmap(avatar, size, size, true);
    Bitmap roundedAvatar = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
    Canvas ac = new Canvas(roundedAvatar);
    Paint ap = new Paint(Paint.ANTI_ALIAS_FLAG);
    RectF rect = new RectF(0, 0, size, size);
    ac.drawRoundRect(rect, cornerRadius, cornerRadius, ap);
    ap.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
    ac.drawBitmap(scaledAvatar, 0, 0, ap);
    canvas.drawBitmap(roundedAvatar, x, y, null);
    scaledAvatar.recycle();
    roundedAvatar.recycle();
}

// ========== 从消息中获取视频文件路径 ==========
String getVideoFilePathFromMsg(Object msgRecord) {
    try {
        Object rawMsg = null;
        try {
            java.lang.reflect.Field f = msgRecord.getClass().getField("msg");
            rawMsg = f.get(msgRecord);
        } catch (Exception e) {
            rawMsg = msgRecord;
        }
        if (rawMsg == null) return null;
        
        Object elementsObj = rawMsg.getClass().getField("elements").get(rawMsg);
        if (elementsObj instanceof java.util.List) {
            java.util.List elements = (java.util.List) elementsObj;
            for (int i = 0; i < elements.size(); i++) {
                Object el = elements.get(i);
                Object videoEl = null;
                try {
                    videoEl = el.getClass().getField("videoElement").get(el);
                } catch (Exception e) {
                    continue;
                }
                if (videoEl != null) {
                    String videoMd5 = null;
                    try {
                        videoMd5 = (String) videoEl.getClass().getField("videoMd5").get(videoEl);
                    } catch (Exception e) {
                        return null;
                    }
                    if (videoMd5 == null || videoMd5.length() == 0) {
                        return null;
                    }
                    String baseDir = "/storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/MobileQQ/shortvideo/";
                    String videoDir = baseDir + videoMd5 + "/";
                    String[] exts = {".mp4", ".mov", ".avi", ".mkv", ".3gp"};
                    for (String ext : exts) {
                        String videoPath = videoDir + videoMd5 + ext;
                        File f = new File(videoPath);
                        if (f.exists()) {
                            return videoPath;
                        }
                    }
                    return null;
                }
            }
        }
    } catch (Exception e) {
        error("getVideoFilePathFromMsg 异常: " + e);
    }
    return null;
}

// ========== 辅助：获取视频尺寸 ==========
int[] getVideoDimensions(String videoPath) {
    int[] dims = {0, 0};
    try {
        String cmd = buildCmd("ffmpeg", "-i \"" + videoPath + "\" 2>&1 | grep Stream");
        String output = execCmdWaitLog(cmd, getScriptPath());
        java.util.regex.Pattern p = java.util.regex.Pattern.compile("Stream.*Video.* (\\d+)x(\\d+)");
        java.util.regex.Matcher m = p.matcher(output);
        if (m.find()) {
            dims[0] = Integer.parseInt(m.group(1));
            dims[1] = Integer.parseInt(m.group(2));
        }
    } catch (Exception e) {
        error("getVideoDimensions error: " + e);
    }
    return dims;
}

// ========== 生成视频卡片背景（动态高度） ==========
String[] generateVideoCardBackground(String uin, String nickname, Bitmap bgBitmap, int videoSrcW, int videoSrcH) {
    int baseWidth = 1080;
    int topAreaHeight = 180;
    int videoAreaWidth = 800;
    int videoAreaHeight = (int) ((float) videoAreaWidth * videoSrcH / videoSrcW);
    int bottomPadding = 60;
    int totalHeight = topAreaHeight + videoAreaHeight + bottomPadding;

    Bitmap bmp = Bitmap.createBitmap(baseWidth, totalHeight, Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(bmp);

    if (bgBitmap != null) {
        float scale = Math.max((float) baseWidth / bgBitmap.getWidth(), (float) totalHeight / bgBitmap.getHeight());
        Matrix matrix = new Matrix();
        matrix.postScale(scale, scale);
        matrix.postTranslate((baseWidth - bgBitmap.getWidth() * scale) / 2f, (totalHeight - bgBitmap.getHeight() * scale) / 2f);
        canvas.drawBitmap(bgBitmap, matrix, null);
        Paint overlay = new Paint();
        overlay.setColor(Color.parseColor("#99000000"));
        canvas.drawRect(0, 0, baseWidth, totalHeight, overlay);
    } else {
        canvas.drawColor(Color.parseColor("#2A2A2A"));
    }

    int cardMargin = 30;
    float cardRadius = 40;
    RectF cardRect = new RectF(cardMargin, cardMargin, baseWidth - cardMargin, totalHeight - cardMargin);
    Paint glassPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    glassPaint.setColor(Color.argb(150, 255, 255, 255));
    glassPaint.setShadowLayer(30, 0, 15, Color.parseColor("#66000000"));
    canvas.drawRoundRect(cardRect, cardRadius, cardRadius, glassPaint);

    Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    strokePaint.setStyle(Paint.Style.STROKE);
    strokePaint.setStrokeWidth(3);
    strokePaint.setColor(Color.parseColor("#80FFFFFF"));
    canvas.drawRoundRect(cardRect, cardRadius, cardRadius, strokePaint);

    Bitmap rawAvatar = null;
    String avatarPath = downloadAvatar(uin);
    if (avatarPath != null && !avatarPath.equals("") && new File(avatarPath).exists()) {
        rawAvatar = BitmapFactory.decodeFile(avatarPath);
    }

    int avatarSize = 80;
    int avatarX = cardMargin + 30;
    int avatarY = cardMargin + 30;
    if (rawAvatar != null) {
        drawRoundedAvatar(canvas, rawAvatar, avatarX, avatarY, avatarSize, 30);
        rawAvatar.recycle();
    }

    TextPaint namePaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    namePaint.setColor(Color.parseColor("#F0F0F0"));
    namePaint.setTypeface(Typeface.DEFAULT_BOLD);
    namePaint.setTextSize(36);
    namePaint.setFakeBoldText(true);
    namePaint.setShadowLayer(4, 0, 2, Color.parseColor("#80000000"));
    String displayName = nickname.length() > 12 ? nickname.substring(0, 12) + "..." : nickname;
    canvas.drawText(displayName, avatarX + avatarSize + 20, avatarY + avatarSize / 2 - 8, namePaint);

    TextPaint timePaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    timePaint.setColor(Color.parseColor("#CCFFFFFF"));
    timePaint.setTextSize(20);
    String dateStr = new java.text.SimpleDateFormat("yyyy/MM/dd HH:mm").format(new java.util.Date());
    canvas.drawText(dateStr, avatarX + avatarSize + 20, avatarY + avatarSize / 2 + 22, timePaint);

    TextPaint uidPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    uidPaint.setColor(Color.parseColor("#B3FFFFFF"));
    uidPaint.setTextSize(24);
    uidPaint.setTextAlign(Paint.Align.RIGHT);
    String uidText = "UID:" + uin;
    canvas.drawText(uidText, baseWidth - cardMargin - 30, avatarY + avatarSize / 2 - 2, uidPaint);

    TextPaint tagPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    tagPaint.setColor(Color.parseColor("#A18CD1"));
    tagPaint.setTextSize(18);
    tagPaint.setFakeBoldText(true);
    tagPaint.setTextAlign(Paint.Align.RIGHT);
    String[] prefixes = {"SYS", "NET", "LOG", "SEC"};
    String randomTag = prefixes[(int) (Math.random() * 4)] + "-" + genRandomHex(4);
    canvas.drawText(randomTag, baseWidth - cardMargin - 30, avatarY + avatarSize / 2 + 28, tagPaint);

    int videoX = (baseWidth - videoAreaWidth) / 2;
    int videoY = topAreaHeight + 10;
    if (videoY + videoAreaHeight > totalHeight - 10) {
        videoY = totalHeight - videoAreaHeight - 10;
    }
    RectF videoRect = new RectF(videoX, videoY, videoX + videoAreaWidth, videoY + videoAreaHeight);
    Paint videoBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    videoBgPaint.setColor(Color.argb(100, 0, 0, 0));
    canvas.drawRoundRect(videoRect, 20, 20, videoBgPaint);
    canvas.drawRoundRect(videoRect, 20, 20, strokePaint);

    String outPath = getScriptPath() + "/temp_video_bg.png";
    try {
        FileOutputStream fos = new FileOutputStream(outPath);
        bmp.compress(Bitmap.CompressFormat.PNG, 100, fos);
        fos.close();
    } catch (Exception e) {
        error("save video bg error: " + e);
    }
    bmp.recycle();

    return new String[]{outPath, String.valueOf(videoX), String.valueOf(videoY), String.valueOf(videoAreaWidth), String.valueOf(videoAreaHeight)};
}

// ========== 文本生成极光卡片（已修改） ==========
void processTextToGlassCard(Object msgRecord) {
    Activity act = getThreadActivity();
    if (act == null || act.isFinishing()) return;
    
    String text = getMsgText(msgRecord);
    if (text.equals("")) { Toast("未提取到有效文本"); return; }
    
    String uin = "";
    String nickname = "未知用户";
    try {
        uin = String.valueOf(msgRecord.getClass().getField("senderUin").get(msgRecord));
        nickname = (String) msgRecord.getClass().getField("sendNickName").get(msgRecord);
    } catch (Exception e) {}

    Object contact = getContact();
    if (contact == null) { Toast("请在聊天界面内使用"); return; }

    showGlassLoading(act, "正在推演程序化 UI DNA...");

    String workUin = uin;
    String workNick = nickname;
    String workText = text;

    Typeface[] fonts = {
        Typeface.DEFAULT,
        Typeface.DEFAULT_BOLD,
        Typeface.MONOSPACE,
        Typeface.SANS_SERIF,
        Typeface.SERIF
    };
    Typeface randomFont = fonts[(int)(Math.random() * fonts.length)];

    new Thread(new Runnable() {
        public void run() {
            try {
                final Bitmap[] bgBmpBox = {null};
                final boolean[] bgDone = {false};
                new Thread(new Runnable() {
                    public void run() {
                        bgBmpBox[0] = fetchAnimeBackground(1080, 1500);
                        bgDone[0] = true;
                    }
                }).start();

                String avatarPath = downloadAvatar(workUin);
                
                int width = 1080; 
                int cardMarginX = 80;
                int cardMarginY = 120;
                int cardPadding = 60;
                int avatarSize = (int)(Math.random() * 40 + 120);
                int gap = 50;
                
                boolean isDark = Math.random() > 0.4;
                float baseHue = (float)(Math.random() * 360);
                boolean hasGrid = Math.random() > 0.5;
                boolean hasParticles = Math.random() > 0.5;
                float cardRadius = (float)(Math.random() * 50 + 20);
                int glassAlpha = (int)(Math.random() * 80 + 30);
                
                TextPaint textPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                textPaint.setColor(Color.parseColor("#F0F0F0"));
                textPaint.setTypeface(randomFont);
                textPaint.setTextSize((float)(Math.random() * 10 + 45));
                textPaint.setShadowLayer(3, 0, 2, Color.parseColor("#66000000"));
                
                int maxTextWidth = width - (cardMarginX * 2) - (cardPadding * 2); 
                StaticLayout staticLayout = new StaticLayout(workText, textPaint, maxTextWidth, Layout.Alignment.ALIGN_NORMAL, 1.4f, 0.0f, false);
                int textHeight = staticLayout.getHeight();
                
                int watermarkHeight = 40;
                int cardHeight = cardPadding + avatarSize + gap + textHeight + gap + watermarkHeight + cardPadding;
                int height = cardHeight + (cardMarginY * 2); 

                act.runOnUiThread(new Runnable() { public void run() { showGlassLoading(act, "正在组装跨次元渲染流..."); }});

                int waitBg = 0;
                while (!bgDone[0] && waitBg++ < 60) {
                    try { Thread.sleep(100); } catch(Exception e){}
                }
                Bitmap bgBitmap = bgBmpBox[0];

                Bitmap bmpComposite = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(bmpComposite);
                
                drawAnimeOrAuroraBackground(canvas, width, height, isDark, baseHue, hasGrid, hasParticles, bgBitmap);
                
                RectF cardRect = new RectF(cardMarginX, cardMarginY, width - cardMarginX, height - cardMarginY);
                Paint glassCardPaint = new Paint(Paint.ANTI_ALIAS_FLAG); 
                glassCardPaint.setColor(isDark ? Color.argb(glassAlpha, 255, 255, 255) : Color.argb(glassAlpha, 0, 0, 0)); 
                glassCardPaint.setShadowLayer(30, 0, 15, Color.parseColor("#66000000")); 
                canvas.drawRoundRect(cardRect, cardRadius, cardRadius, glassCardPaint); 
                
                Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                strokePaint.setStyle(Paint.Style.STROKE);
                strokePaint.setStrokeWidth((float)(Math.random() * 4 + 1));
                strokePaint.setColor(isDark ? Color.parseColor("#4DFFFFFF") : Color.parseColor("#33000000")); 
                canvas.drawRoundRect(cardRect, cardRadius, cardRadius, strokePaint);
                
                int curY = cardMarginY + cardPadding;
                int curX = cardMarginX + cardPadding;

                Bitmap rawAvatar = null;
                if (!avatarPath.equals("")) {
                    try { rawAvatar = BitmapFactory.decodeFile(avatarPath); } catch (Exception e) {}
                }
                
                if (rawAvatar != null) {
                    drawRoundedAvatar(canvas, rawAvatar, curX, curY, avatarSize, dp(act, 20));
                    rawAvatar.recycle();
                }

                TextPaint namePaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                namePaint.setColor(Color.parseColor("#F0F0F0"));
                namePaint.setTypeface(Typeface.DEFAULT_BOLD);
                namePaint.setTextSize(46);
                namePaint.setFakeBoldText(true);
                namePaint.setShadowLayer(2, 0, 1, Color.parseColor("#4D000000"));

                TextPaint tagTextPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                tagTextPaint.setColor(Color.HSVToColor(new float[]{(baseHue+180)%360, 0.8f, isDark?1.0f:0.4f}));
                tagTextPaint.setTextSize(22);
                tagTextPaint.setFakeBoldText(true);

                TextPaint rightTopPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                rightTopPaint.setColor(isDark ? Color.parseColor("#80FFFFFF") : Color.parseColor("#66000000"));
                rightTopPaint.setTextSize(26);
                rightTopPaint.setTextAlign(Paint.Align.RIGHT);
                rightTopPaint.setTypeface(Typeface.MONOSPACE);

                TextPaint rightBotPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                rightBotPaint.setColor(isDark ? Color.parseColor("#B3FFFFFF") : Color.parseColor("#99000000"));
                rightBotPaint.setTextSize(28);
                rightBotPaint.setTextAlign(Paint.Align.RIGHT);
                rightBotPaint.setFakeBoldText(true);

                String dateStr = new java.text.SimpleDateFormat("yyyy/MM/dd HH:mm").format(new java.util.Date());
                String botText = "UID:" + workUin;
                String[] prefixArr = {"SYS-", "NET-", "LOG-", "SEC-"};
                String randomTag = prefixArr[(int)(Math.random()*4)] + genRandomHex(4);

                float rightTopW = rightTopPaint.measureText(dateStr);
                float rightBotW = rightBotPaint.measureText(botText);
                float maxRightW = Math.max(rightTopW, rightBotW) + 40; 
                int rightX = width - cardMarginX - cardPadding; 
                int nameStartX = curX + avatarSize + 35;
                
                float maxNameW = rightX - nameStartX - maxRightW - 30; 
                if (maxNameW < 10) maxNameW = 10;
                String safeName = TextUtils.ellipsize(workNick, namePaint, maxNameW, TextUtils.TruncateAt.END).toString();

                float blockCenterY = curY + avatarSize / 2f;
                float nameY = blockCenterY - 10;
                float tagY = blockCenterY + 35;

                canvas.drawText(safeName, nameStartX, nameY, namePaint);

                Paint badgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                badgePaint.setColor(isDark ? Color.parseColor("#33FFFFFF") : Color.parseColor("#1A000000"));
                float tagTextW = tagTextPaint.measureText(randomTag);
                canvas.drawRoundRect(new RectF(nameStartX, tagY - 25, nameStartX + tagTextW + 20, tagY + 10), 8, 8, badgePaint);
                canvas.drawText(randomTag, nameStartX + 10, tagY - 2, tagTextPaint);

                canvas.drawText(dateStr, rightX, nameY - 5, rightTopPaint); 
                canvas.drawText(botText, rightX, tagY, rightBotPaint); 

                Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                dotPaint.setColor(Color.HSVToColor(new float[]{baseHue, 0.8f, 1.0f}));
                dotPaint.setShadowLayer(8, 0, 0, dotPaint.getColor());
                canvas.drawCircle(rightX - rightBotW - 20, tagY - 10, 8, dotPaint);

                curY += avatarSize + gap;

                canvas.save();
                canvas.translate(curX, curY);
                staticLayout.draw(canvas);
                canvas.restore();
                
                curY += textHeight + gap;

                Paint waterPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                waterPaint.setColor(isDark ? Color.parseColor("#80FFFFFF") : Color.parseColor("#80000000")); 
                waterPaint.setTextSize(32);
                waterPaint.setTextAlign(Paint.Align.CENTER);
                String[] waters = {"Aurora Engine • Intercept Mode", "Project INFINITY • Blind Box"};
                canvas.drawText(waters[(int)(Math.random()*waters.length)], width / 2, curY + 30, waterPaint);

                Bitmap bmpFinal = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                Canvas canvasFinal = new Canvas(bmpFinal);
                Paint alphaPaint = new Paint();
                alphaPaint.setAlpha((int)(Math.random()*50 + 200)); 
                canvasFinal.drawBitmap(bmpComposite, 0, 0, alphaPaint);
                
                bmpComposite.recycle();
                if (bgBitmap != null) bgBitmap.recycle();
                
                String outPath = getScriptPath() + "/temp_glass_card.png";
                FileOutputStream fos = new FileOutputStream(outPath);
                bmpFinal.compress(Bitmap.CompressFormat.PNG, 100, fos); 
                fos.flush(); fos.close();
                bmpFinal.recycle();
                
                act.runOnUiThread(new Runnable() {
                    public void run() {
                        hideGlassLoading();
                        send(contact, "[pic=" + outPath + "]");
                        Toast("盲盒卡片已生成并发送！");
                    }
                });
                
            } catch (Exception e) {
                act.runOnUiThread(new Runnable() {
                    public void run() {
                        hideGlassLoading();
                        Toast("渲染失败: " + e.getMessage());
                    }
                });
            }
        }
    }).start();
}

// ========== 自身发送消息转卡片（已修改） ==========
void sendMyTextAsGlassCard(String workText, Object contact, Activity act) {
    if (act == null || act.isFinishing()) return;
    
    showGlassLoading(act, "正在提取宿主身份信息...");
    
    Typeface[] fonts = {
        Typeface.DEFAULT,
        Typeface.DEFAULT_BOLD,
        Typeface.MONOSPACE,
        Typeface.SANS_SERIF,
        Typeface.SERIF
    };
    Typeface randomFont = fonts[(int)(Math.random() * fonts.length)];

    new Thread(new Runnable() {
        public void run() {
            try {
                String workUin = myUin;
                String workNick = getString("cached_my_nick", "极光主理人"); 
                
                try {
                    com.tencent.common.app.BaseApplicationImpl appImpl = com.tencent.common.app.BaseApplicationImpl.getApplication();
                    mqq.app.AppRuntime app = appImpl.getRuntime();
                    if (workUin == null || workUin.equals("")) {
                        workUin = app.getAccount();
                    }
                    java.lang.reflect.Method m = app.getClass().getMethod("getCurrentNickname", new Class[0]);
                    String n = (String) m.invoke(app, new Object[0]);
                    if (n != null && n.length() > 0) {
                        workNick = n;
                        setData("cached_my_nick", n); 
                    }
                } catch (Exception e) {}
                
                if (workUin == null || workUin.equals("")) workUin = "10000";

                final Bitmap[] bgBmpBox = {null};
                final boolean[] bgDone = {false};
                new Thread(new Runnable() {
                    public void run() {
                        bgBmpBox[0] = fetchAnimeBackground(1080, 1500);
                        bgDone[0] = true;
                    }
                }).start();
                
                act.runOnUiThread(new Runnable() { public void run() { showGlassLoading(act, "正在内存中直连渲染头像..."); }});
                
                Bitmap rawAvatar = null;
                try {
                    URL url = new URL("http://q1.qlogo.cn/g?b=qq&nk=" + workUin + "&s=640");
                    java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
                    conn.setConnectTimeout(5000);
                    conn.setRequestProperty("Cache-Control", "no-cache");
                    conn.setRequestProperty("Pragma", "no-cache"); 
                    if (conn.getResponseCode() == 200) {
                        java.io.InputStream is = conn.getInputStream();
                        rawAvatar = BitmapFactory.decodeStream(is);
                        is.close();
                    }
                } catch (Exception e) {}
                
                int width = 1080; 
                int cardMarginX = 80;
                int cardMarginY = 120;
                int cardPadding = 60;
                int avatarSize = (int)(Math.random() * 40 + 120);
                int gap = 50;
                
                boolean isDark = Math.random() > 0.4;
                float baseHue = (float)(Math.random() * 360);
                boolean hasGrid = Math.random() > 0.5;
                boolean hasParticles = Math.random() > 0.5;
                float cardRadius = (float)(Math.random() * 50 + 20);
                int glassAlpha = (int)(Math.random() * 80 + 30);
                
                TextPaint textPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                textPaint.setColor(Color.parseColor("#F0F0F0"));
                textPaint.setTypeface(randomFont);
                textPaint.setTextSize((float)(Math.random() * 10 + 45));
                textPaint.setShadowLayer(3, 0, 2, Color.parseColor("#66000000"));
                
                int maxTextWidth = width - (cardMarginX * 2) - (cardPadding * 2); 
                StaticLayout staticLayout = new StaticLayout(workText, textPaint, maxTextWidth, Layout.Alignment.ALIGN_NORMAL, 1.4f, 0.0f, false);
                int textHeight = staticLayout.getHeight();
                
                int watermarkHeight = 40;
                int cardHeight = cardPadding + avatarSize + gap + textHeight + gap + watermarkHeight + cardPadding;
                int height = cardHeight + (cardMarginY * 2); 
                
                int waitBg = 0;
                while (!bgDone[0] && waitBg++ < 60) {
                    try { Thread.sleep(100); } catch(Exception e){}
                }
                Bitmap bgBitmap = bgBmpBox[0];

                Bitmap bmpComposite = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(bmpComposite);
                
                drawAnimeOrAuroraBackground(canvas, width, height, isDark, baseHue, hasGrid, hasParticles, bgBitmap);
                
                act.runOnUiThread(new Runnable() { public void run() { showGlassLoading(act, "正在组装最终的玻璃图层..."); }});
                
                RectF cardRect = new RectF(cardMarginX, cardMarginY, width - cardMarginX, height - cardMarginY);
                Paint glassCardPaint = new Paint(Paint.ANTI_ALIAS_FLAG); 
                glassCardPaint.setColor(isDark ? Color.argb(glassAlpha, 255, 255, 255) : Color.argb(glassAlpha, 0, 0, 0)); 
                glassCardPaint.setShadowLayer(30, 0, 15, Color.parseColor("#66000000")); 
                canvas.drawRoundRect(cardRect, cardRadius, cardRadius, glassCardPaint); 
                
                Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                strokePaint.setStyle(Paint.Style.STROKE);
                strokePaint.setStrokeWidth((float)(Math.random() * 4 + 1));
                strokePaint.setColor(isDark ? Color.parseColor("#4DFFFFFF") : Color.parseColor("#33000000")); 
                canvas.drawRoundRect(cardRect, cardRadius, cardRadius, strokePaint);
                
                int curY = cardMarginY + cardPadding;
                int curX = cardMarginX + cardPadding;

                if (rawAvatar != null) {
                    drawRoundedAvatar(canvas, rawAvatar, curX, curY, avatarSize, dp(act, 20));
                    rawAvatar.recycle();
                }

                TextPaint namePaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                namePaint.setColor(Color.parseColor("#F0F0F0"));
                namePaint.setTypeface(Typeface.DEFAULT_BOLD);
                namePaint.setTextSize(46);
                namePaint.setFakeBoldText(true);
                namePaint.setShadowLayer(2, 0, 1, Color.parseColor("#4D000000"));

                TextPaint tagTextPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                tagTextPaint.setColor(Color.HSVToColor(new float[]{(baseHue+180)%360, 0.8f, isDark?1.0f:0.4f}));
                tagTextPaint.setTextSize(22);
                tagTextPaint.setFakeBoldText(true);

                TextPaint rightTopPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                rightTopPaint.setColor(isDark ? Color.parseColor("#80FFFFFF") : Color.parseColor("#66000000"));
                rightTopPaint.setTextSize(26);
                rightTopPaint.setTextAlign(Paint.Align.RIGHT);
                rightTopPaint.setTypeface(Typeface.MONOSPACE);

                TextPaint rightBotPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                rightBotPaint.setColor(isDark ? Color.parseColor("#B3FFFFFF") : Color.parseColor("#99000000"));
                rightBotPaint.setTextSize(28);
                rightBotPaint.setTextAlign(Paint.Align.RIGHT);
                rightBotPaint.setFakeBoldText(true);

                String dateStr = new java.text.SimpleDateFormat("yyyy/MM/dd HH:mm").format(new java.util.Date());
                String botText = "UID:" + workUin;
                String[] prefixArr = {"SYS-", "NET-", "LOG-", "SEC-"};
                String randomTag = prefixArr[(int)(Math.random()*4)] + genRandomHex(4);

                float rightTopW = rightTopPaint.measureText(dateStr);
                float rightBotW = rightBotPaint.measureText(botText);
                float maxRightW = Math.max(rightTopW, rightBotW) + 40; 
                int rightX = width - cardMarginX - cardPadding; 
                int nameStartX = curX + avatarSize + 35;
                
                float maxNameW = rightX - nameStartX - maxRightW - 30; 
                if (maxNameW < 10) maxNameW = 10;
                String safeName = TextUtils.ellipsize(workNick, namePaint, maxNameW, TextUtils.TruncateAt.END).toString();

                float blockCenterY = curY + avatarSize / 2f;
                float nameY = blockCenterY - 10;
                float tagY = blockCenterY + 35;

                canvas.drawText(safeName, nameStartX, nameY, namePaint);

                Paint badgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                badgePaint.setColor(isDark ? Color.parseColor("#33FFFFFF") : Color.parseColor("#1A000000"));
                float tagTextW = tagTextPaint.measureText(randomTag);
                canvas.drawRoundRect(new RectF(nameStartX, tagY - 25, nameStartX + tagTextW + 20, tagY + 10), 8, 8, badgePaint);
                canvas.drawText(randomTag, nameStartX + 10, tagY - 2, tagTextPaint);

                canvas.drawText(dateStr, rightX, nameY - 5, rightTopPaint); 
                canvas.drawText(botText, rightX, tagY, rightBotPaint); 

                Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                dotPaint.setColor(Color.HSVToColor(new float[]{baseHue, 0.8f, 1.0f}));
                dotPaint.setShadowLayer(8, 0, 0, dotPaint.getColor());
                canvas.drawCircle(rightX - rightBotW - 20, tagY - 10, 8, dotPaint);

                curY += avatarSize + gap;

                canvas.save();
                canvas.translate(curX, curY);
                staticLayout.draw(canvas);
                canvas.restore();
                
                curY += textHeight + gap;

                Paint waterPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                waterPaint.setColor(isDark ? Color.parseColor("#80FFFFFF") : Color.parseColor("#80000000")); 
                waterPaint.setTextSize(32);
                waterPaint.setTextAlign(Paint.Align.CENTER);
                String[] waters = {"Aurora Engine • Intercept Mode", "Project INFINITY • Auto Card"};
                canvas.drawText(waters[(int)(Math.random()*waters.length)], width / 2, curY + 30, waterPaint);

                Bitmap bmpFinal = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                Canvas canvasFinal = new Canvas(bmpFinal);
                Paint alphaPaint = new Paint();
                alphaPaint.setAlpha((int)(Math.random()*50 + 200)); 
                canvasFinal.drawBitmap(bmpComposite, 0, 0, alphaPaint);
                
                bmpComposite.recycle();
                if (bgBitmap != null) bgBitmap.recycle();
                
                String outPath = getScriptPath() + "/temp_my_glass_card.png";
                FileOutputStream fos = new FileOutputStream(outPath);
                bmpFinal.compress(Bitmap.CompressFormat.PNG, 100, fos); 
                fos.flush(); fos.close();
                bmpFinal.recycle();
                
                act.runOnUiThread(new Runnable() {
                    public void run() {
                        hideGlassLoading();
                        send(contact, "[pic=" + outPath + "]");
                    }
                });
                
            } catch (Exception e) {
                act.runOnUiThread(new Runnable() {
                    public void run() {
                        hideGlassLoading();
                        Toast("拦截渲染失败: " + e.getMessage());
                    }
                });
            }
        }
    }).start();
}

// ========== 图片消息转卡片（已修改） ==========
void processImageToGlassCard(Object msgRecord) {
    Activity act = getThreadActivity();
    if (act == null || act.isFinishing()) return;
    Object contact = getContact();
    if (contact == null) { Toast("请在聊天界面内使用"); return; }

    String uin = "";
    String nickname = "未知用户";
    try {
        uin = String.valueOf(msgRecord.getClass().getField("senderUin").get(msgRecord));
        nickname = (String) msgRecord.getClass().getField("sendNickName").get(msgRecord);
    } catch (Throwable e) {}

    showGlassLoading(act, "正在跨域获取图片...");

    String workUin = uin;
    String workNick = nickname;

    Typeface[] fonts = {
        Typeface.DEFAULT,
        Typeface.DEFAULT_BOLD,
        Typeface.MONOSPACE,
        Typeface.SANS_SERIF,
        Typeface.SERIF
    };
    Typeface randomFont = fonts[(int)(Math.random() * fonts.length)];

    new Thread(new Runnable() {
        public void run() {
            try {
                final Bitmap[] bgBmpBox = {null};
                final boolean[] bgDone = {false};
                new Thread(new Runnable() {
                    public void run() {
                        bgBmpBox[0] = fetchAnimeBackground(1080, 1500);
                        bgDone[0] = true;
                    }
                }).start();

                String picUrl = "";
                Object rawMsg = null;
                try { rawMsg = msgRecord.getClass().getField("msg").get(msgRecord); } catch (Throwable e) { rawMsg = msgRecord; }

                if (rawMsg != null) {
                    Object elements = null;
                    try { elements = rawMsg.getClass().getField("elements").get(rawMsg); } catch (Throwable e) {}
                    if (elements instanceof java.util.List) {
                        java.util.List list = (java.util.List) elements;
                        for (int i = 0; i < list.size(); i++) {
                            Object el = list.get(i);
                            Object picEl = null;
                            try { picEl = el.getClass().getField("picElement").get(el); } catch (Throwable e) {} 
                            if (picEl != null) {
                                try { 
                                    String u = getpic(picEl); 
                                    picUrl = (u != null && u.startsWith("/download")) ? "https://multimedia.nt.qq.com.cn" + u : u;
                                    break; 
                                } catch (Throwable e) {}
                            }
                        }
                    }
                }

                if (picUrl == null || picUrl.equals("")) { act.runOnUiThread(new Runnable() { public void run() { Toast("无法提取图片链接"); }}); return; }
                if (picUrl.startsWith("//")) picUrl = "https:" + picUrl;
                else if (picUrl.startsWith("http://")) picUrl = picUrl.replace("http://", "https://");

                act.runOnUiThread(new Runnable() { public void run() { showGlassLoading(act, "正在执行底层安全下载..."); }});

                String path = getScriptPath();
                String tempName = "temp_glass_" + System.currentTimeMillis() + ".tmp";
                File tempFile = new File(path, tempName);
                if (tempFile.exists()) tempFile.delete();

                int r = -1;
                if (picUrl.startsWith("http")) r = download(picUrl, path + "/", tempName);
                else if (copy(picUrl, tempFile.getAbsolutePath())) r = 0;

                if (r == 0) { int wait = 0; while((!tempFile.exists() || tempFile.length() < 100) && wait++ < 50) { try { Thread.sleep(200); } catch (Throwable e) {} } }
                if (!tempFile.exists() || tempFile.length() < 100) { act.runOnUiThread(new Runnable() { public void run() { Toast("下载失败或被拦截"); }}); if (tempFile.exists()) tempFile.delete(); return; }

                boolean isGif = false;
                try {
                    FileInputStream fis = new FileInputStream(tempFile);
                    byte[] header = new byte[3]; fis.read(header); fis.close();
                    if (header[0] == 0x47 && header[1] == 0x49 && header[2] == 0x46) isGif = true;
                } catch (Throwable e) {}

                File ffmpegBin = new File(context.getFilesDir(), "libffmpeg.so");
                if (!ffmpegBin.exists()) ffmpegBin = new File(context.getFilesDir(), "ffmpeg");
                boolean canDoGif = isGif && ffmpegBin.exists();

                String avatarPath = downloadAvatar(workUin);

                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(tempFile.getAbsolutePath(), opts);
                int srcW = opts.outWidth;
                int srcH = opts.outHeight;
                if (srcW <= 0 || srcH <= 0) { act.runOnUiThread(new Runnable() { public void run() { Toast("无法获取图片尺寸"); }}); tempFile.delete(); return; }

                boolean isDark = Math.random() > 0.3;
                float baseHue = (float)(Math.random() * 360);
                boolean hasGrid = Math.random() > 0.6;
                boolean hasParticles = Math.random() > 0.5;
                float cardRadius = (float)(Math.random() * 40 + 20); 
                int glassAlpha = (int)(Math.random() * 60 + 30); 

                int width = 1080;
                int cardMargin = 80;
                int cardMarginX = cardMargin;
                int cardPadding = 50;
                int avatarSize = (int)(Math.random() * 40 + 120);
                
                int targetPicWidth = width - (cardMargin * 2) - (cardPadding * 2);
                int targetPicHeight = (int) (srcH * ((float) targetPicWidth / srcW));
                if (targetPicHeight > 1500) targetPicHeight = 1500;
                
                int bottomInfoHeight = avatarSize + 80; 
                int cardHeight = cardPadding + targetPicHeight + 60 + bottomInfoHeight + cardPadding;
                int height = cardHeight + (cardMargin * 2);

                act.runOnUiThread(new Runnable() { public void run() { showGlassLoading(act, canDoGif ? "演算程序化动态相框..." : "演算程序化静态相框..."); }});

                int waitBg = 0;
                while (!bgDone[0] && waitBg++ < 60) {
                    try { Thread.sleep(100); } catch(Exception e){}
                }
                Bitmap bgBitmap = bgBmpBox[0];

                Bitmap bmpComposite = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(bmpComposite);

                drawAnimeOrAuroraBackground(canvas, width, height, isDark, baseHue, hasGrid, hasParticles, bgBitmap);

                RectF cardRect = new RectF(cardMargin, cardMargin, width - cardMargin, height - cardMargin);
                Paint glassPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                glassPaint.setColor(isDark ? Color.argb(glassAlpha, 255, 255, 255) : Color.argb(glassAlpha, 0, 0, 0)); 
                glassPaint.setShadowLayer(30, 0, 15, Color.parseColor("#66000000"));
                canvas.drawRoundRect(cardRect, cardRadius, cardRadius, glassPaint);

                Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                strokePaint.setStyle(Paint.Style.STROKE);
                strokePaint.setStrokeWidth((float)(Math.random() * 4 + 1));
                strokePaint.setColor(isDark ? Color.parseColor("#4DFFFFFF") : Color.parseColor("#33000000"));
                canvas.drawRoundRect(cardRect, cardRadius, cardRadius, strokePaint);

                int picX = cardMargin + cardPadding;
                int picY = cardMargin + cardPadding;
                RectF picRect = new RectF(picX, picY, picX + targetPicWidth, picY + targetPicHeight);

                int curX = cardMarginX + cardPadding;
                int curY = picY + targetPicHeight + 60;
                
                Bitmap rawAvatar = null;
                if (!avatarPath.equals("")) {
                    try { rawAvatar = BitmapFactory.decodeFile(avatarPath); } catch (Exception e) {}
                }
                
                if (rawAvatar != null) {
                    drawRoundedAvatar(canvas, rawAvatar, curX, curY, avatarSize, dp(act, 20));
                    rawAvatar.recycle();
                }

                TextPaint namePaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                namePaint.setColor(Color.parseColor("#F0F0F0"));
                namePaint.setTypeface(Typeface.DEFAULT_BOLD);
                namePaint.setTextSize(46);
                namePaint.setFakeBoldText(true);
                namePaint.setShadowLayer(2, 0, 1, Color.parseColor("#4D000000"));

                TextPaint tagTextPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                tagTextPaint.setColor(Color.HSVToColor(new float[]{(baseHue+180)%360, 0.8f, isDark?1.0f:0.4f}));
                tagTextPaint.setTextSize(22);
                tagTextPaint.setFakeBoldText(true);

                TextPaint rightTopPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                rightTopPaint.setColor(isDark ? Color.parseColor("#80FFFFFF") : Color.parseColor("#66000000"));
                rightTopPaint.setTextSize(26);
                rightTopPaint.setTextAlign(Paint.Align.RIGHT);
                rightTopPaint.setTypeface(Typeface.MONOSPACE);

                TextPaint rightBotPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                rightBotPaint.setColor(isDark ? Color.parseColor("#B3FFFFFF") : Color.parseColor("#99000000"));
                rightBotPaint.setTextSize(28);
                rightBotPaint.setTextAlign(Paint.Align.RIGHT);
                rightBotPaint.setFakeBoldText(true);

                String dateStr = new java.text.SimpleDateFormat("yyyy/MM/dd HH:mm").format(new java.util.Date());
                String botText = "UID:" + workUin;
                String[] prefixArr = {"SYS-", "NET-", "LOG-", "SEC-"};
                String randomTag = prefixArr[(int)(Math.random()*4)] + genRandomHex(4);

                float rightTopW = rightTopPaint.measureText(dateStr);
                float rightBotW = rightBotPaint.measureText(botText);
                float maxRightW = Math.max(rightTopW, rightBotW) + 40; 
                int rightX = width - cardMarginX - cardPadding; 
                int nameStartX = curX + avatarSize + 35;
                
                float maxNameW = rightX - nameStartX - maxRightW - 30; 
                if (maxNameW < 10) maxNameW = 10;
                String safeName = TextUtils.ellipsize(workNick, namePaint, maxNameW, TextUtils.TruncateAt.END).toString();

                float blockCenterY = curY + avatarSize / 2f;
                float nameY = blockCenterY - 10;
                float tagY = blockCenterY + 35;

                canvas.drawText(safeName, nameStartX, nameY, namePaint);

                Paint badgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                badgePaint.setColor(isDark ? Color.parseColor("#33FFFFFF") : Color.parseColor("#1A000000"));
                float tagTextW = tagTextPaint.measureText(randomTag);
                canvas.drawRoundRect(new RectF(nameStartX, tagY - 25, nameStartX + tagTextW + 20, tagY + 10), 8, 8, badgePaint);
                canvas.drawText(randomTag, nameStartX + 10, tagY - 2, tagTextPaint);

                canvas.drawText(dateStr, rightX, nameY - 5, rightTopPaint); 
                canvas.drawText(botText, rightX, tagY, rightBotPaint); 

                Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                dotPaint.setColor(Color.HSVToColor(new float[]{baseHue, 0.8f, 1.0f}));
                dotPaint.setShadowLayer(8, 0, 0, dotPaint.getColor());
                canvas.drawCircle(rightX - rightBotW - 20, tagY - 10, 8, dotPaint);

                if (canDoGif) {
                    Bitmap bmpFrame = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                    Canvas canvasFrame = new Canvas(bmpFrame);
                    Paint alphaPaint = new Paint();
                    alphaPaint.setAlpha(220); 
                    canvasFrame.drawBitmap(bmpComposite, 0, 0, alphaPaint);

                    Paint clearPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                    clearPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
                    canvasFrame.drawRoundRect(picRect, 20, 20, clearPaint);
                    canvasFrame.drawRoundRect(picRect, 20, 20, strokePaint); 

                    String framePath = getScriptPath() + "/temp_frame.png";
                    FileOutputStream fosFrame = new FileOutputStream(framePath);
                    bmpFrame.compress(Bitmap.CompressFormat.PNG, 100, fosFrame);
                    fosFrame.flush(); fosFrame.close();
                    bmpFrame.recycle(); bmpComposite.recycle();

                    act.runOnUiThread(new Runnable() { public void run() { showGlassLoading(act, "正在调用底层引擎压制动图..."); }});

                    String outGif = getScriptPath() + "/temp_glass_card.gif";
                    new File(outGif).delete();

                    String filter = "[0:v]scale=" + targetPicWidth + ":" + targetPicHeight + "[sg];" +
                                    "[sg]pad=" + width + ":" + height + ":" + picX + ":" + picY + ":color=black@0[pg];" +
                                    "[pg][1:v]overlay=0:0[comp];" +
                                    "[comp]split[a][b];" +
                                    "[a]palettegen=max_colors=256:stats_mode=diff[p];" +
                                    "[b][p]paletteuse=dither=bayer:bayer_scale=5:diff_mode=rectangle";

                    String linker = new File("/system/bin/linker64").exists() ? "/system/bin/linker64 " : (new File("/system/bin/linker").exists() ? "/system/bin/linker " : "");
                    String cmd = linker + ffmpegBin.getAbsolutePath() + " -y -i " + tempFile.getAbsolutePath() + " -i " + framePath + " -filter_complex \"" + filter + "\" -loop 0 " + outGif;

                    try {
                        Process p = Runtime.getRuntime().exec(new String[]{"sh", "-c", cmd});
                        new Thread(new Runnable(){public void run(){try{BufferedReader r=new BufferedReader(new InputStreamReader(p.getInputStream())); while(r.readLine()!=null);}catch(Throwable e){}}}).start();
                        new Thread(new Runnable(){public void run(){try{BufferedReader r=new BufferedReader(new InputStreamReader(p.getErrorStream())); while(r.readLine()!=null);}catch(Throwable e){}}}).start();
                        p.waitFor();
                    } catch (Throwable e) {}

                    new File(framePath).delete();
                    tempFile.delete();
                    if (bgBitmap != null) bgBitmap.recycle();

                    act.runOnUiThread(new Runnable() {
                        public void run() {
                            if (new File(outGif).exists() && new File(outGif).length() > 0) {
                                send(contact, "[pic=" + outGif + "]");
                                Toast("程序化动态相框已发送！");
                            } else { Toast("动图底层压制失败"); }
                        }
                    });

                } else {
                    int inSampleSize = 1;
                    int maxDim = Math.max(srcW, srcH);
                    while ((maxDim / inSampleSize) > 1500) { inSampleSize *= 2; }
                    
                    BitmapFactory.Options loadOpts = new BitmapFactory.Options();
                    loadOpts.inSampleSize = inSampleSize;
                    Bitmap sourcePic = BitmapFactory.decodeFile(tempFile.getAbsolutePath(), loadOpts);
                    if (sourcePic != null) {
                        Bitmap scaledPic = Bitmap.createScaledBitmap(sourcePic, targetPicWidth, targetPicHeight, true);
                        Paint picPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                        BitmapShader picShader = new BitmapShader(scaledPic, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
                        Matrix matrix = new Matrix();
                        matrix.postTranslate(picX, picY);
                        picShader.setLocalMatrix(matrix);
                        picPaint.setShader(picShader);
                        canvas.drawRoundRect(picRect, 20, 20, picPaint); 
                        scaledPic.recycle(); sourcePic.recycle();
                    }
                    canvas.drawRoundRect(picRect, 20, 20, strokePaint);

                    Bitmap bmpFinal = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                    Canvas canvasFinal = new Canvas(bmpFinal);
                    Paint alphaPaint = new Paint();
                    alphaPaint.setAlpha(220); 
                    canvasFinal.drawBitmap(bmpComposite, 0, 0, alphaPaint);

                    String outPath = getScriptPath() + "/temp_glass_image.png";
                    FileOutputStream fos = new FileOutputStream(outPath);
                    bmpFinal.compress(Bitmap.CompressFormat.PNG, 100, fos);
                    fos.flush(); fos.close();
                    
                    bmpComposite.recycle(); bmpFinal.recycle(); 
                    tempFile.delete();
                    if (bgBitmap != null) bgBitmap.recycle();

                    act.runOnUiThread(new Runnable() {
                        public void run() {
                            send(contact, "[pic=" + outPath + "]");
                            Toast("程序化静态相框已发送！");
                        }
                    });
                }
            } catch (Throwable e) { 
                String err = e.toString();
                act.runOnUiThread(new Runnable() { public void run() { Toast("渲染崩溃: " + err); }});
            } finally {
                act.runOnUiThread(new Runnable() {
                    public void run() { try { hideGlassLoading(); } catch (Throwable e) {} }
                });
            }
        }
    }).start();
}

// ========== 图文混合消息转卡片（已修改） ==========
void processImageTextToGlassCard(Object msgRecord) {
    Activity act = getThreadActivity();
    if (act == null || act.isFinishing()) return;
    Object contact = getContact();
    if (contact == null) { Toast("请在聊天界面内使用"); return; }

    String uin = "";
    String nickname = "未知用户";
    try {
        uin = String.valueOf(msgRecord.getClass().getField("senderUin").get(msgRecord));
        nickname = (String) msgRecord.getClass().getField("sendNickName").get(msgRecord);
    } catch (Throwable e) {}

    String extractedText = getMsgText(msgRecord); 
    if (extractedText == null || extractedText.trim().equals("")) { extractedText = " "; }

    showGlassLoading(act, "正在跨域分离图文轨...");

    String workUin = uin;
    String workNick = nickname;
    String workText = extractedText;

    Typeface[] fonts = {
        Typeface.DEFAULT,
        Typeface.DEFAULT_BOLD,
        Typeface.MONOSPACE,
        Typeface.SANS_SERIF,
        Typeface.SERIF
    };
    Typeface randomFont = fonts[(int)(Math.random() * fonts.length)];

    new Thread(new Runnable() {
        public void run() {
            try {
                final Bitmap[] bgBmpBox = {null};
                final boolean[] bgDone = {false};
                new Thread(new Runnable() {
                    public void run() {
                        bgBmpBox[0] = fetchAnimeBackground(1080, 1500);
                        bgDone[0] = true;
                    }
                }).start();

                String picUrl = "";
                Object rawMsg = null;
                try { rawMsg = msgRecord.getClass().getField("msg").get(msgRecord); } catch (Throwable e) { rawMsg = msgRecord; }
                if (rawMsg != null) {
                    Object elements = null;
                    try { elements = rawMsg.getClass().getField("elements").get(rawMsg); } catch (Throwable e) {}
                    if (elements instanceof java.util.List) {
                        java.util.List list = (java.util.List) elements;
                        for (int i = 0; i < list.size(); i++) {
                            Object el = list.get(i);
                            Object picEl = null;
                            try { picEl = el.getClass().getField("picElement").get(el); } catch (Throwable e) {}
                            if (picEl != null) {
                                try {
                                    String u = getpic(picEl);
                                    picUrl = (u != null && u.startsWith("/download")) ? "https://multimedia.nt.qq.com.cn" + u : u;
                                    break;
                                } catch (Throwable e) {}
                            }
                        }
                    }
                }

                if (picUrl == null || picUrl.equals("")) { act.runOnUiThread(new Runnable() { public void run() { Toast("无法提取图文中的图片链接"); }}); return; }
                if (picUrl.startsWith("//")) picUrl = "https:" + picUrl;
                else if (picUrl.startsWith("http://")) picUrl = picUrl.replace("http://", "https://");

                act.runOnUiThread(new Runnable() { public void run() { showGlassLoading(act, "正在执行底层安全下载..."); }});

                String path = getScriptPath();
                String tempName = "temp_glass_img_text_" + System.currentTimeMillis() + ".tmp";
                File tempFile = new File(path, tempName);
                if (tempFile.exists()) tempFile.delete();

                int r = -1;
                if (picUrl.startsWith("http")) r = download(picUrl, path + "/", tempName);
                else if (copy(picUrl, tempFile.getAbsolutePath())) r = 0;

                if (r == 0) { int wait = 0; while((!tempFile.exists() || tempFile.length() < 100) && wait++ < 50) { try { Thread.sleep(200); } catch (Throwable e) {} } }
                if (!tempFile.exists() || tempFile.length() < 100) { act.runOnUiThread(new Runnable() { public void run() { Toast("下载失败或被拦截"); }}); if (tempFile.exists()) tempFile.delete(); return; }

                String avatarPath = downloadAvatar(workUin);

                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(tempFile.getAbsolutePath(), opts);
                int srcW = opts.outWidth;
                int srcH = opts.outHeight;
                if (srcW <= 0 || srcH <= 0) { act.runOnUiThread(new Runnable() { public void run() { Toast("无法获取图片尺寸"); }}); tempFile.delete(); return; }

                boolean isDark = Math.random() > 0.4;
                float baseHue = (float)(Math.random() * 360);
                boolean hasGrid = Math.random() > 0.5;
                boolean hasParticles = Math.random() > 0.5;
                float cardRadius = (float)(Math.random() * 40 + 20); 
                int glassAlpha = (int)(Math.random() * 60 + 30); 

                int width = 1080;
                int cardMargin = 80;
                int cardMarginX = cardMargin;
                int cardPadding = 50;
                int avatarSize = (int)(Math.random() * 40 + 120); 
                int gap = 40;

                int targetContentWidth = width - (cardMargin * 2) - (cardPadding * 2);
                int targetPicHeight = (int) (srcH * ((float) targetContentWidth / srcW));
                if (targetPicHeight > 1500) targetPicHeight = 1500; 
                
                TextPaint textPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                textPaint.setColor(Color.parseColor("#F0F0F0"));
                textPaint.setTypeface(randomFont);
                textPaint.setTextSize(45);
                textPaint.setShadowLayer(3, 0, 2, Color.parseColor("#4D000000"));
                StaticLayout staticLayout = new StaticLayout(workText, textPaint, targetContentWidth, Layout.Alignment.ALIGN_NORMAL, 1.4f, 0.0f, false);
                int textHeight = staticLayout.getHeight();

                int watermarkHeight = 40; 
                int totalContentHeight = cardPadding + avatarSize + gap + targetPicHeight + gap + textHeight + gap + watermarkHeight + cardPadding;
                int height = (cardMargin * 2) + totalContentHeight;

                act.runOnUiThread(new Runnable() { public void run() { showGlassLoading(act, "正在渲染图文生成艺术排版..."); }});

                int waitBg = 0;
                while (!bgDone[0] && waitBg++ < 60) {
                    try { Thread.sleep(100); } catch(Exception e){}
                }
                Bitmap bgBitmap = bgBmpBox[0];

                Bitmap bmpComposite = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(bmpComposite);

                drawAnimeOrAuroraBackground(canvas, width, height, isDark, baseHue, hasGrid, hasParticles, bgBitmap);

                RectF cardRect = new RectF(cardMargin, cardMargin, width - cardMargin, height - cardMargin);
                Paint glassPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                glassPaint.setColor(isDark ? Color.argb(glassAlpha, 255, 255, 255) : Color.argb(glassAlpha, 0, 0, 0)); 
                glassPaint.setShadowLayer(30, 0, 15, Color.parseColor("#66000000"));
                canvas.drawRoundRect(cardRect, cardRadius, cardRadius, glassPaint);

                Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                strokePaint.setStyle(Paint.Style.STROKE);
                strokePaint.setStrokeWidth((float)(Math.random() * 4 + 1));
                strokePaint.setColor(isDark ? Color.parseColor("#4DFFFFFF") : Color.parseColor("#33000000"));
                canvas.drawRoundRect(cardRect, cardRadius, cardRadius, strokePaint);

                int curY = cardMargin + cardPadding;
                int curX = cardMargin + cardPadding;

                Bitmap rawAvatar = null;
                if (!avatarPath.equals("")) {
                    try { rawAvatar = BitmapFactory.decodeFile(avatarPath); } catch (Exception e) {}
                }
                
                if (rawAvatar != null) {
                    drawRoundedAvatar(canvas, rawAvatar, curX, curY, avatarSize, dp(act, 20));
                    rawAvatar.recycle();
                }

                TextPaint namePaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                namePaint.setColor(Color.parseColor("#F0F0F0"));
                namePaint.setTypeface(Typeface.DEFAULT_BOLD);
                namePaint.setTextSize(46);
                namePaint.setFakeBoldText(true);
                namePaint.setShadowLayer(2, 0, 1, Color.parseColor("#4D000000"));

                TextPaint tagTextPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                tagTextPaint.setColor(Color.HSVToColor(new float[]{(baseHue+180)%360, 0.8f, isDark?1.0f:0.4f}));
                tagTextPaint.setTextSize(22);
                tagTextPaint.setFakeBoldText(true);

                TextPaint rightTopPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                rightTopPaint.setColor(isDark ? Color.parseColor("#80FFFFFF") : Color.parseColor("#66000000"));
                rightTopPaint.setTextSize(26);
                rightTopPaint.setTextAlign(Paint.Align.RIGHT);
                rightTopPaint.setTypeface(Typeface.MONOSPACE);

                TextPaint rightBotPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                rightBotPaint.setColor(isDark ? Color.parseColor("#B3FFFFFF") : Color.parseColor("#99000000"));
                rightBotPaint.setTextSize(28);
                rightBotPaint.setTextAlign(Paint.Align.RIGHT);
                rightBotPaint.setFakeBoldText(true);

                String dateStr = new java.text.SimpleDateFormat("yyyy/MM/dd HH:mm").format(new java.util.Date());
                String botText = "UID:" + workUin;
                String[] prefixArr = {"SYS-", "NET-", "LOG-", "SEC-"};
                String randomTag = prefixArr[(int)(Math.random()*4)] + genRandomHex(4);

                float rightTopW = rightTopPaint.measureText(dateStr);
                float rightBotW = rightBotPaint.measureText(botText);
                float maxRightW = Math.max(rightTopW, rightBotW) + 40; 
                int rightX = width - cardMarginX - cardPadding; 
                int nameStartX = curX + avatarSize + 35;
                
                float maxNameW = rightX - nameStartX - maxRightW - 30; 
                if (maxNameW < 10) maxNameW = 10;
                String safeName = TextUtils.ellipsize(workNick, namePaint, maxNameW, TextUtils.TruncateAt.END).toString();

                float blockCenterY = curY + avatarSize / 2f;
                float nameY = blockCenterY - 10;
                float tagY = blockCenterY + 35;

                canvas.drawText(safeName, nameStartX, nameY, namePaint);

                Paint badgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                badgePaint.setColor(isDark ? Color.parseColor("#33FFFFFF") : Color.parseColor("#1A000000"));
                float tagTextW = tagTextPaint.measureText(randomTag);
                canvas.drawRoundRect(new RectF(nameStartX, tagY - 25, nameStartX + tagTextW + 20, tagY + 10), 8, 8, badgePaint);
                canvas.drawText(randomTag, nameStartX + 10, tagY - 2, tagTextPaint);

                canvas.drawText(dateStr, rightX, nameY - 5, rightTopPaint); 
                canvas.drawText(botText, rightX, tagY, rightBotPaint); 

                Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                dotPaint.setColor(Color.HSVToColor(new float[]{baseHue, 0.8f, 1.0f}));
                dotPaint.setShadowLayer(8, 0, 0, dotPaint.getColor());
                canvas.drawCircle(rightX - rightBotW - 20, tagY - 10, 8, dotPaint);

                curY += avatarSize + gap;

                int inSampleSize = 1;
                int maxDim = Math.max(srcW, srcH);
                while ((maxDim / inSampleSize) > 1500) { inSampleSize *= 2; }
                BitmapFactory.Options loadOpts = new BitmapFactory.Options();
                loadOpts.inSampleSize = inSampleSize;
                Bitmap sourcePic = BitmapFactory.decodeFile(tempFile.getAbsolutePath(), loadOpts);
                if (sourcePic != null) {
                    Bitmap scaledPic = Bitmap.createScaledBitmap(sourcePic, targetContentWidth, targetPicHeight, true);
                    Paint picPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                    BitmapShader picShader = new BitmapShader(scaledPic, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
                    Matrix matrix = new Matrix();
                    matrix.postTranslate(curX, curY);
                    picShader.setLocalMatrix(matrix);
                    picPaint.setShader(picShader);
                    RectF picRect = new RectF(curX, curY, curX + targetContentWidth, curY + targetPicHeight);
                    canvas.drawRoundRect(picRect, 20, 20, picPaint);
                    canvas.drawRoundRect(picRect, 20, 20, strokePaint);
                    scaledPic.recycle(); sourcePic.recycle();
                }
                
                curY += targetPicHeight + gap;

                canvas.save();
                canvas.translate(curX, curY);
                staticLayout.draw(canvas);
                canvas.restore();
                
                curY += textHeight + gap;

                Paint waterPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                waterPaint.setColor(isDark ? Color.parseColor("#80FFFFFF") : Color.parseColor("#80000000"));
                waterPaint.setTextSize(35);
                waterPaint.setTextAlign(Paint.Align.CENTER);
                String[] waters = {"CyberCore • Image & Text", "Project INFINITY • Blind Box", "Aurora Engine • Multi-Track"};
                canvas.drawText(waters[(int)(Math.random()*waters.length)], width / 2, curY + 35, waterPaint);

                Bitmap bmpFinal = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                Canvas canvasFinal = new Canvas(bmpFinal);
                Paint alphaPaint = new Paint();
                alphaPaint.setAlpha((int)(Math.random()*50 + 200)); 
                canvasFinal.drawBitmap(bmpComposite, 0, 0, alphaPaint);

                String outPath = getScriptPath() + "/temp_glass_img_text.png";
                FileOutputStream fos = new FileOutputStream(outPath);
                bmpFinal.compress(Bitmap.CompressFormat.PNG, 100, fos);
                fos.flush(); fos.close();

                bmpComposite.recycle(); bmpFinal.recycle();
                tempFile.delete();
                if (bgBitmap != null) bgBitmap.recycle();

                act.runOnUiThread(new Runnable() {
                    public void run() {
                        send(contact, "[pic=" + outPath + "]");
                        Toast("盲盒图文卡片已发送！");
                    }
                });

            } catch (Throwable e) {
                String err = e.toString();
                act.runOnUiThread(new Runnable() { public void run() { Toast("渲染崩溃: " + err); }});
            } finally {
                act.runOnUiThread(new Runnable() { public void run() { try { hideGlassLoading(); } catch (Throwable e) {} } });
            }
        }
    }).start();
}

// ========== 视频转极光卡片（完整版） ==========
void videoToAuroraVideo(Object msgRecord) {
    Activity act = getThreadActivity();
    if (act == null || act.isFinishing()) return;
    Object contact = getContact();
    if (contact == null) { Toast("请在聊天窗口内使用"); return; }

    String uin = "";
    String nickname = "未知用户";
    try {
        uin = String.valueOf(msgRecord.getClass().getField("senderUin").get(msgRecord));
        nickname = (String) msgRecord.getClass().getField("sendNickName").get(msgRecord);
    } catch (Exception e) {}

    String videoPath = getVideoFilePathFromMsg(msgRecord);
    if (videoPath == null || videoPath.equals("")) {
        Toast("无法获取视频文件路径");
        return;
    }

    File videoFile = new File(videoPath);
    if (!videoFile.exists()) {
        Toast("原视频文件不存在: " + videoPath);
        return;
    }

    int[] videoDims = getVideoDimensions(videoPath);
    if (videoDims[0] == 0 || videoDims[1] == 0) {
        Toast("无法获取视频尺寸");
        return;
    }
    int srcW = videoDims[0];
    int srcH = videoDims[1];

    String workUin = uin;
    String workNick = nickname;
    String path = videoPath;

    showGlassLoading(act, "正在合成极光视频...");

    new Thread(new Runnable() {
        public void run() {
            try {
                String scriptDir = getScriptPath();
                
                final Bitmap[] bgBmpBox = {null};
                final boolean[] bgDone = {false};
                new Thread(new Runnable() {
                    public void run() {
                        bgBmpBox[0] = fetchAnimeBackground(1080, 720);
                        bgDone[0] = true;
                    }
                }).start();

                int waitBg = 0;
                while (!bgDone[0] && waitBg++ < 60) {
                    try { Thread.sleep(100); } catch(Exception e){}
                }
                Bitmap bgBitmap = bgBmpBox[0];
                
                String[] bgInfo = generateVideoCardBackground(workUin, workNick, bgBitmap, srcW, srcH);
                String bgPath = bgInfo[0];
                int videoX = Integer.parseInt(bgInfo[1]);
                int videoY = Integer.parseInt(bgInfo[2]);
                int videoW = Integer.parseInt(bgInfo[3]);
                int videoH = Integer.parseInt(bgInfo[4]);

                File bgFile = new File(bgPath);
                if (!bgFile.exists()) {
                    act.runOnUiThread(new Runnable() {
                        public void run() {
                            hideGlassLoading();
                            Toast("背景图生成失败");
                        }
                    });
                    return;
                }

                String outPath = scriptDir + "/out_video.mp4";
                new File(outPath).delete();

                String filter = "[1:v]scale=" + videoW + ":" + videoH + "[vid];" +
                                "[0:v][vid]overlay=" + videoX + ":" + videoY + "[outv]";
                String finalArgs = "-y -i \"" + bgPath + "\" -i \"" + path + "\" " +
                                   "-filter_complex \"" + filter + "\" -map \"[outv]\" -map 1:a " +
                                   "-c:v mpeg4 -c:a aac -shortest \"" + outPath + "\"";
                
                String log = execCmdWaitLog(buildCmd("ffmpeg", finalArgs), scriptDir);

                new File(bgPath).delete();
                if (bgBitmap != null) bgBitmap.recycle();

                final String finalLog = log;
                act.runOnUiThread(new Runnable() {
                    public void run() {
                        hideGlassLoading();
                        if (new File(outPath).exists() && new File(outPath).length() > 0) {
                            video(contact, outPath);
                            Toast("极光视频生成完毕！");
                        } else {
                            String logPath = scriptDir + "/ffmpeg_error.log";
                            try {
                                FileWriter fw = new FileWriter(logPath);
                                fw.write(finalLog);
                                fw.close();
                            } catch (Exception e) {}
                            String shortLog = finalLog.length() > 200 ? finalLog.substring(0,200) + "..." : finalLog;
                            Toast("合成失败！完整日志已保存到：" + logPath + "\n预览：" + shortLog);
                        }
                    }
                });

            } catch (Exception e) {
                String err = e.toString();
                act.runOnUiThread(new Runnable() {
                    public void run() {
                        hideGlassLoading();
                        Toast("系统崩溃: " + err);
                    }
                });
            } finally {
                act.runOnUiThread(new Runnable() {
                    public void run() { try { hideGlassLoading(); } catch(Exception e){} }
                });
            }
        }
    }).start();
}
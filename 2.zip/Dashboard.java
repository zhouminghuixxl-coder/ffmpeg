import android.app.*;
import android.content.*;
import android.view.*;
import android.widget.*;
import android.graphics.*;
import android.graphics.drawable.*;
import java.io.*;
import java.util.*;
import android.widget.VideoView;
import android.media.MediaPlayer;
import android.widget.FrameLayout;
import org.json.JSONObject;
import androidx.viewpager.widget.ViewPager;
import android.util.SparseArray;
import android.view.animation.TranslateAnimation;
import android.view.animation.Animation;

class VoicePanelLogic {
    Runnable refreshFiles;
    Runnable refreshTabs;
}

boolean checkLogin(Activity act, LinearLayout container) {
    if (GLOBAL_COOKIE == null) {
        container.removeAllViews();
        TextView tv = new TextView(act);
        tv.setText("需要登录才能查看歌单\n\n请点击下方按钮进行QQ授权登录。");
        tv.setTextColor(Theme.COLOR_TEXT_SUB);
        tv.setPadding(0, dp(act, 50), 0, dp(act, 20));
        tv.setGravity(Gravity.CENTER);
        container.addView(tv);

        TextView btn = makeGlassActionBtn(act, "立即登录", Theme.COLOR_PRIMARY);
        btn.setTextColor(Color.BLACK);
        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                new Thread(new Runnable() {
                    public void run() {
                        boolean ok = performQQLogin();
                        act.runOnUiThread(new Runnable() {
                            public void run() {
                                if (ok) { Toast("登录成功"); container.removeAllViews(); } 
                                else { Toast("登录失败，请重试"); }
                            }
                        });
                    }
                }).start();
            }
        });
        container.addView(btn);
        return false;
    }
    return true;
}

void showNeteaseSearchLayout(Activity act, LinearLayout container, Dialog dialog) {
    container.removeAllViews();

    int MODE_SEARCH = 0;
    int MODE_PLAYLIST = 1;
    int MODE_SONGLIST = 2;
    int[] currentMode = {MODE_SEARCH};

    String[] currentPlaylistId = {null};
    String[] currentPlaylistName = {null};

    android.os.Handler uiHandler = new android.os.Handler(android.os.Looper.getMainLooper());

    LinearLayout topBar = new LinearLayout(act);
    topBar.setOrientation(LinearLayout.HORIZONTAL);
    topBar.setGravity(Gravity.CENTER_VERTICAL);
    container.addView(topBar);

    LinearLayout leftContainer = new LinearLayout(act);
    leftContainer.setOrientation(LinearLayout.HORIZONTAL);
    leftContainer.setGravity(Gravity.CENTER_VERTICAL);
    LinearLayout.LayoutParams leftLp = new LinearLayout.LayoutParams(0, -2, 1.0f);
    leftLp.rightMargin = dp(act, 10);
    leftContainer.setLayoutParams(leftLp);
    topBar.addView(leftContainer);

    TextView modeBtn = new TextView(act);
    modeBtn.setText("切换歌单");
    modeBtn.setTextSize(12);
    modeBtn.setTextColor(Theme.COLOR_PRIMARY);
    modeBtn.setGravity(Gravity.CENTER);
    modeBtn.setPadding(dp(act, 12), dp(act, 8), dp(act, 12), dp(act, 8));
    modeBtn.setBackground(makeGlassDrawable(act, Color.parseColor("#33FFFFFF"), Theme.COLOR_GLASS_BORDER, 12));
    LinearLayout.LayoutParams modeBtnLp = new LinearLayout.LayoutParams(-2, -2);
    modeBtn.setLayoutParams(modeBtnLp);
    topBar.addView(modeBtn);

    LinearLayout resultList = new LinearLayout(act);
    resultList.setOrientation(LinearLayout.VERTICAL);
    resultList.setPadding(0, dp(act, 10), 0, 0);
    container.addView(resultList);

    EditText searchInput = makeGlassInput(act, "", "输入歌名/歌手...");
    searchInput.setPadding(dp(act, 15), dp(act, 8), dp(act, 15), dp(act, 8));
    LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(0, -2, 1.0f);
    inputLp.rightMargin = dp(act, 8);
    searchInput.setLayoutParams(inputLp);

    TextView searchBtn = new TextView(act);
    searchBtn.setText("搜");
    searchBtn.setTextSize(14);
    searchBtn.setTextColor(Theme.COLOR_PRIMARY);
    searchBtn.setGravity(Gravity.CENTER);
    searchBtn.setPadding(dp(act, 12), dp(act, 8), dp(act, 12), dp(act, 8));
    searchBtn.setBackground(makeGlassDrawable(act, Color.parseColor("#33FFFFFF"), Theme.COLOR_GLASS_BORDER, 12));
    LinearLayout.LayoutParams searchBtnLp = new LinearLayout.LayoutParams(-2, -2);
    searchBtn.setLayoutParams(searchBtnLp);

    TextView backBtn = new TextView(act);
    backBtn.setText("返回歌单");
    backBtn.setTextSize(12);
    backBtn.setTextColor(Theme.COLOR_PRIMARY);
    backBtn.setGravity(Gravity.CENTER);
    backBtn.setPadding(dp(act, 15), dp(act, 6), dp(act, 15), dp(act, 6));
    backBtn.setBackground(makeGlassDrawable(act, Color.parseColor("#33FFFFFF"), Theme.COLOR_GLASS_BORDER, 12));
    LinearLayout.LayoutParams backLp = new LinearLayout.LayoutParams(-2, -2);
    backLp.rightMargin = dp(act, 10);
    backBtn.setLayoutParams(backLp);

    TextView refreshSongsBtn = new TextView(act);
    refreshSongsBtn.setText("刷新");
    refreshSongsBtn.setTextSize(12);
    refreshSongsBtn.setTextColor(Theme.COLOR_PRIMARY);
    refreshSongsBtn.setGravity(Gravity.CENTER);
    refreshSongsBtn.setPadding(dp(act, 15), dp(act, 6), dp(act, 15), dp(act, 6));
    refreshSongsBtn.setBackground(makeGlassDrawable(act, Color.parseColor("#33FFFFFF"), Theme.COLOR_GLASS_BORDER, 12));
    LinearLayout.LayoutParams refreshSongsLp = new LinearLayout.LayoutParams(-2, -2);
    refreshSongsBtn.setLayoutParams(refreshSongsLp);

    Runnable updateTopBar = new Runnable() {
        public void run() {
            uiHandler.post(new Runnable() {
                public void run() {
                    leftContainer.removeAllViews();
                    if (currentMode[0] == MODE_SEARCH) {
                        leftContainer.addView(searchInput);
                        leftContainer.addView(searchBtn);
                        modeBtn.setText("切换歌单");
                        modeBtn.setVisibility(View.VISIBLE);
                    } else if (currentMode[0] == MODE_PLAYLIST) {
                        modeBtn.setText("切换搜歌");
                        modeBtn.setVisibility(View.VISIBLE);
                    } else if (currentMode[0] == MODE_SONGLIST) {
                        leftContainer.addView(backBtn);
                        leftContainer.addView(refreshSongsBtn);
                        modeBtn.setVisibility(View.GONE);
                    }
                }
            });
        }
    };

    void showMessage(String msg) {
        uiHandler.post(new Runnable() {
            public void run() {
                resultList.removeAllViews();
                TextView tv = new TextView(act);
                tv.setText(msg);
                tv.setTextColor(Theme.COLOR_TEXT_SUB);
                tv.setGravity(Gravity.CENTER);
                tv.setPadding(0, dp(act, 20), 0, 0);
                resultList.addView(tv);
            }
        });
    }

    Runnable loadPlaylists = new Runnable() {
        public void run() {
            showMessage("正在加载歌单...");
            if (CURRENT_UID == null) ensureUid();
            if (CURRENT_UID == null) {
                showMessage("获取用户信息超时，请重登");
                return;
            }

            ArrayList playlists = getUserPlaylists(CURRENT_UID);
            uiHandler.post(new Runnable() {
                public void run() {
                    resultList.removeAllViews();
                    if (playlists.size() == 0) {
                        showMessage("未读取到歌单");
                        return;
                    }
                    for (int i = 0; i < playlists.size(); i++) {
                        HashMap pl = (HashMap) playlists.get(i);
                        TextView item = new TextView(act);
                        String name = (String) pl.get("name");
                        name = (name.contains("喜欢的音乐")) ? "喜欢的音乐 " + name : name;
                        item.setText(name + "\n    " + pl.get("count") + "首");
                        item.setTextSize(14);
                        item.setTextColor(Theme.COLOR_TEXT_MAIN);
                        item.setPadding(dp(act, 15), dp(act, 12), dp(act, 15), dp(act, 12));
                        item.setBackground(makePressableGlass(act, Theme.COLOR_INPUT_BG, Color.parseColor("#4D000000"), Theme.COLOR_GLASS_BORDER, 12));
                        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
                        lp.bottomMargin = dp(act, 8);
                        item.setLayoutParams(lp);

                        HashMap currentPlaylist = pl;
                        item.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {
                                currentMode[0] = MODE_SONGLIST;
                                currentPlaylistId[0] = (String) currentPlaylist.get("id");
                                currentPlaylistName[0] = (String) currentPlaylist.get("name");
                                updateTopBar.run();
                                loadSongsForPlaylist(currentPlaylistId[0], currentPlaylistName[0]);
                            }
                        });
                        resultList.addView(item);
                    }
                }
            });
        }
    };

    void loadSongsForPlaylist(String playlistId, String playlistName) {
        String pid = playlistId;
        String pname = playlistName;
        showMessage("正在读取: " + pname);
        new Thread(new Runnable() {
            public void run() {
                ArrayList songs = getPlaylistSongs(pid);
                uiHandler.post(new Runnable() {
                    public void run() {
                        resultList.removeAllViews();
                        if (songs.size() == 0) {
                            showMessage("歌单内暂无歌曲");
                            return;
                        }
                        for (int j = 0; j < songs.size(); j++) {
                            HashMap song = (HashMap) songs.get(j);
                            TextView songItem = new TextView(act);
                            songItem.setText((j + 1) + ". " + song.get("name") + "\n    " + song.get("artist"));
                            songItem.setTextSize(14);
                            songItem.setTextColor(Theme.COLOR_TEXT_MAIN);
                            songItem.setPadding(dp(act, 15), dp(act, 12), dp(act, 15), dp(act, 12));
                            songItem.setBackground(makePressableGlass(act, Theme.COLOR_INPUT_BG, Color.parseColor("#4D000000"), Color.parseColor("#33FFFFFF"), 12));
                            LinearLayout.LayoutParams itemLp = new LinearLayout.LayoutParams(-1, -2);
                            itemLp.bottomMargin = dp(act, 8);
                            songItem.setLayoutParams(itemLp);
                            HashMap finalSong = song;
                            songItem.setOnClickListener(new View.OnClickListener() {
                                public void onClick(View v) {
                                    prepareAndPlay(finalSong);
                                }
                            });
                            resultList.addView(songItem);
                        }
                    }
                });
            }
        }).start();
    }

    searchBtn.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            if (currentMode[0] != MODE_SEARCH) return;
            String keyword = searchInput.getText().toString();
            if (keyword.length() == 0) return;
            showMessage("搜索中...");
            new Thread(new Runnable() {
                public void run() {
                    doSearch(keyword, resultList, dialog);
                }
            }).start();
        }
    });

    modeBtn.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            if (currentMode[0] == MODE_SEARCH) {
                currentMode[0] = MODE_PLAYLIST;
                updateTopBar.run();
                if (GLOBAL_COOKIE == null) {
                    uiHandler.post(new Runnable() {
                        public void run() {
                            resultList.removeAllViews();
                            TextView tv = new TextView(act);
                            tv.setText("需要登录才能查看歌单\n\n请点击下方按钮进行QQ授权登录。");
                            tv.setTextColor(Theme.COLOR_TEXT_SUB);
                            tv.setPadding(0, dp(act, 50), 0, dp(act, 20));
                            tv.setGravity(Gravity.CENTER);
                            resultList.addView(tv);

                            TextView loginBtn = makeGlassActionBtn(act, "立即登录", Theme.COLOR_PRIMARY);
                            loginBtn.setTextColor(Color.BLACK);
                            loginBtn.setOnClickListener(new View.OnClickListener() {
                                public void onClick(View v) {
                                    new Thread(new Runnable() {
                                        public void run() {
                                            boolean ok = performQQLogin();
                                            act.runOnUiThread(new Runnable() {
                                                public void run() {
                                                    if (ok) {
                                                        Toast("登录成功");
                                                        new Thread(loadPlaylists).start();
                                                    } else {
                                                        Toast("登录失败，请重试");
                                                    }
                                                }
                                            });
                                        }
                                    }).start();
                                }
                            });
                            resultList.addView(loginBtn);
                        }
                    });
                } else {
                    new Thread(loadPlaylists).start();
                }
            } else if (currentMode[0] == MODE_PLAYLIST) {
                currentMode[0] = MODE_SEARCH;
                updateTopBar.run();
                showMessage("请输入关键词搜索");
            }
        }
    });

    backBtn.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            if (currentMode[0] != MODE_SONGLIST) return;
            currentMode[0] = MODE_PLAYLIST;
            updateTopBar.run();
            new Thread(loadPlaylists).start();
        }
    });

    refreshSongsBtn.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            if (currentMode[0] != MODE_SONGLIST) return;
            if (currentPlaylistId[0] != null) {
                loadSongsForPlaylist(currentPlaylistId[0], currentPlaylistName[0]);
            } else {
                Toast("无法刷新，歌单信息丢失");
            }
        }
    });

    currentMode[0] = MODE_SEARCH;
    updateTopBar.run();
    showMessage("请输入关键词搜索");
}

void showVoiceLibraryLayout(Activity act, LinearLayout container, Dialog dialog, VoicePanelLogic logic) {
    container.removeAllViews();

    HorizontalScrollView tabScroll = new HorizontalScrollView(act);
    tabScroll.setHorizontalScrollBarEnabled(false);
    LinearLayout tabContainer = new LinearLayout(act);
    tabContainer.setOrientation(LinearLayout.HORIZONTAL);
    tabScroll.addView(tabContainer);
    container.addView(tabScroll, new LinearLayout.LayoutParams(-1, -2));

    EditText searchInput = makeGlassInput(act, "", "搜索当前目录下文件...");
    LinearLayout.LayoutParams lpSearch = new LinearLayout.LayoutParams(-1, -2);
    lpSearch.topMargin = dp(act, 10);
    lpSearch.bottomMargin = dp(act, 10);
    container.addView(searchInput, lpSearch);

    LinearLayout listContainer = new LinearLayout(act);
    listContainer.setOrientation(LinearLayout.VERTICAL);
    container.addView(listContainer, new LinearLayout.LayoutParams(-1, -2));

    logic.refreshFiles = new Runnable() {
    public void run() {
        listContainer.removeAllViews();
        if (UIState.dirList.isEmpty()) { updateListUI(listContainer, "请添加目录"); return; }
        if (UIState.currentDirIndex >= UIState.dirList.size()) UIState.currentDirIndex = 0;
        
        String path = (String) UIState.dirList.get(UIState.currentDirIndex);
        File dir = new File(path);
        
        if (!dir.exists()) {
            updateListUI(listContainer, "目录不存在:\n" + path);
            if (!dir.mkdirs()) return; 
        }

        File[] files = dir.listFiles();
        if (files != null) {
            String kw = searchInput.getText().toString().toLowerCase();
            boolean found = false;
            for (int i=0; i<files.length; i++) {
                File f = files[i];
                if (!f.isFile()) continue; // 跳过子目录
                
                // 判断是否为音频或视频文件
                boolean isAudio = isAudioFile(f.getAbsolutePath());
                boolean isVideo = isVideoFile(f.getAbsolutePath());
                if (!isAudio && !isVideo) continue; // 跳过非音视频文件
                
                // 关键词过滤
                if (f.getName().toLowerCase().contains(kw)) {
                    listContainer.addView(createGlassFileRow(act, f, this));
                    found = true;
                }
            }
            if (!found) updateListUI(listContainer, "暂无文件");
        }
    }
};

    logic.refreshTabs = new Runnable() {
        public void run() {
            tabContainer.removeAllViews();
            for (int i = 0; i < UIState.dirList.size(); i++) {
                final int idx = i;
                String path = (String) UIState.dirList.get(i);
                File f = new File(path);
                String name = f.getName();
                if (name.equals("")) name = "根目录";
                if (name.equals("yy")) name = "默认(yy)";

                TextView tab = new TextView(act);
                tab.setText(name);
                tab.setTextSize(12);
                tab.setPadding(dp(act, 15), dp(act, 6), dp(act, 15), dp(act, 6));
                tab.setGravity(Gravity.CENTER);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
                lp.rightMargin = dp(act, 8);
                tab.setLayoutParams(lp);

                if (i == UIState.currentDirIndex) {
                    tab.setTextColor(Color.BLACK);
                    tab.setTypeface(Typeface.DEFAULT_BOLD);
                    tab.setBackground(makeGlassDrawable(act, Theme.COLOR_PRIMARY, Theme.COLOR_PRIMARY, 14));
                } else {
                    tab.setTextColor(Theme.COLOR_TEXT_SUB);
                    tab.setTypeface(Typeface.DEFAULT);
                    tab.setBackground(makeGlassDrawable(act, Theme.COLOR_INPUT_BG, Theme.COLOR_GLASS_BORDER, 14));
                }

                tab.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        UIState.currentDirIndex = idx;
                        logic.refreshTabs.run(); logic.refreshFiles.run();
                    }
                });
                tabContainer.addView(tab);
            }

            TextView btnAdd = new TextView(act);
            btnAdd.setText("+");
            btnAdd.setTextSize(14);
            btnAdd.setTextColor(Theme.COLOR_PRIMARY);
            btnAdd.setGravity(Gravity.CENTER);
            btnAdd.setBackground(makeGlassDrawable(act, Theme.COLOR_INPUT_BG, Theme.COLOR_GLASS_BORDER, 14));
            btnAdd.setPadding(dp(act, 15), dp(act, 6), dp(act, 15), dp(act, 6));
            btnAdd.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    showAddPathDialog(act, new Runnable() {
                        public void run() { logic.refreshTabs.run(); logic.refreshFiles.run(); }
                    });
                }
            });
            tabContainer.addView(btnAdd);
        }
    };
    
    logic.refreshTabs.run();
    logic.refreshFiles.run();

    searchInput.addTextChangedListener(new android.text.TextWatcher() {
        public void afterTextChanged(android.text.Editable s) { logic.refreshFiles.run(); }
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
        public void onTextChanged(CharSequence s, int start, int before, int count) {}
    });
}

View createGlassFileRow(Context ctx, File file, Runnable refresh) {
    String safePath = file.getAbsolutePath();
    String safeName = file.getName();
    long safeSize = file.length();

    LinearLayout row = new LinearLayout(ctx);
    row.setOrientation(LinearLayout.HORIZONTAL);
    row.setBackground(makePressableGlass(ctx, Theme.COLOR_INPUT_BG, Color.parseColor("#4D000000"), Theme.COLOR_GLASS_BORDER, 10));
    row.setPadding(dp(ctx, 15), dp(ctx, 10), dp(ctx, 15), dp(ctx, 10));
    LinearLayout.LayoutParams lpRow = new LinearLayout.LayoutParams(-1, -2);
    lpRow.bottomMargin = dp(ctx, 8);
    row.setLayoutParams(lpRow);
    
    LinearLayout info = new LinearLayout(ctx);
    info.setOrientation(LinearLayout.VERTICAL);
    info.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
    info.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            if (isVideoFile(safePath)) {
                showVideoPlayerDialog(ctx, new File(safePath));
            } else {
                showPlayerDialog(ctx, new File(safePath));
            }
        }
    });

    TextView name = new TextView(ctx);
    name.setText(safeName);
    name.setTextSize(14);
    name.setTextColor(Theme.COLOR_TEXT_MAIN);
    name.setSingleLine(true);
    name.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
    info.addView(name);
    
    TextView size = new TextView(ctx);
    double sizeKb = safeSize / 1024.0;
    double sizeFix = (double)Math.round(sizeKb * 10) / 10.0;
    size.setText(sizeFix + " KB");
    size.setTextSize(11);
    size.setTextColor(Theme.COLOR_TEXT_SUB);
    info.addView(size);
    row.addView(info);

    TextView btnSend = new TextView(ctx);
    btnSend.setText("发送");
    btnSend.setTextColor(Color.BLACK);
    btnSend.setTextSize(12);
    btnSend.setTypeface(Typeface.DEFAULT_BOLD);
    btnSend.setBackground(makeGlassDrawable(ctx, Theme.COLOR_PRIMARY, Theme.COLOR_PRIMARY, 8));
    btnSend.setPadding(dp(ctx, 12), dp(ctx, 6), dp(ctx, 12), dp(ctx, 6));
    // 修复：使用文档提供的 voice 方法发送语音/音频文件
    btnSend.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            Object contact = getContact();
            if (contact == null) {
                Toast("请先进入聊天界面");
                return;
            }
            voice(contact, safePath);
        }
    });
    LinearLayout.LayoutParams lpSend = new LinearLayout.LayoutParams(-2, -2);
    lpSend.leftMargin = dp(ctx, 10);
    row.addView(btnSend, lpSend);

    File currentFile = new File(safePath);
    String parentPath = currentFile.getParent();
    if (parentPath != null && (parentPath.endsWith("/yy") || parentPath.endsWith("\\yy"))) {
        TextView btnDelete = new TextView(ctx);
        btnDelete.setText("删除");
        btnDelete.setTextColor(Theme.COLOR_DANGER);
        btnDelete.setPadding(dp(ctx, 12), dp(ctx, 5), dp(ctx, 0), dp(ctx, 5));
        btnDelete.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { new File(safePath).delete(); refresh.run(); }
        });
        row.addView(btnDelete);
    }
    return row;
}

void showEmoticonGalleryLayout(Activity act, LinearLayout container, Dialog dialog) {
    container.removeAllViews();
    
    String THUMB_DIR = getScriptPath() + "/emoticons/thumbs";
    String EMOJI_DIR = getScriptPath() + "/emoticons";
    File thumbDirFile = new File(THUMB_DIR);
    if (!thumbDirFile.exists()) thumbDirFile.mkdirs();
    
    File[] thumbFiles = thumbDirFile.listFiles();

    if (thumbFiles == null || thumbFiles.length == 0) {
        updateListUI(container, "画廊空空如也\n快去长按图片收录吧");
        return;
    }

    int columns = 3;
    LinearLayout currentRow = null;
    int screenWidth = act.getResources().getDisplayMetrics().widthPixels;
    int imageSize = (screenWidth - dp(act, 40 + 30 + 30 + 20)) / columns;

    for (int i = 0; i < thumbFiles.length; i++) {
        File thumbFile = thumbFiles[i];
        String origFileName = thumbFile.getName().replace("thumb_", "");
        String origPath = EMOJI_DIR + "/" + origFileName;

        if (i % columns == 0) {
            currentRow = new LinearLayout(act);
            currentRow.setOrientation(LinearLayout.HORIZONTAL);
            currentRow.setGravity(Gravity.CENTER_HORIZONTAL);
            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, -2);
            rowLp.bottomMargin = dp(act, 10);
            currentRow.setLayoutParams(rowLp);
            container.addView(currentRow);
        }

        ImageView iv = new ImageView(act);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setBackground(makeGlassDrawable(act, Theme.COLOR_INPUT_BG, Theme.COLOR_GLASS_BORDER, 8));
        iv.setPadding(dp(act, 4), dp(act, 4), dp(act, 4), dp(act, 4));

        try {
            Bitmap thumbBmp = BitmapFactory.decodeFile(thumbFile.getAbsolutePath());
            iv.setImageBitmap(thumbBmp);
        } catch (Exception e) {}

        LinearLayout.LayoutParams ivLp = new LinearLayout.LayoutParams(imageSize, imageSize);
        ivLp.rightMargin = (i % columns != columns - 1) ? dp(act, 10) : 0;
        iv.setLayoutParams(ivLp);

        iv.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showEmoticonDetail(act, origPath); 
            }
        });

        iv.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View v) {
                new java.io.File(origPath).delete();
                thumbFile.delete();
                Toast("已删除该表情");
                showEmoticonGalleryLayout(act, container, dialog); 
                return true;
            }
        });

        currentRow.addView(iv);
    }
}

View createMainDashboard(Activity act, Dialog dialog) {
    LinearLayout card = new LinearLayout(act);
    card.setOrientation(LinearLayout.VERTICAL);
    card.setBackground(makeAuroraBgRandom(act, 24)); 
    card.setPadding(dp(act, 20), dp(act, 25), dp(act, 20), dp(act, 20));

    LinearLayout header = new LinearLayout(act);
    header.setGravity(Gravity.CENTER_VERTICAL);
    TextView title = new TextView(act);
    title.setText("极光引擎空间");
    title.setTextSize(20);
    title.setTypeface(Typeface.DEFAULT_BOLD);
    title.setTextColor(Theme.COLOR_TEXT_MAIN);
    header.addView(title, new LinearLayout.LayoutParams(0, -2, 1.0f));

    TextView status = new TextView(act);
    status.setText(GLOBAL_COOKIE == null ? "未登录" : "VIP就绪");
    status.setTextSize(12);
    status.setTextColor(GLOBAL_COOKIE == null ? Theme.COLOR_TEXT_SUB : Theme.COLOR_PRIMARY);
    header.addView(status);
    card.addView(header);

    LinearLayout quickBar = new LinearLayout(act);
    quickBar.setOrientation(LinearLayout.HORIZONTAL);
    quickBar.setGravity(Gravity.CENTER_VERTICAL);
    quickBar.setPadding(0, dp(act, 15), 0, dp(act, 10));

    // 字转图片按钮
    TextView btnAutoCard = new TextView(act);
    LinearLayout.LayoutParams lpAutoCard = new LinearLayout.LayoutParams(-2, -2);
    lpAutoCard.leftMargin = dp(act, 10);
    btnAutoCard.setLayoutParams(lpAutoCard);
    btnAutoCard.setTextSize(11);
    btnAutoCard.setPadding(dp(act, 10), dp(act, 6), dp(act, 10), dp(act, 6));
    
    Runnable updateAutoCardUI = new Runnable() {
        public void run() {
            boolean isOn = getString("auto_quote_card", "false").equals("true");
            if (isOn) {
                btnAutoCard.setText("字转图:开");
                btnAutoCard.setTextColor(Color.BLACK);
                btnAutoCard.setBackground(makeGlassDrawable(act, Theme.COLOR_PRIMARY, Theme.COLOR_PRIMARY, 12));
            } else {
                btnAutoCard.setText("字转图:关");
                btnAutoCard.setTextColor(Theme.COLOR_TEXT_SUB);
                btnAutoCard.setBackground(makeGlassDrawable(act, Color.TRANSPARENT, Color.parseColor("#66FFFFFF"), 12));
            }
        }
    };
    updateAutoCardUI.run();
    
    btnAutoCard.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            boolean isOn = getString("auto_quote_card", "false").equals("true");
            setData("auto_quote_card", isOn ? "false" : "true");
            updateAutoCardUI.run();
            if (!isOn) {
                Toast("已开启！你发送的纯文本将被重铸为极光卡片");
            } else {
                Toast("已关闭极光卡片替换");
            }
        }
    });
    quickBar.addView(btnAutoCard);

    // 音乐发送模式按钮
    TextView btnMusicMode = new TextView(act);
    LinearLayout.LayoutParams lpMusicMode = new LinearLayout.LayoutParams(-2, -2);
    lpMusicMode.leftMargin = dp(act, 10);
    btnMusicMode.setLayoutParams(lpMusicMode);
    btnMusicMode.setTextSize(11);
    btnMusicMode.setPadding(dp(act, 10), dp(act, 6), dp(act, 10), dp(act, 6));
    
    Runnable updateMusicModeUI = new Runnable() {
        public void run() {
            String mode = getMusicSendMode();
            if (mode.equals("voice")) {
                btnMusicMode.setText("点歌：语音");
                btnMusicMode.setTextColor(Color.WHITE);
                btnMusicMode.setBackground(makeGlassDrawable(act, Theme.COLOR_PRIMARY, Theme.COLOR_PRIMARY, 12));
            } else if (mode.equals("file")) {
                btnMusicMode.setText("点歌：mp3");
                btnMusicMode.setTextColor(Color.WHITE);
                btnMusicMode.setBackground(makeGlassDrawable(act, Color.parseColor("#FF6EC7"), Color.parseColor("#FF6EC7"), 12));
            } else {
                btnMusicMode.setText("点歌：卡片");
                btnMusicMode.setTextColor(Color.WHITE);
                btnMusicMode.setBackground(makeGlassDrawable(act, Color.parseColor("#3B71FE"), Color.parseColor("#3B71FE"), 12));
            }
        }
    };
    updateMusicModeUI.run();
    
    btnMusicMode.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            String currentMode = getMusicSendMode();
            String newMode;
            
            if (currentMode.equals("voice")) {
                newMode = "file";
                Toast("切换到 mp3 文件模式");
            } else if (currentMode.equals("file")) {
                newMode = "card";
                Toast("切换到网易云卡片模式");
            } else {
                newMode = "voice";
                Toast("切换到语音模式");
            }
            
            setMusicSendMode(newMode);
            updateMusicModeUI.run();
        }
    });
    quickBar.addView(btnMusicMode);
    
    // 图片尺寸模式按钮
    TextView btnImageSize = new TextView(act);
    LinearLayout.LayoutParams lpImageSize = new LinearLayout.LayoutParams(-2, -2);
    lpImageSize.leftMargin = dp(act, 10);
    btnImageSize.setLayoutParams(lpImageSize);
    btnImageSize.setTextSize(11);
    btnImageSize.setPadding(dp(act, 10), dp(act, 6), dp(act, 10), dp(act, 6));

    Runnable updateImageSizeUI = new Runnable() {
        public void run() {
            String mode = getString("image_size_mode", "0");
            if (mode.equals("0")) {
                btnImageSize.setText("图片:原图");
                btnImageSize.setTextColor(Theme.COLOR_TEXT_SUB);
                btnImageSize.setBackground(makeGlassDrawable(act, Color.TRANSPARENT, Color.parseColor("#66FFFFFF"), 12));
            } else if (mode.equals("1")) {
                btnImageSize.setText("图片:最小");
                btnImageSize.setTextColor(Color.WHITE);
                btnImageSize.setBackground(makeGlassDrawable(act, Color.parseColor("#FF6EC7"), Color.parseColor("#FF6EC7"), 12));
            } else {
                btnImageSize.setText("图片:最大");
                btnImageSize.setTextColor(Color.WHITE);
                btnImageSize.setBackground(makeGlassDrawable(act, Color.parseColor("#3B71FE"), Color.parseColor("#3B71FE"), 12));
            }
        }
    };
    updateImageSizeUI.run();

    btnImageSize.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            String current = getString("image_size_mode", "0");
            String next;
            if (current.equals("0")) {
                next = "1";
                Toast("图片尺寸已设为最小");
            } else if (current.equals("1")) {
                next = "2";
                Toast("图片尺寸已设为最大");
            } else {
                next = "0";
                Toast("图片尺寸已恢复原图");
            }
            setData("image_size_mode", next);
            updateImageSizeUI.run();
        }
    });
    quickBar.addView(btnImageSize);
    
    // 图片外显开关按钮
    TextView btnImageShow = new TextView(act);
    LinearLayout.LayoutParams lpImageShow = new LinearLayout.LayoutParams(-2, -2);
    lpImageShow.leftMargin = dp(act, 10);
    btnImageShow.setLayoutParams(lpImageShow);
    btnImageShow.setTextSize(11);
    btnImageShow.setPadding(dp(act, 10), dp(act, 6), dp(act, 10), dp(act, 6));

    Runnable updateImageShowUI = new Runnable() {
        public void run() {
            boolean isOn = getString("image_show_text", "false").equals("true");
            if (isOn) {
                btnImageShow.setText("外显:开");
                btnImageShow.setTextColor(Color.WHITE);
                btnImageShow.setBackground(makeGlassDrawable(act, Theme.COLOR_PRIMARY, Theme.COLOR_PRIMARY, 12));
            } else {
                btnImageShow.setText("外显:关");
                btnImageShow.setTextColor(Theme.COLOR_TEXT_SUB);
                btnImageShow.setBackground(makeGlassDrawable(act, Color.TRANSPARENT, Color.parseColor("#66FFFFFF"), 12));
            }
        }
    };
    updateImageShowUI.run();

    btnImageShow.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            boolean isOn = getString("image_show_text", "false").equals("true");
            if (isOn) {
                setData("image_show_text", "false");
                Toast("图片外显已关闭");
            } else {
                setData("image_show_text", "true");
                Toast("图片外显已开启");
                ThreadPoolManager.runOnNetwork(new Runnable() {
                    public void run() {
                        fetchAndUpdate();
                    }
                });
            }
            updateImageShowUI.run();
        }
    });
    quickBar.addView(btnImageShow);

    // 视频解析开关按钮
    TextView btnVideoParse = new TextView(act);
    LinearLayout.LayoutParams lpVideoParse = new LinearLayout.LayoutParams(-2, -2);
    lpVideoParse.leftMargin = dp(act, 10);
    btnVideoParse.setLayoutParams(lpVideoParse);
    btnVideoParse.setTextSize(11);
    btnVideoParse.setPadding(dp(act, 10), dp(act, 6), dp(act, 10), dp(act, 6));

    Runnable updateVideoParseUI = new Runnable() {
        public void run() {
            boolean isOn = getString("video_parse_enabled", "true").equals("true");
            if (isOn) {
                btnVideoParse.setText("解析:开");
                btnVideoParse.setTextColor(Color.WHITE);
                btnVideoParse.setBackground(makeGlassDrawable(act, Theme.COLOR_PRIMARY, Theme.COLOR_PRIMARY, 12));
            } else {
                btnVideoParse.setText("解析:关");
                btnVideoParse.setTextColor(Theme.COLOR_TEXT_SUB);
                btnVideoParse.setBackground(makeGlassDrawable(act, Color.TRANSPARENT, Color.parseColor("#66FFFFFF"), 12));
            }
        }
    };
    updateVideoParseUI.run();

    btnVideoParse.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            boolean isOn = getString("video_parse_enabled", "true").equals("true");
            setData("video_parse_enabled", isOn ? "false" : "true");
            updateVideoParseUI.run();
            Toast(isOn ? "视频解析已关闭" : "视频解析已开启");
        }
    });
    quickBar.addView(btnVideoParse);
    
    card.addView(quickBar);

    LinearLayout navBar = new LinearLayout(act);
    navBar.setOrientation(LinearLayout.HORIZONTAL);
    navBar.setBackground(makeGlassDrawable(act, Theme.COLOR_INPUT_BG, Theme.COLOR_GLASS_BORDER, 15));
    navBar.setPadding(dp(act, 5), dp(act, 5), dp(act, 5), dp(act, 5));
    LinearLayout.LayoutParams lpNav = new LinearLayout.LayoutParams(-1, -2);
    lpNav.bottomMargin = dp(act, 15);
    navBar.setLayoutParams(lpNav);
    
    TextView tab1 = new TextView(act); tab1.setText("搜歌");
    TextView tab2 = new TextView(act); tab2.setText("播放库");
    TextView tab3 = new TextView(act); tab3.setText("表情包");

    LinearLayout contentArea = new LinearLayout(act);
    contentArea.setOrientation(LinearLayout.VERTICAL);
    ScrollView scroll = new ScrollView(act);
    scroll.setVerticalScrollBarEnabled(false);
    scroll.addView(contentArea);

    VoicePanelLogic vLogic = new VoicePanelLogic();

    Runnable resetTabs = new Runnable() {
        public void run() {
            tab1.setTextColor(Theme.COLOR_TEXT_SUB); tab1.setBackground(null); tab1.setTypeface(Typeface.DEFAULT);
            tab2.setTextColor(Theme.COLOR_TEXT_SUB); tab2.setBackground(null); tab2.setTypeface(Typeface.DEFAULT);
            tab3.setTextColor(Theme.COLOR_TEXT_SUB); tab3.setBackground(null); tab3.setTypeface(Typeface.DEFAULT);
        }
    };

    LinearLayout.LayoutParams lpTab = new LinearLayout.LayoutParams(0, dp(act, 35), 1.0f);
    
    tab1.setLayoutParams(lpTab); tab1.setGravity(Gravity.CENTER); tab1.setTextSize(13);
    tab1.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            resetTabs.run();
            tab1.setTextColor(Color.BLACK); tab1.setTypeface(Typeface.DEFAULT_BOLD);
            tab1.setBackground(makeGlassDrawable(act, Theme.COLOR_PRIMARY, Theme.COLOR_PRIMARY, 12));
            showNeteaseSearchLayout(act, contentArea, dialog);
        }
    });
    navBar.addView(tab1);

    tab2.setLayoutParams(lpTab); tab2.setGravity(Gravity.CENTER); tab2.setTextSize(13);
    tab2.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            resetTabs.run();
            tab2.setTextColor(Color.BLACK); tab2.setTypeface(Typeface.DEFAULT_BOLD);
            tab2.setBackground(makeGlassDrawable(act, Theme.COLOR_PRIMARY, Theme.COLOR_PRIMARY, 12));
            showVoiceLibraryLayout(act, contentArea, dialog, vLogic);
        }
    });
    navBar.addView(tab2);

    tab3.setLayoutParams(lpTab); tab3.setGravity(Gravity.CENTER); tab3.setTextSize(13);
    tab3.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            resetTabs.run();
            tab3.setTextColor(Color.BLACK); tab3.setTypeface(Typeface.DEFAULT_BOLD);
            tab3.setBackground(makeGlassDrawable(act, Theme.COLOR_PRIMARY, Theme.COLOR_PRIMARY, 12));
            showEmoticonGalleryLayout(act, contentArea, dialog);
        }
    });
    navBar.addView(tab3);
    
    card.addView(navBar);
    card.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1.0f));
    
    tab1.performClick();

    return card;
}
// ==========================================
// 文件：EmoticonManager.java
// 表情包图库与 OOM 防护引擎
// ==========================================
import android.app.*;
import android.content.*;
import android.view.*;
import android.widget.*;
import android.graphics.*;
import android.graphics.drawable.*;
import java.io.*;
import java.util.List;

String EMOJI_DIR = getScriptPath() + "/emoticons";
String THUMB_DIR = getScriptPath() + "/emoticons/thumbs";

void initEmojiDirs() {
    File d1 = new File(EMOJI_DIR);
    if (!d1.exists()) d1.mkdirs();
    File d2 = new File(THUMB_DIR);
    if (!d2.exists()) d2.mkdirs();
}

void generateThumbnail(String originalPath, String thumbPath) {
    try {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(originalPath, options);
        
        options.inSampleSize = calculateInSampleSize(options, 256, 256);
        options.inJustDecodeBounds = false;
        
        Bitmap thumbBitmap = BitmapFactory.decodeFile(originalPath, options);
        if (thumbBitmap != null) {
            FileOutputStream fos = new FileOutputStream(thumbPath);
            thumbBitmap.compress(Bitmap.CompressFormat.JPEG, 60, fos);
            fos.flush();
            fos.close();
            thumbBitmap.recycle();
        }
    } catch (Exception e) {}
}

int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
    final int height = options.outHeight;
    final int width = options.outWidth;
    int inSampleSize = 1;
    if (height > reqHeight || width > reqWidth) {
        final int halfHeight = height / 2;
        final int halfWidth = width / 2;
        while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
            inSampleSize *= 2;
        }
    }
    return inSampleSize;
}

void saveEmoticon(Object msgRecord) {
    Activity act = getThreadActivity();
    if (act == null || act.isFinishing()) return;
    
    initEmojiDirs();
    showGlassLoading(act, "正在获取图片源...");
    
    new Thread(new Runnable() {
        public void run() {
            try {
                String picUrl = "";
                Object rawMsg = null;
                
                try {
                    java.lang.reflect.Field f = msgRecord.getClass().getField("msg");
                    rawMsg = f.get(msgRecord);
                } catch (Exception e) {
                    rawMsg = msgRecord;
                }

                if (rawMsg != null) {
                    Object elements = rawMsg.getClass().getField("elements").get(rawMsg);
                    if (elements instanceof java.util.List) {
                        java.util.List list = (java.util.List) elements;
                        for (int i = 0; i < list.size(); i++) {
                            Object el = list.get(i);
                            Object picEl = el.getClass().getField("picElement").get(el);
                            if (picEl != null) {
                                try { picUrl = getpic(picEl); } catch (Exception e) {}
                                break; 
                            }
                        }
                    }
                }
                
                if (picUrl == null || picUrl.equals("")) {
                    act.runOnUiThread(new Runnable() { public void run() { hideGlassLoading(); Toast("无法提取原图真实链接"); }});
                    return;
                }

                act.runOnUiThread(new Runnable() { public void run() { showGlassLoading(act, "正在跨域下载图片流..."); }});

                if (picUrl.startsWith("//")) {
                    picUrl = "https:" + picUrl;
                }

                String ext = ".jpg";
                String lowerUrl = picUrl.toLowerCase();
                if (lowerUrl.contains(".gif") || lowerUrl.contains("tp=gif") || lowerUrl.contains("format=gif")) {
                    ext = ".gif";
                } else if (lowerUrl.contains(".png")) {
                    ext = ".png";
                }

                String fileName = "emoji_" + System.currentTimeMillis() + ext;
                String savePath = EMOJI_DIR + "/" + fileName;
                String thumbPath = THUMB_DIR + "/thumb_" + fileName;
                
                boolean isSuccess = false;
                
                if (picUrl.startsWith("http")) {
                    int res = download(picUrl, EMOJI_DIR, fileName);
                    isSuccess = (res == 0);
                } else {
                    isSuccess = copy(picUrl, savePath);
                }

                if (isSuccess && new java.io.File(savePath).exists()) {
                    generateThumbnail(savePath, thumbPath); 
                    act.runOnUiThread(new Runnable() {
                        public void run() { hideGlassLoading(); Toast("表情包已收录入库！"); }
                    });
                } else {
                    act.runOnUiThread(new Runnable() { public void run() { hideGlassLoading(); Toast("收录失败，连接被拒或路径无效:\n" + picUrl); }});
                }
            } catch (Exception e) {
                act.runOnUiThread(new Runnable() { public void run() { hideGlassLoading(); Toast("发生异常: " + e.getMessage()); }});
            }
        }
    }).start();
}

void showEmoticonGallery(Activity act) {
    if (act == null || act.isFinishing()) return;
    initEmojiDirs();
    
    Dialog d = new Dialog(act);
    d.requestWindowFeature(1);
    d.getWindow().setBackgroundDrawable(new ColorDrawable(0));
    
    FrameLayout outer = new FrameLayout(act);
    outer.setPadding(dp(act, 20), dp(act, 24), dp(act, 20), dp(act, 24));
    
    LinearLayout bgLayout = new LinearLayout(act);
    bgLayout.setOrientation(LinearLayout.VERTICAL);
    bgLayout.setBackground(createAuroraSpaceBg(act, 24));
    bgLayout.setPadding(dp(act, 15), dp(act, 25), dp(act, 15), dp(act, 25));
    
    LinearLayout glassCard = new LinearLayout(act);
    glassCard.setOrientation(LinearLayout.VERTICAL);
    glassCard.setBackground(createAeroGlass(act, "#33FFFFFF", "#80FFFFFF", 20));
    glassCard.setPadding(dp(act, 15), dp(act, 20), dp(act, 15), dp(act, 20));
    
    TextView head = new TextView(act);
    head.setText("极光画廊");
    head.setTextSize(20);
    head.setTextColor(Color.WHITE);
    head.getPaint().setFakeBoldText(true);
    head.setGravity(Gravity.CENTER);
    glassCard.addView(head);
    
    TextView subHead = new TextView(act);
    subHead.setText("点击预览 / 长按删除");
    subHead.setTextSize(12);
    subHead.setTextColor(Color.parseColor("#E6FFFFFF"));
    subHead.setGravity(Gravity.CENTER);
    subHead.setPadding(0, dp(act, 4), 0, dp(act, 20));
    glassCard.addView(subHead);
    
    ScrollView scroll = new ScrollView(act);
    scroll.setVerticalScrollBarEnabled(false);
    LinearLayout gridLayout = new LinearLayout(act);
    gridLayout.setOrientation(LinearLayout.VERTICAL);
    
    File[] thumbFiles = new File(THUMB_DIR).listFiles();
    if (thumbFiles == null || thumbFiles.length == 0) {
        TextView empty = new TextView(act);
        empty.setText("空空如也，快去长按图片收录吧");
        empty.setTextColor(Color.parseColor("#99FFFFFF"));
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(0, dp(act, 50), 0, dp(act, 50));
        gridLayout.addView(empty);
    } else {
        int columns = 3;
        LinearLayout currentRow = null;
        int screenWidth = act.getResources().getDisplayMetrics().widthPixels;
        int imageSize = (screenWidth - dp(act, 40 + 30 + 30 + 20)) / columns; 
        
        for (int i = 0; i < thumbFiles.length; i++) {
            File thumbFile = thumbFiles[i];
            String origFileName = thumbFile.getName().replace("thumb_", "");
            String origPath = EMOJI_DIR + "/" + origFileName;
            
            if (i % columns == 0) {
                currentRow = new LinearLayout(act);
                currentRow.setOrientation(LinearLayout.HORIZONTAL);
                currentRow.setGravity(Gravity.CENTER_HORIZONTAL);
                LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, -2);
                rowLp.bottomMargin = dp(act, 10);
                currentRow.setLayoutParams(rowLp);
                gridLayout.addView(currentRow);
            }
            
            ImageView iv = new ImageView(act);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackground(createAeroGlass(act, "#1AFFFFFF", "#66FFFFFF", 8));
            iv.setPadding(dp(act, 4), dp(act, 4), dp(act, 4), dp(act, 4));
            
            Bitmap thumbBmp = BitmapFactory.decodeFile(thumbFile.getAbsolutePath());
            iv.setImageBitmap(thumbBmp);
            
            LinearLayout.LayoutParams ivLp = new LinearLayout.LayoutParams(imageSize, imageSize);
            ivLp.rightMargin = (i % columns != columns - 1) ? dp(act, 10) : 0;
            iv.setLayoutParams(ivLp);
            
            iv.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    showEmoticonDetail(act, origPath);
                    d.dismiss();
                }
            });
            
            currentRow.addView(iv);
        }
    }
    
    scroll.addView(gridLayout);
    LinearLayout.LayoutParams lpScroll = new LinearLayout.LayoutParams(-1, -2);
    lpScroll.weight = 1.0f;
    scroll.setLayoutParams(lpScroll);
    glassCard.addView(scroll);
    
    TextView btnCancel = new TextView(act);
    btnCancel.setText("关闭画廊");
    btnCancel.setTextSize(14);
    btnCancel.setTextColor(Color.WHITE);
    btnCancel.setGravity(Gravity.CENTER);
    btnCancel.setBackground(createPressableAeroGlass(act, "#1A000000", "#33000000", "#4DFFFFFF", 50));
    LinearLayout.LayoutParams lpCancel = new LinearLayout.LayoutParams(-1, dp(act, 44));
    lpCancel.topMargin = dp(act, 15);
    btnCancel.setLayoutParams(lpCancel);
    btnCancel.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { d.dismiss(); } });
    glassCard.addView(btnCancel);
    
    bgLayout.addView(glassCard);
    outer.addView(bgLayout);
    d.setContentView(outer);
    d.getWindow().setLayout((int)(act.getResources().getDisplayMetrics().widthPixels * 0.90), (int)(act.getResources().getDisplayMetrics().heightPixels * 0.75));
    d.show();
}

void showEmoticonDetail(Activity act, String imagePath) {
    if (act == null || act.isFinishing()) return;
    Dialog d = new Dialog(act);
    d.requestWindowFeature(1);
    d.getWindow().setBackgroundDrawable(new ColorDrawable(0));
    
    LinearLayout root = new LinearLayout(act);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setBackground(createAuroraSpaceBg(act, 20));
    root.setPadding(dp(act, 20), dp(act, 30), dp(act, 20), dp(act, 30));
    
    boolean isGif = false;
    try {
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(imagePath, opts);
        if ("image/gif".equalsIgnoreCase(opts.outMimeType)) {
            isGif = true;
        }
    } catch (Exception e) {}

    View mediaView;
    if (isGif || imagePath.toLowerCase().endsWith(".gif")) {
        android.webkit.WebView webView = new android.webkit.WebView(act);
        webView.setBackgroundColor(Color.TRANSPARENT);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        
        android.webkit.WebSettings settings = webView.getSettings();
        settings.setAllowFileAccess(true);
        
        webView.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) { return true; } 
        });

        String html = "<html><body style=\"margin:0;padding:0;display:flex;justify-content:center;align-items:center;height:100%;\"><img src=\"file://" + imagePath + "\" style=\"max-width:100%;max-height:100%;\"/></body></html>";
        webView.loadDataWithBaseURL("file://", html, "text/html", "utf-8", null);
        mediaView = webView;
    } else {
        ImageView iv = new ImageView(act);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        try {
            Bitmap bmp = BitmapFactory.decodeFile(imagePath);
            iv.setImageBitmap(bmp);
        } catch (Exception e) {}
        mediaView = iv;
    }

    LinearLayout.LayoutParams lpMedia = new LinearLayout.LayoutParams(-1, dp(act, 300));
    lpMedia.bottomMargin = dp(act, 20);
    mediaView.setLayoutParams(lpMedia);
    root.addView(mediaView);
    
    TextView btnSend = new TextView(act);
    btnSend.setText("发送该表情");
    btnSend.setTextSize(16);
    btnSend.setTextColor(Color.parseColor("#A18CD1"));
    btnSend.getPaint().setFakeBoldText(true);
    btnSend.setGravity(Gravity.CENTER);
    btnSend.setBackground(createPressableAeroGlass(act, "#E6FFFFFF", "#CCCCCC", "#FFFFFF", 50));
    LinearLayout.LayoutParams lpSend = new LinearLayout.LayoutParams(-1, dp(act, 50));
    lpSend.bottomMargin = dp(act, 10);
    btnSend.setLayoutParams(lpSend);
    btnSend.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            d.dismiss();
            Object contact = getContact();
            if (contact != null) {
                send(contact, "[pic=" + imagePath + "]");
                Toast("表情包已发送！");
            } else {
                Toast("请在聊天界面内发送");
            }
        }
    });
    root.addView(btnSend);
    
    TextView btnCancel = new TextView(act);
    btnCancel.setText("返回");
    btnCancel.setTextSize(14);
    btnCancel.setTextColor(Color.WHITE);
    btnCancel.setGravity(Gravity.CENTER);
    btnCancel.setBackground(createPressableAeroGlass(act, "#1A000000", "#33000000", "#4DFFFFFF", 50));
    btnCancel.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(act, 44)));
    btnCancel.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) { d.dismiss(); } 
    });
    root.addView(btnCancel);
    
    d.setContentView(root);
    d.getWindow().setLayout((int)(act.getResources().getDisplayMetrics().widthPixels * 0.85), -2);
    d.show();
}

void openAuroraGallery() {
    Activity act = getThreadActivity();
    if (act != null && !act.isFinishing()) showEmoticonGallery(act);
}
// 自定义外显.java - 支持多备用文案链接
import java.util.*;
import java.lang.Thread;
import java.lang.reflect.Field;

String 当前外显 = "默认文案";

// 文案链接列表（按优先级排列）
String[] 文案链接列表 = {
    "https://v1.hitokoto.cn/?c=a&encode=text",          // 一言（二次元）
    "https://api.btstu.cn/yan/api.php?charset=utf-8&encode=text",  // 随机一言
    "https://api.lolimi.cn/API/shangg/api?type=text",   // 原链接（可能失效）
    "https://api.ixiaowai.cn/api/api.php?type=text"     // 备用
};

// 递归查找字段（反射用）
Field findField(Class clazz, String fieldName) {
    try {
        return clazz.getDeclaredField(fieldName);
    } catch (NoSuchFieldException e) {
        Class superClass = clazz.getSuperclass();
        if (superClass != null && superClass != Object.class) {
            return findField(superClass, fieldName);
        }
        return null;
    }
}

// 从API获取纯文本文案并更新语录.txt 和 当前外显
void fetchAndUpdate() {
    String tempFile = "temp.txt";
    boolean 下载成功 = false;
    String 成功文案 = null;

    for (int i = 0; i < 文案链接列表.length; i++) {
        String 链接 = 文案链接列表[i];
        try {
            // 下载到临时文件
            int dlResult = download(链接, getScriptPath(), tempFile);
            if (dlResult != 0) {
                continue;
            }

            String text = read(getScriptPath() + "/" + tempFile);
            if (text == null || text.trim().isEmpty()) {
                del(getScriptPath() + "/" + tempFile);
                continue;
            }

            text = text.trim();
            // 简单过滤掉HTML标签（如果有）
            if (text.startsWith("<!DOCTYPE") || text.startsWith("<html")) {
                continue;
            }

            成功文案 = text;
            下载成功 = true;
            break;
        } catch (Exception e) {
            // 忽略单个链接异常
        } finally {
            del(getScriptPath() + "/" + tempFile);
        }
    }

    if (下载成功 && 成功文案 != null) {
        String 语录路径 = getScriptPath() + "/语录.txt";
        if (write(语录路径, 成功文案)) {
            当前外显 = 成功文案;
        } else {
            error("写入语录.txt失败");
        }
    } else {
        error("所有文案链接均下载失败，保留原文案");
    }
}

// 初始化块
{
    try {
        String 语录路径 = getScriptPath() + "/语录.txt";
        String saved = read(语录路径);
        if (saved != null && !saved.isEmpty()) {
            当前外显 = saved.trim();
        }
        fetchAndUpdate();
        Toast("emo外显脚本已加载，当前文案：" + 当前外显);
    } catch (Exception e) {
        error("初始化异常：" + e.toString());
    }
}
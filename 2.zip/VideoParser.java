// VideoParser.java
// 视频解析模块 - 仅对自己发送的视频链接进行解析
import android.app.*;
import android.content.*;
import android.graphics.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.regex.*;

// 正则匹配视频链接
Pattern urlPattern = Pattern.compile("https?://(?:(?:www\\.)?douyin\\.com|v\\.douyin\\.com|iesdouyin\\.com|(?:www\\.)?kuaishou\\.com|v\\.kuaishou\\.com|www\\.kwai\\.com|b23\\.tv|(?:www\\.)?bilibili\\.com|(?:www\\.)?xiaohongshu\\.com|xhslink\\.com|(?:www\\.)?weishi\\.qq\\.com|(?:www\\.)?shipinhao\\.weixin\\.qq\\.com|(?:www\\.)?tiktok\\.com|vm\\.tiktok\\.com|vt\\.tiktok\\.com)[^\\s]*");

// 解析入口
void parseVideoIfNeeded(Object msg) {
    // 仅处理自己发送的消息
    boolean mySent = false;
    try { mySent = msg.MySent; } catch (Exception e) { return; }
    if (!mySent) return;

    // 获取消息文本
    String text = getMsgText(msg);
    if (text == null || text.isEmpty()) return;

    // 匹配链接
    Matcher m = urlPattern.matcher(text);
    if (!m.find()) return;

    // 检查开关
    if (!getString("video_parse_enabled", "true").equals("true")) return;

    String url = m.group();
    // 获取联系人
    Object contact = getContact();
    if (contact == null) {
        Toast("请先进入聊天界面");
        return;
    }
    long msgId = 0;
    try { msgId = (Long) msg.getClass().getField("msgId").get(msg); } catch (Exception e) {}

    // 在子线程中解析
    new Thread(new Runnable() {
        public void run() {
            parseAndSend(url, contact, msgId);
        }
    }).start();
}

void parseAndSend(String url, Object contact, long msgId) {
    try {
        // 清理缓存目录
        String cacheDir = getScriptPath() + "/video_cache/";
        File dir = new File(cacheDir);
        if (dir.exists()) {
            File[] files = dir.listFiles();
            if (files != null) for (File f : files) f.delete();
        } else {
            dir.mkdirs();
        }

        String videoUrl = null;
        List images = new ArrayList();

        // 1. 尝试 video-crack API
        try {
            String encoded = URLEncoder.encode(url, "UTF-8");
            String apiUrl = "http://47.99.158.118/video-crack/v2/parse?content=" + encoded;
            log("[视频解析] 尝试 video-crack API");
            String resp = httpGet(apiUrl);
            if (resp != null && !resp.isEmpty()) {
                // 格式: {"code":0,"data":{"url":"...","imageUrl":[...]}}
                String data = extractJsonObject(resp, "data");
                if (data != null) {
                    videoUrl = extractJsonString(data, "url");
                    if (videoUrl != null && !videoUrl.isEmpty()) {
                        log("[视频解析] video-crack 返回视频链接");
                    } else {
                        String imgArr = extractJsonArray(data, "imageUrl");
                        if (imgArr != null) {
                            images = parseJsonArray(imgArr);
                            if (!images.isEmpty()) {
                                log("[视频解析] video-crack 返回图片列表");
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            log("[视频解析] video-crack 异常: " + e);
        }

        // 2. 如果 video-crack 没获取到，尝试 guiguiya API
        if ((videoUrl == null || videoUrl.isEmpty()) && images.isEmpty()) {
            try {
                String encoded = URLEncoder.encode(url, "UTF-8");
                String apiUrl = "http://api.guiguiya.com/api/video_qsy/juhe?url=" + encoded;
                log("[视频解析] 尝试 guiguiya API");
                String resp = httpGet(apiUrl);
                if (resp != null && !resp.isEmpty()) {
                    // 格式: {"code":"200","data":{"url":"..."}}
                    String code = extractJsonString(resp, "code");
                    if ("200".equals(code)) {
                        String data = extractJsonObject(resp, "data");
                        if (data != null) {
                            videoUrl = extractJsonString(data, "url");
                            if (videoUrl != null && !videoUrl.isEmpty()) {
                                log("[视频解析] guiguiya 返回视频链接");
                            }
                        }
                    }
                }
            } catch (Exception e) {
                log("[视频解析] guiguiya 异常: " + e);
            }
        }

        // 3. 尝试 tangdouz API (专门处理抖音图文)
        if ((videoUrl == null || videoUrl.isEmpty()) && images.isEmpty()) {
            try {
                String encoded = URLEncoder.encode(url, "UTF-8");
                // 添加 type=json 参数以获取结构化数据
                String apiUrl = "https://api.tangdouz.com/dy.php?lj=" + encoded + "&type=json";
                log("[视频解析] 尝试 tangdouz API");
                String resp = httpGet(apiUrl);
                if (resp != null && !resp.isEmpty()) {
                    // 如果返回 JSON
                    if (resp.startsWith("{")) {
                        // 格式: {"video":"视频链接","img":["图1","图2"]}
                        videoUrl = extractJsonString(resp, "video");
                        if (videoUrl != null && !videoUrl.isEmpty()) {
                            log("[视频解析] tangdouz 返回视频链接");
                        } else {
                            String imgArr = extractJsonArray(resp, "img");
                            if (imgArr != null) {
                                images = parseJsonArray(imgArr);
                                if (!images.isEmpty()) {
                                    log("[视频解析] tangdouz 返回图片列表");
                                }
                            }
                        }
                    } 
                    // 如果是纯文本格式 (链接±img=...)
                    else if (resp.contains("±")) {
                        images = parseTangdouzRaw(resp);
                        if (!images.isEmpty()) {
                            log("[视频解析] tangdouz 返回图片列表(文本格式)");
                        }
                    }
                    // 如果是纯链接
                    else if (resp.startsWith("http")) {
                        videoUrl = resp.trim();
                        log("[视频解析] tangdouz 返回直接视频链接");
                    }
                }
            } catch (Exception e) {
                log("[视频解析] tangdouz 异常: " + e);
            }
        }

        // 如果仍未获取到内容，记录并退出
        if ((videoUrl == null || videoUrl.isEmpty()) && images.isEmpty()) {
            log("[视频解析] 所有API均未返回有效内容");
            return;
        }

        // 发送视频或图片
        if (videoUrl != null && !videoUrl.isEmpty()) {
            videoUrl = normalizeUrl(videoUrl);
            if (isValidUrl(videoUrl)) {
                String fileName = "video_" + System.currentTimeMillis() + ".mp4";
                String filePath = cacheDir + fileName;
                int ret = download(videoUrl, cacheDir, fileName);
                if (ret == 0 && new File(filePath).exists() && new File(filePath).length() > 1024) {
                    video(contact, filePath);
                    if (msgId != 0) recall(contact, msgId);
                    reply(contact, msgId, "已解析并发送视频");
                    log("[视频解析] 成功发送视频");
                } else {
                    log("[视频解析] 视频下载失败");
                }
            } else {
                log("[视频解析] 视频URL无效: " + videoUrl);
            }
        } else if (!images.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            int validCount = 0;
            for (int i = 0; i < images.size(); i++) {
                String imgUrl = (String) images.get(i);
                imgUrl = normalizeUrl(imgUrl);
                if (!isValidUrl(imgUrl)) {
                    log("[视频解析] 跳过无效图片URL");
                    continue;
                }
                String fileName = "img_" + System.currentTimeMillis() + "_" + i + ".jpg";
                String filePath = cacheDir + fileName;
                int ret = download(imgUrl, cacheDir, fileName);
                if (ret == 0 && new File(filePath).exists() && new File(filePath).length() > 1024) {
                    sb.append("[pic=").append(filePath).append("]");
                    validCount++;
                } else {
                    log("[视频解析] 图片下载失败");
                }
            }
            if (sb.length() > 0) {
                if (msgId != 0) recall(contact, msgId);
                send(contact, sb.toString());
                reply(contact, msgId, "已解析并发送" + validCount + "张图片");
                log("[视频解析] 成功发送 " + validCount + " 张图片");
            } else {
                log("[视频解析] 没有有效图片可发送");
            }
        }
    } catch (Exception e) {
        log("[视频解析] 异常: " + e);
    }
}

// 辅助：解析 tangdouz 返回的原始文本格式 (链接±img=...)
List parseTangdouzRaw(String raw) {
    List list = new ArrayList();
    String[] parts = raw.split("±");
    for (int i = 0; i < parts.length; i++) {
        String p = parts[i].trim();
        if (p.startsWith("img=")) {
            String u = p.substring(4);
            if (u != null && !u.isEmpty()) {
                list.add(u);
            }
        }
    }
    return list;
}

// 辅助：检查URL是否有效
boolean isValidUrl(String url) {
    if (url == null) return false;
    url = url.trim();
    if (url.length() < 10) return false;
    if (url.endsWith(",") || url.endsWith(".") || url.endsWith("?") || url.endsWith("=")) return false;
    if (url.indexOf(",") != -1 && url.indexOf(",") == url.length() - 1) return false;
    if (url.startsWith("http://") || url.startsWith("https://")) return true;
    return false;
}

// 辅助：规范化 URL，补全缺失的协议头
String normalizeUrl(String url) {
    if (url == null) return null;
    url = url.trim();
    if (url.startsWith("//")) return "https:" + url;
    if (url.startsWith("://")) return "https" + url;
    if (!url.startsWith("http://") && !url.startsWith("https://")) return "https://" + url;
    return url;
}

// 辅助：提取JSON中的对象
String extractJsonObject(String json, String key) {
    if (json == null || key == null) return null;
    String pattern = "\"" + key + "\"\\s*:\\s*\\{";
    int start = findPattern(json, pattern);
    if (start == -1) return null;
    int braceCount = 0;
    int end = start;
    int len = json.length();
    while (end < len) {
        char c = json.charAt(end);
        if (c == '{') braceCount++;
        else if (c == '}') {
            braceCount--;
            if (braceCount == 0) break;
        }
        end++;
        if (end >= len) break;
    }
    if (end >= len || braceCount != 0) return null;
    return json.substring(start, end + 1);
}

// 辅助：提取JSON中的字符串值
String extractJsonString(String json, String key) {
    if (json == null || key == null) return null;
    String pattern = "\"" + key + "\"\\s*:\\s*\"";
    int start = findPattern(json, pattern);
    if (start == -1) return null;
    start += pattern.length() - 1;
    if (start >= json.length()) return null;
    int end = start + 1;
    int len = json.length();
    while (end < len) {
        if (json.charAt(end) == '"' && json.charAt(end - 1) != '\\') break;
        end++;
    }
    if (end >= len) return null;
    return json.substring(start, end);
}

// 辅助：提取JSON数组内容（去掉括号）
String extractJsonArray(String json, String key) {
    if (json == null || key == null) return null;
    String pattern = "\"" + key + "\"\\s*:\\s*\\[";
    int start = findPattern(json, pattern);
    if (start == -1) return null;
    int bracketCount = 0;
    int end = start;
    int len = json.length();
    while (end < len) {
        char c = json.charAt(end);
        if (c == '[') bracketCount++;
        else if (c == ']') {
            bracketCount--;
            if (bracketCount == 0) break;
        }
        end++;
        if (end >= len) break;
    }
    if (end >= len || bracketCount != 0) return null;
    int arrStart = start + pattern.length() - 1;
    if (arrStart >= len) return null;
    if (arrStart > end) return null;
    return json.substring(arrStart, end + 1);
}

// 辅助：解析数组字符串为列表
List parseJsonArray(String arrStr) {
    List list = new ArrayList();
    if (arrStr == null) return list;
    arrStr = arrStr.trim();
    if (arrStr.startsWith("[") && arrStr.endsWith("]")) {
        arrStr = arrStr.substring(1, arrStr.length() - 1);
    }
    int pos = 0;
    int len = arrStr.length();
    while (pos < len) {
        int start = arrStr.indexOf('"', pos);
        if (start == -1) break;
        int end = start + 1;
        while (end < len) {
            if (arrStr.charAt(end) == '"' && arrStr.charAt(end - 1) != '\\') break;
            end++;
        }
        if (end < len) {
            String item = arrStr.substring(start + 1, end);
            if (item != null && item.trim().length() > 5) list.add(item);
            pos = end + 1;
        } else break;
    }
    return list;
}

// 辅助：查找正则位置
int findPattern(String text, String pattern) {
    if (text == null || pattern == null) return -1;
    try {
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(pattern);
        java.util.regex.Matcher m = p.matcher(text);
        if (m.find()) return m.start();
    } catch (Exception e) {
        log("[视频解析] 正则匹配异常: " + e);
    }
    return -1;
}
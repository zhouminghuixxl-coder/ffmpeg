import android.app.*;
import android.content.*;
import android.view.*;
import android.widget.*;
import android.graphics.*;
import android.graphics.drawable.*;
import java.io.*;
import android.widget.VideoView;
import android.widget.MediaController;
import android.media.MediaPlayer;

View makeGlassInputCard(Activity act, String label, String key, String hint) {
    LinearLayout box = new LinearLayout(act);
    box.setOrientation(LinearLayout.VERTICAL);
    box.addView(makeGlassLabel(act, label));
    EditText et = makeGlassInput(act, getString(key, ""), hint);
    et.addTextChangedListener(new android.text.TextWatcher() {
        public void afterTextChanged(android.text.Editable s) { setData(key, s.toString().trim()); }
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
        public void onTextChanged(CharSequence s, int start, int before, int count) {}
    });
    box.addView(et);
    return box;
}

View makeGlassSliderCard(Activity act, String label, String key, float def, float min, float max) {
    LinearLayout card = new LinearLayout(act);
    card.setOrientation(LinearLayout.VERTICAL);
    card.setBackground(makeGlassDrawable(act, Theme.COLOR_INPUT_BG, Theme.COLOR_GLASS_BORDER, 12)); 
    card.setPadding(dp(act, 15), dp(act, 12), dp(act, 15), dp(act, 10));
    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
    lp.bottomMargin = dp(act, 10);
    card.setLayoutParams(lp);

    LinearLayout head = new LinearLayout(act);
    head.setGravity(Gravity.CENTER_VERTICAL);
    
    TextView tvLabel = new TextView(act);
    tvLabel.setText(label);
    tvLabel.setTextSize(13f);
    tvLabel.setTextColor(Theme.COLOR_TEXT_MAIN);
    head.addView(tvLabel, new LinearLayout.LayoutParams(0, -2, 1.0f));

    TextView tvVal = new TextView(act); 
    String savedStr = getString(key, String.valueOf(def));
    float currentVal = 0f;
    try { currentVal = Float.parseFloat(savedStr); } catch(Exception e) { currentVal = def; }
    tvVal.setText(String.valueOf(currentVal));
    tvVal.setTextColor(Theme.COLOR_PRIMARY);
    tvVal.setTypeface(Typeface.DEFAULT_BOLD);
    head.addView(tvVal);
    card.addView(head);

    SeekBar sb = new SeekBar(act); 
    sb.setMax(100);
    sb.setThumb(getGlassSeekBarThumb(act));
    sb.setProgressDrawable(getGlassSeekBarTrack(act));
    sb.setPadding(dp(act, 10), dp(act, 15), dp(act, 10), dp(act, 5)); 
    sb.setMaxHeight(dp(act, 4)); 
    sb.setThumbOffset(dp(act, 9)); 

    int progress = (int) ((currentVal - min) / (max - min) * 100);
    sb.setProgress(progress);

    sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
        public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
            float val = (p / 100.0f) * (max - min) + min;
            val = (float)(Math.round(val * 10)) / 10;
            tvVal.setText(String.valueOf(val));
            setData(key, String.valueOf(val));
        }
        public void onStartTrackingTouch(SeekBar s) {}
        public void onStopTrackingTouch(SeekBar s) {}
    });
    card.addView(sb);
    return card;
}

void showGlassOptionSelector(Activity act, TextView displayView, String title, String key, String[] options) {
    if (act == null || act.isFinishing()) return;
    Dialog d = new Dialog(act); 
    d.requestWindowFeature(Window.FEATURE_NO_TITLE);
    LinearLayout root = new LinearLayout(act);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setBackground(makeAuroraBg(act, 20));
    root.setPadding(dp(act, 20), dp(act, 20), dp(act, 20), dp(act, 20));

    TextView tvTitle = new TextView(act);
    tvTitle.setText(title);
    tvTitle.setTypeface(Typeface.DEFAULT_BOLD);
    tvTitle.setTextColor(Theme.COLOR_TEXT_MAIN);
    tvTitle.setPadding(0, 0, 0, dp(act, 15));
    tvTitle.setGravity(Gravity.CENTER);
    root.addView(tvTitle);

    String current = getString(key, options[0]);

    for (int i = 0; i < options.length; i++) {
        String val = options[i]; 
        TextView item = new TextView(act);
        item.setText(val);
        item.setTextSize(15f);
        item.setPadding(dp(act, 20), dp(act, 12), dp(act, 20), dp(act, 12));
        item.setGravity(Gravity.CENTER);
        
        if (val.equals(current)) {
            item.setTextColor(Theme.COLOR_PRIMARY);
            item.setBackground(makeGlassDrawable(act, Color.parseColor("#3300FFD1"), Theme.COLOR_PRIMARY, 10));
        } else {
            item.setTextColor(Theme.COLOR_TEXT_MAIN);
            item.setBackground(makePressableGlass(act, Theme.COLOR_INPUT_BG, Color.parseColor("#4D000000"), Theme.COLOR_GLASS_BORDER, 10));
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(act, 8);
        item.setLayoutParams(lp);
        item.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                setData(key, val);
                displayView.setText(val + " 下拉");
                d.dismiss();
            }
        });
        root.addView(item);
    }
    d.setContentView(root);
    d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
    d.getWindow().setLayout((int)(act.getResources().getDisplayMetrics().widthPixels * 0.8), -2);
    d.show();
}

View makeGlassSelectCard(Activity act, String label, String key, String[] options, String def) {
    LinearLayout card = new LinearLayout(act);
    card.setOrientation(LinearLayout.HORIZONTAL);
    card.setGravity(Gravity.CENTER_VERTICAL);
    card.setBackground(makeGlassDrawable(act, Theme.COLOR_INPUT_BG, Theme.COLOR_GLASS_BORDER, 10));
    card.setPadding(dp(act, 15), dp(act, 12), dp(act, 15), dp(act, 12));
    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
    lp.bottomMargin = dp(act, 10);
    card.setLayoutParams(lp);

    TextView tvLabel = new TextView(act);
    tvLabel.setText(label);
    tvLabel.setTextColor(Theme.COLOR_TEXT_MAIN);
    card.addView(tvLabel, new LinearLayout.LayoutParams(0, -2, 1.0f));

    TextView tvVal = new TextView(act); 
    String curr = getString(key, def);
    tvVal.setText(curr + " 下拉");
    tvVal.setTextColor(Theme.COLOR_PRIMARY);
    tvVal.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) { showGlassOptionSelector(act, tvVal, "选择 " + label, key, options); }
    });
    card.addView(tvVal);
    return card;
}

View makeGlassSwitchCard(Activity act, String label, String key, boolean def) {
    LinearLayout card = new LinearLayout(act);
    card.setOrientation(LinearLayout.HORIZONTAL);
    card.setGravity(Gravity.CENTER_VERTICAL);
    card.setBackground(makeGlassDrawable(act, Theme.COLOR_INPUT_BG, Theme.COLOR_GLASS_BORDER, 10));
    card.setPadding(dp(act, 15), dp(act, 8), dp(act, 15), dp(act, 8));
    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
    lp.bottomMargin = dp(act, 10);
    card.setLayoutParams(lp);

    TextView tvLabel = new TextView(act);
    tvLabel.setText(label);
    tvLabel.setTextColor(Theme.COLOR_TEXT_MAIN);
    card.addView(tvLabel, new LinearLayout.LayoutParams(0, -2, 1.0f));

    TextView btn = new TextView(act); 
    btn.setTextSize(12f);
    btn.setGravity(Gravity.CENTER);
    btn.setPadding(dp(act, 15), dp(act, 6), dp(act, 15), dp(act, 6));
    
    String saved = getString(key, String.valueOf(def));
    btn.setTag(saved); 
    
    if (saved.equals("true")) {
        btn.setText("已开启");
        btn.setTextColor(Color.BLACK);
        btn.setBackground(makeGlassDrawable(act, Theme.COLOR_PRIMARY, Theme.COLOR_PRIMARY, 15));
    } else {
        btn.setText("已关闭");
        btn.setTextColor(Theme.COLOR_TEXT_SUB);
        btn.setBackground(makeGlassDrawable(act, Color.TRANSPARENT, Color.parseColor("#66FFFFFF"), 15));
    }

    btn.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            String current = (String) v.getTag();
            if (current.equals("true")) {
                v.setTag("false"); setData(key, "false");
                ((TextView)v).setText("已关闭");
                ((TextView)v).setTextColor(Theme.COLOR_TEXT_SUB);
                v.setBackground(makeGlassDrawable(act, Color.TRANSPARENT, Color.parseColor("#66FFFFFF"), 15));
            } else {
                v.setTag("true"); setData(key, "true");
                ((TextView)v).setText("已开启");
                ((TextView)v).setTextColor(Color.BLACK);
                v.setBackground(makeGlassDrawable(act, Theme.COLOR_PRIMARY, Theme.COLOR_PRIMARY, 15));
            }
        }
    });

    card.addView(btn);
    return card;
}

void showAddVoiceDialog(Activity act, String providerType, String storageKey, Runnable callback) {
    if (act == null || act.isFinishing()) return;
    Dialog d = new Dialog(act);
    d.requestWindowFeature(Window.FEATURE_NO_TITLE);
    
    LinearLayout root = new LinearLayout(act);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setBackground(makeAuroraBg(act, 20));
    root.setPadding(dp(act, 25), dp(act, 25), dp(act, 25), dp(act, 25));

    TextView title = new TextView(act);
    title.setText(providerType.equals("fish") ? "添加 Fish 音色" : "添加 Vocu 音色");
    title.setTextSize(18f);
    title.setTypeface(Typeface.DEFAULT_BOLD);
    title.setTextColor(Theme.COLOR_TEXT_MAIN);
    title.setGravity(Gravity.CENTER);
    title.setPadding(0, 0, 0, dp(act, 20)); 
    root.addView(title);

    EditText etName = makeGlassInput(act, "", "给音色起个名 (如: 派蒙)");
    root.addView(etName);
    root.addView(makeGlassSpacer(act, 1, 15));

    String idHint = providerType.equals("fish") ? "粘贴 Reference ID" : "粘贴 Voice ID (UUID)";
    EditText etId = makeGlassInput(act, "", idHint);
    root.addView(etId);
    root.addView(makeGlassSpacer(act, 1, 25));

    LinearLayout btnLayout = new LinearLayout(act);
    btnLayout.setOrientation(LinearLayout.HORIZONTAL);

    TextView btnCancel = makeGlassActionBtn(act, "取消", Color.TRANSPARENT);
    btnCancel.setTextColor(Theme.COLOR_TEXT_SUB);
    LinearLayout.LayoutParams lpCancel = new LinearLayout.LayoutParams(0, -2, 1.0f);
    lpCancel.rightMargin = dp(act, 10);
    btnCancel.setLayoutParams(lpCancel);
    btnCancel.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { d.dismiss(); } });
    btnLayout.addView(btnCancel);

    TextView btnSave = makeGlassActionBtn(act, "保存", Theme.COLOR_PRIMARY);
    btnSave.setTextColor(Color.BLACK);
    LinearLayout.LayoutParams lpSave = new LinearLayout.LayoutParams(0, -2, 1.0f);
    btnSave.setLayoutParams(lpSave);
    btnSave.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            String n = etName.getText().toString().trim();
            String i = etId.getText().toString().trim();
            if (n.equals("") || i.equals("")) { Toast("标题和 ID 不能为空"); return; }
            ArrayList list = getVoiceList(storageKey);
            Map m = new HashMap(); m.put("name", n); m.put("id", i);
            list.add(m);
            saveVoiceList(storageKey, list);
            callback.run(); Toast("添加成功"); d.dismiss();
        }
    });
    btnLayout.addView(btnSave);
    root.addView(btnLayout);

    d.setContentView(root);
    d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT)); 
    d.getWindow().setLayout((int)(act.getResources().getDisplayMetrics().widthPixels * 0.85), -2);
    d.show();
}

void showVoiceManager(Activity act, TextView tvRefName, String providerType) {
    if (act == null || act.isFinishing()) return;
    Dialog d = new Dialog(act);
    d.requestWindowFeature(Window.FEATURE_NO_TITLE);
    
    String storageKey = providerType.equals("fish") ? "saved_voices_fish" : "saved_voices_vocu";
    String settingIdKey = providerType.equals("fish") ? "reference_id" : "vocu_voice_id";
    String settingNameKey = providerType.equals("fish") ? "reference_name" : "vocu_voice_name";
    
    LinearLayout root = new LinearLayout(act);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setBackground(makeAuroraBg(act, 20)); 
    
    TextView title = new TextView(act);
    title.setText(providerType.equals("fish") ? "Fish 音色库" : "Vocu 音色库");
    title.setTextSize(18f);
    title.setTypeface(Typeface.DEFAULT_BOLD);
    title.setTextColor(Theme.COLOR_TEXT_MAIN);
    title.setPadding(dp(act, 20), dp(act, 20), dp(act, 20), dp(act, 10));
    root.addView(title);
    
    ScrollView sv = new ScrollView(act);
    LinearLayout listContainer = new LinearLayout(act);
    listContainer.setOrientation(LinearLayout.VERTICAL);
    listContainer.setPadding(dp(act, 15), 0, dp(act, 15), 0);
    sv.addView(listContainer);
    root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1.0f));

    Runnable refreshList = new Runnable() {
        public void run() {
            listContainer.removeAllViews();
            ArrayList voices = getVoiceList(storageKey);
            
            if (voices.size() == 0) {
                TextView empty = new TextView(act);
                empty.setText("暂无保存的音色\n点击底部按钮添加");
                empty.setPadding(0, dp(act, 40), 0, dp(act, 40));
                empty.setGravity(Gravity.CENTER);
                empty.setTextColor(Theme.COLOR_TEXT_SUB);
                listContainer.addView(empty);
            }

            for (int i = 0; i < voices.size(); i++) {
                Map vMap = (Map) voices.get(i);
                String vName = (String) vMap.get("name");
                String vId = (String) vMap.get("id");
                int index = i; 

                LinearLayout card = new LinearLayout(act);
                card.setOrientation(LinearLayout.HORIZONTAL);
                card.setBackground(makePressableGlass(act, Theme.COLOR_INPUT_BG, Color.parseColor("#4D000000"), Theme.COLOR_GLASS_BORDER, 12));
                card.setPadding(dp(act, 15), dp(act, 12), dp(act, 15), dp(act, 12));
                card.setGravity(Gravity.CENTER_VERTICAL);
                LinearLayout.LayoutParams lpCard = new LinearLayout.LayoutParams(-1, -2);
                lpCard.bottomMargin = dp(act, 10);
                card.setLayoutParams(lpCard);
                
                LinearLayout info = new LinearLayout(act);
                info.setOrientation(LinearLayout.VERTICAL);
                info.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
                
                TextView tName = new TextView(act);
                tName.setText(vName);
                tName.setTextSize(15f);
                tName.setTypeface(Typeface.DEFAULT_BOLD);
                tName.setTextColor(Theme.COLOR_TEXT_MAIN);
                TextView tId = new TextView(act);
                tId.setText("ID: " + vId);
                tId.setTextSize(11f);
                tId.setTextColor(Theme.COLOR_TEXT_SUB);
                tId.setSingleLine(true);
                
                info.addView(tName);
                info.addView(tId);
                
                info.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        setData(settingIdKey, vId);
                        setData(settingNameKey, vName);
                        if (tvRefName != null) tvRefName.setText("音色: " + vName);
                        Toast("已应用音色: " + vName);
                        d.dismiss();
                    }
                });
                card.addView(info);

                TextView btnDel = new TextView(act);
                btnDel.setText("删除");
                btnDel.setTextSize(16f);
                btnDel.setTextColor(Theme.COLOR_DANGER);
                btnDel.setPadding(dp(act, 15), dp(act, 5), dp(act, 5), dp(act, 5));
                btnDel.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        voices.remove(index);
                        saveVoiceList(storageKey, voices);
                        refreshList.run(); 
                    }
                });
                card.addView(btnDel);
                listContainer.addView(card);
            }
        }
    };
    refreshList.run();

    TextView btnAdd = makeGlassActionBtn(act, "+ 添加新音色", Theme.COLOR_PRIMARY);
    btnAdd.setTextColor(Color.BLACK);
    LinearLayout.LayoutParams lpBtn = new LinearLayout.LayoutParams(-1, -2);
    lpBtn.setMargins(dp(act, 20), dp(act, 10), dp(act, 20), dp(act, 20));
    btnAdd.setLayoutParams(lpBtn);
    btnAdd.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) { showAddVoiceDialog(act, providerType, storageKey, refreshList); }
    });
    root.addView(btnAdd);

    d.setContentView(root);
    d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
    d.getWindow().setLayout((int)(act.getResources().getDisplayMetrics().widthPixels * 0.9), (int)(act.getResources().getDisplayMetrics().heightPixels * 0.65));
    d.show();
}


void showAddPathDialog(Context ctx, Runnable onConfirm) {
    if (ctx == null) return;
    Dialog d = new Dialog(ctx);
    d.requestWindowFeature(Window.FEATURE_NO_TITLE);
    
    LinearLayout root = new LinearLayout(ctx);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setBackground(makeAuroraBg(ctx, 20));
    root.setPadding(dp(ctx, 25), dp(ctx, 25), dp(ctx, 25), dp(ctx, 25));

    TextView title = new TextView(ctx);
    title.setText("添加本地目录");
    title.setTextSize(18f);
    title.setTypeface(Typeface.DEFAULT_BOLD);
    title.setTextColor(Theme.COLOR_TEXT_MAIN);
    title.setGravity(Gravity.CENTER);
    title.setPadding(0, 0, 0, dp(ctx, 20));
    root.addView(title);

    EditText et = makeGlassInput(ctx, "/sdcard/", "/sdcard/Download/Voice/");
    root.addView(et);
    root.addView(makeGlassSpacer(ctx, 1, 25));

    LinearLayout btnLayout = new LinearLayout(ctx);
    btnLayout.setOrientation(LinearLayout.HORIZONTAL);

    TextView btnCancel = makeGlassActionBtn(ctx, "取消", Color.TRANSPARENT);
    btnCancel.setTextColor(Theme.COLOR_TEXT_SUB);
    LinearLayout.LayoutParams lpCancel = new LinearLayout.LayoutParams(0, -2, 1.0f);
    lpCancel.rightMargin = dp(ctx, 10);
    btnCancel.setLayoutParams(lpCancel);
    btnCancel.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { d.dismiss(); } });
    btnLayout.addView(btnCancel);

    TextView btnSave = makeGlassActionBtn(ctx, "添加", Theme.COLOR_PRIMARY);
    btnSave.setTextColor(Color.BLACK);
    LinearLayout.LayoutParams lpSave = new LinearLayout.LayoutParams(0, -2, 1.0f);
    btnSave.setLayoutParams(lpSave);
    btnSave.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            String path = et.getText().toString().trim();
            if (path.length() > 0) {
                if (path.endsWith("/")) path = path.substring(0, path.length() - 1);
                UIState.dirList.add(path);
                
                try {
                    File f = new File(getScriptPath() + "/audio_paths.config");
                    BufferedWriter bw = new BufferedWriter(new FileWriter(f));
                    for (int i = 0; i < UIState.dirList.size(); i++) {
                        bw.write((String)UIState.dirList.get(i)); bw.newLine();
                    }
                    bw.close();
                } catch (Exception e) {}
                
                UIState.currentDirIndex = UIState.dirList.size() - 1; 
                onConfirm.run();
                d.dismiss();
            } else { Toast("路径不能为空"); }
        }
    });
    btnLayout.addView(btnSave);

    root.addView(btnLayout);
    d.setContentView(root);
    d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
    d.getWindow().setLayout((int)(ctx.getResources().getDisplayMetrics().widthPixels * 0.85), -2);
    d.show();
}

// ========== 音频播放弹窗 ==========
void showPlayerDialog(Context ctx, File file) {
    if (ctx == null) return;
    String safePath = file.getAbsolutePath();
    String safeName = file.getName();

    Dialog pd = new Dialog(ctx); 
    pd.requestWindowFeature(Window.FEATURE_NO_TITLE);
    
    LinearLayout root = new LinearLayout(ctx);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setBackground(makeAuroraBg(ctx, 20));
    root.setPadding(dp(ctx, 25), dp(ctx, 25), dp(ctx, 25), dp(ctx, 25));

    TextView title = new TextView(ctx);
    title.setText(safeName);
    title.setTextSize(15f);
    title.setTypeface(Typeface.DEFAULT_BOLD);
    title.setTextColor(Theme.COLOR_TEXT_MAIN);
    title.setGravity(Gravity.CENTER);
    title.setSingleLine(true); 
    title.setEllipsize(android.text.TextUtils.TruncateAt.END);
    root.addView(title);

    LinearLayout progressLayout = new LinearLayout(ctx);
    progressLayout.setOrientation(LinearLayout.VERTICAL);
    progressLayout.setPadding(0, dp(ctx, 25), 0, dp(ctx, 15));
    
    SeekBar sb = new SeekBar(ctx); 
    sb.setProgressDrawable(getGlassSeekBarTrack(ctx));
    sb.setThumb(getGlassSeekBarThumb(ctx));
    sb.setPadding(dp(ctx, 10), 0, dp(ctx, 10), 0);
    sb.setMaxHeight(dp(ctx, 4)); 
    sb.setThumbOffset(dp(ctx, 9));
    progressLayout.addView(sb);

    TextView tvTime = new TextView(ctx); 
    tvTime.setTextSize(11f);
    tvTime.setTextColor(Theme.COLOR_TEXT_SUB);
    tvTime.setGravity(Gravity.CENTER);
    tvTime.setText("0:00 / 0:00");
    tvTime.setPadding(0, dp(ctx, 8), 0, 0);
    progressLayout.addView(tvTime);
    
    root.addView(progressLayout);

    LinearLayout ctrl = new LinearLayout(ctx);
    ctrl.setGravity(Gravity.CENTER_VERTICAL);
    ctrl.setPadding(0, dp(ctx, 5), 0, 0);
    
    TextView btnPlay = new TextView(ctx); 
    btnPlay.setText("暂停"); // 初始状态为暂停（自动播放后）
    btnPlay.setTextSize(16f);
    btnPlay.setGravity(Gravity.CENTER);
    btnPlay.setTextColor(Color.BLACK);
    btnPlay.setTypeface(Typeface.DEFAULT_BOLD);
    btnPlay.setBackground(makeGlassDrawable(ctx, Theme.COLOR_INPUT_BG, Theme.COLOR_GLASS_BORDER, 25));
    LinearLayout.LayoutParams lpPlay = new LinearLayout. LayoutParams(dp(ctx, 50), dp(ctx, 50));
    lpPlay.rightMargin = dp(ctx, 15); 
    btnPlay.setLayoutParams(lpPlay);

    LinearLayout switchCard = new LinearLayout(ctx);
    switchCard.setOrientation(LinearLayout.HORIZONTAL);
    switchCard.setGravity(Gravity.CENTER_VERTICAL);
    switchCard.setBackground(makeGlassDrawable(ctx, Theme.COLOR_INPUT_BG, Theme.COLOR_GLASS_BORDER, 12));
    switchCard.setPadding(dp(ctx, 12), dp(ctx, 8), dp(ctx, 12), dp(ctx, 8));
    LinearLayout.LayoutParams lpSwitch = new LinearLayout.LayoutParams(0, -2, 1.0f);
    switchCard.setLayoutParams(lpSwitch);

    TextView swLabel = new TextView(ctx);
    swLabel.setText("发送模式");
    swLabel.setTextSize(13);
    swLabel.setTextColor(Theme.COLOR_TEXT_MAIN);
    switchCard.addView(swLabel, new LinearLayout.LayoutParams(0, -2, 1.0f));

    TextView swBtn = new TextView(ctx);
    swBtn.setText("原文件"); 
    swBtn.setTextSize(11);
    swBtn.setTextColor(Theme.COLOR_TEXT_SUB);
    swBtn.setGravity(Gravity.CENTER);
    swBtn.setPadding(dp(ctx, 12), dp(ctx, 6), dp(ctx, 12), dp(ctx, 6));
    swBtn.setBackground(makeGlassDrawable(ctx, Color.TRANSPARENT, Color.parseColor("#66FFFFFF"), 12));
    swBtn.setTag("0");
    switchCard.addView(swBtn);

    ctrl.addView(btnPlay);
    ctrl.addView(switchCard);
    root.addView(ctrl);

    TextView btnSend = new TextView(ctx);
    btnSend.setText("发送 (原文件)");
    btnSend.setTextSize(14);
    btnSend.setTypeface(Typeface.DEFAULT_BOLD);
    btnSend.setGravity(Gravity.CENTER);
    btnSend.setPadding(0, dp(ctx, 12), 0, dp(ctx, 12));
    LinearLayout.LayoutParams lpSend = new LinearLayout.LayoutParams(-1, -2);
    lpSend.topMargin = dp(ctx, 20);
    btnSend.setLayoutParams(lpSend);
    btnSend.setTextColor(Theme.COLOR_PRIMARY);
    btnSend.setBackground(makePressableGlass(ctx, Color.parseColor("#E6FFFFFF"), Color.parseColor("#CCFFFFFF"), Theme.COLOR_GLASS_BORDER, 50));
    root.addView(btnSend);

    String TEMP_PLAY_AAC = getScriptPath() + "/temp_play.m4a";
    String TEMP_SEND_SILK = getScriptPath() + "/temp_send.silk";

    final boolean isSilk = safePath.toLowerCase().endsWith(".silk");
    final Activity act = (ctx instanceof Activity) ? (Activity) ctx : getThreadActivity();
    final android.os.Handler handler = new android.os.Handler();

    if (isSilk) {
        Dialog loadingDialog = new Dialog(ctx);
        loadingDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        loadingDialog.setCancelable(false);
        LinearLayout loadingRoot = new LinearLayout(ctx);
        loadingRoot.setOrientation(LinearLayout.VERTICAL);
        loadingRoot.setBackground(makeAuroraBg(ctx, 20));
        loadingRoot.setPadding(dp(ctx, 35), dp(ctx, 35), dp(ctx, 35), dp(ctx, 35));
        loadingRoot.setGravity(Gravity.CENTER);
        ProgressBar pb = new ProgressBar(ctx);
        loadingRoot.addView(pb);
        TextView tv = new TextView(ctx);
        tv.setText("正在转码播放...");
        tv.setTextColor(Theme.COLOR_TEXT_MAIN);
        tv.setTextSize(14f);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(0, dp(ctx, 15), 0, 0);
        loadingRoot.addView(tv);
        loadingDialog.setContentView(loadingRoot);
        loadingDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        loadingDialog.show();

        new Thread(new Runnable() {
            public void run() {
                new File(TEMP_PLAY_AAC).delete();
                boolean success = false;
                try {
                    success = ffmpegToAac(safePath, TEMP_PLAY_AAC, 16000, 1);
                } catch (Exception e) {}
                if (!success) {
                    try {
                        success = toAac(safePath, TEMP_PLAY_AAC, 16000, 1);
                    } catch (Exception e) {}
                }
                if (act == null) return;
                act.runOnUiThread(new Runnable() {
                    public void run() {
                        try {
                            loadingDialog.dismiss();
                            if (success) {
                                AudioPlayer.play(TEMP_PLAY_AAC);
                                startPlaybackUpdates(pd, sb, tvTime, btnPlay, handler, TEMP_PLAY_AAC);
                            } else {
                                Toast("Silk转码播放失败");
                                pd.dismiss();
                            }
                        } catch (Exception e) {}
                    }
                });
            }
        }).start();
    } else {
        AudioPlayer.play(safePath);
        startPlaybackUpdates(pd, sb, tvTime, btnPlay, handler, safePath);
    }

    swBtn.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            String state = (String) v.getTag();
            if (state.equals("0")) {
                v.setTag("1");
                ((TextView)v).setText("转码Silk");
                ((TextView)v).setTextColor(Color.WHITE);
                v.setBackground(makeGlassDrawable(ctx, Theme.COLOR_PRIMARY, Theme.COLOR_PRIMARY, 12));
                btnSend.setText("发送 (转码Silk)");
                btnSend.setTextColor(Color.WHITE);
                btnSend.setBackground(makePressableGlass(ctx, Theme.COLOR_PRIMARY, Color.parseColor("#4D000000"), Theme.COLOR_GLASS_BORDER, 50));
            } else {
                v.setTag("0");
                ((TextView)v).setText("原文件");
                ((TextView)v).setTextColor(Theme.COLOR_TEXT_SUB);
                v.setBackground(makeGlassDrawable(ctx, Color.TRANSPARENT, Color.parseColor("#66FFFFFF"), 12));
                btnSend.setText("发送 (原文件)");
                btnSend.setTextColor(Theme.COLOR_PRIMARY);
                btnSend.setBackground(makePressableGlass(ctx, Color.parseColor("#E6FFFFFF"), Color.parseColor("#CCFFFFFF"), Theme.COLOR_GLASS_BORDER, 50));
            }
        }
    });

    btnSend.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            String mode = (String) swBtn.getTag();
            pd.dismiss();
            AudioPlayer.stop();

            Object contact = getContact();
            if (contact == null) { Toast("请先在聊天窗口点击一下"); return; }

            if (mode.equals("1")) {
                if (act == null || act.isFinishing()) { Toast("无法获取Activity"); return; }
                act.runOnUiThread(new Runnable() {
                    public void run() {
                        try {
                            Dialog loadingDialog = new Dialog(act);
                            loadingDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                            loadingDialog.setCancelable(false);
                            LinearLayout loadingRoot = new LinearLayout(act);
                            loadingRoot.setOrientation(LinearLayout.VERTICAL);
                            loadingRoot.setBackground(makeAuroraBg(act, 20));
                            loadingRoot.setPadding(dp(act, 35), dp(act, 35), dp(act, 35), dp(act, 35));
                            loadingRoot.setGravity(Gravity.CENTER);
                            ProgressBar pb = new ProgressBar(act);
                            loadingRoot.addView(pb);
                            TextView tv = new TextView(act);
                            tv.setText("正在转码 Silk...");
                            tv.setTextColor(Theme.COLOR_TEXT_MAIN);
                            tv.setTextSize(14f);
                            tv.setTypeface(Typeface.DEFAULT_BOLD);
                            tv.setGravity(Gravity.CENTER);
                            tv.setPadding(0, dp(act, 15), 0, 0);
                            loadingRoot.addView(tv);
                            loadingDialog.setContentView(loadingRoot);
                            loadingDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                            loadingDialog.show();

                            new Thread(new Runnable() {
                                public void run() {
                                    new File(TEMP_SEND_SILK).delete();
                                    boolean success = toSilk(safePath, TEMP_SEND_SILK);
                                    act.runOnUiThread(new Runnable() {
                                        public void run() {
                                            try {
                                                loadingDialog.dismiss();
                                                if (success) {
                                                    voice(contact, TEMP_SEND_SILK);
                                                    Toast("转码并发送成功");
                                                } else {
                                                    Toast("转码失败");
                                                }
                                            } catch (Exception e) {}
                                        }
                                    });
                                }
                            }).start();
                        } catch (Exception e) {}
                    }
                });
            } else {
                voice(contact, safePath);
                Toast("已发送");
            }
        }
    });

    pd.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
        public void onDismiss(android.content.DialogInterface d) { AudioPlayer.stop(); }
    });

    pd.setContentView(root);
    pd.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
    pd.getWindow().setLayout((int)(ctx.getResources().getDisplayMetrics().widthPixels * 0.88), -2);
    pd.show();
}

// ========== 视频播放弹窗（增强版） ==========
void showVideoPlayerDialog(Context ctx, File file) {
    if (ctx == null) return;
    String safePath = file.getAbsolutePath();
    String safeName = file.getName();

    Dialog pd = new Dialog(ctx); 
    pd.requestWindowFeature(Window.FEATURE_NO_TITLE);
    
    LinearLayout root = new LinearLayout(ctx);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setBackground(makeAuroraBg(ctx, 20));
    root.setPadding(dp(ctx, 25), dp(ctx, 25), dp(ctx, 25), dp(ctx, 25));

    TextView title = new TextView(ctx);
    title.setText(safeName);
    title.setTextSize(15f);
    title.setTypeface(Typeface.DEFAULT_BOLD);
    title.setTextColor(Theme.COLOR_TEXT_MAIN);
    title.setGravity(Gravity.CENTER);
    title.setSingleLine(true); 
    title.setEllipsize(android.text.TextUtils.TruncateAt.END);
    root.addView(title);

    VideoView videoView = new VideoView(ctx);
    videoView.setVideoPath(safePath);
    LinearLayout.LayoutParams videoLp = new LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, 
        dp(ctx, 300) // 初始占位高度，稍后根据比例调整
    );
    videoLp.topMargin = dp(ctx, 15);
    videoLp.bottomMargin = dp(ctx, 15);
    videoLp.gravity = Gravity.CENTER_HORIZONTAL; // 水平居中
    videoView.setLayoutParams(videoLp);
    root.addView(videoView);

    // 进度条和时间
    LinearLayout progressLayout = new LinearLayout(ctx);
    progressLayout.setOrientation(LinearLayout.VERTICAL);
    progressLayout.setPadding(0, 0, 0, dp(ctx, 15));
    
    SeekBar sb = new SeekBar(ctx); 
    sb.setProgressDrawable(getGlassSeekBarTrack(ctx));
    sb.setThumb(getGlassSeekBarThumb(ctx));
    sb.setPadding(dp(ctx, 10), 0, dp(ctx, 10), 0);
    sb.setMaxHeight(dp(ctx, 4)); 
    sb.setThumbOffset(dp(ctx, 9));
    progressLayout.addView(sb);

    TextView tvTime = new TextView(ctx); 
    tvTime.setTextSize(11f);
    tvTime.setTextColor(Theme.COLOR_TEXT_SUB);
    tvTime.setGravity(Gravity.CENTER);
    tvTime.setText("0:00 / 0:00");
    tvTime.setPadding(0, dp(ctx, 8), 0, 0);
    progressLayout.addView(tvTime);
    root.addView(progressLayout);

    // 控制栏
    LinearLayout ctrl = new LinearLayout(ctx);
    ctrl.setGravity(Gravity.CENTER_VERTICAL);
    ctrl.setPadding(0, 0, 0, dp(ctx, 15));
    
    TextView btnPlay = new TextView(ctx); 
    btnPlay.setText("暂停");
    btnPlay.setTextSize(16f); // 调小字号
    btnPlay.setGravity(Gravity.CENTER);
    btnPlay.setTextColor(Color.BLACK); // 黑色
    btnPlay.setTypeface(Typeface.DEFAULT_BOLD); // 加粗
    btnPlay.setBackground(makeGlassDrawable(ctx, Theme.COLOR_INPUT_BG, Theme.COLOR_GLASS_BORDER, 25));
    LinearLayout.LayoutParams lpPlay = new LinearLayout.LayoutParams(dp(ctx, 50), dp(ctx, 50));
    lpPlay.rightMargin = dp(ctx, 15); 
    btnPlay.setLayoutParams(lpPlay);
    ctrl.addView(btnPlay);

    // 模式切换卡片
    LinearLayout switchCard = new LinearLayout(ctx);
    switchCard.setOrientation(LinearLayout.HORIZONTAL);
    switchCard.setGravity(Gravity.CENTER_VERTICAL);
    switchCard.setBackground(makeGlassDrawable(ctx, Theme.COLOR_INPUT_BG, Theme.COLOR_GLASS_BORDER, 12));
    switchCard.setPadding(dp(ctx, 12), dp(ctx, 8), dp(ctx, 12), dp(ctx, 8));
    LinearLayout.LayoutParams lpSwitch = new LinearLayout.LayoutParams(0, -2, 1.0f);
    switchCard.setLayoutParams(lpSwitch);

    TextView swLabel = new TextView(ctx);
    swLabel.setText("发送模式");
    swLabel.setTextSize(13);
    swLabel.setTextColor(Theme.COLOR_TEXT_MAIN);
    switchCard.addView(swLabel, new LinearLayout.LayoutParams(0, -2, 1.0f));

    TextView swBtn = new TextView(ctx);
    swBtn.setText("原文件");
    swBtn.setTextSize(11);
    swBtn.setTextColor(Theme.COLOR_TEXT_SUB);
    swBtn.setGravity(Gravity.CENTER);
    swBtn.setPadding(dp(ctx, 12), dp(ctx, 6), dp(ctx, 12), dp(ctx, 6));
    swBtn.setBackground(makeGlassDrawable(ctx, Color.TRANSPARENT, Color.parseColor("#66FFFFFF"), 12));
    swBtn.setTag("0");
    switchCard.addView(swBtn);

    ctrl.addView(switchCard);
    root.addView(ctrl);

    TextView btnSend = new TextView(ctx);
    btnSend.setText("发送 (原文件)");
    btnSend.setTextSize(14);
    btnSend.setTypeface(Typeface.DEFAULT_BOLD);
    btnSend.setGravity(Gravity.CENTER);
    btnSend.setPadding(0, dp(ctx, 12), 0, dp(ctx, 12));
    LinearLayout.LayoutParams lpSend = new LinearLayout.LayoutParams(-1, -2);
    lpSend.topMargin = dp(ctx, 20);
    btnSend.setLayoutParams(lpSend);
    btnSend.setTextColor(Theme.COLOR_PRIMARY);
    btnSend.setBackground(makePressableGlass(ctx, Color.parseColor("#E6FFFFFF"), Color.parseColor("#CCFFFFFF"), Theme.COLOR_GLASS_BORDER, 50));
    root.addView(btnSend);

    final android.os.Handler handler = new android.os.Handler();
    final Activity act = (ctx instanceof Activity) ? (Activity) ctx : getThreadActivity();

    // 视频准备就绪后调整高度并自动播放
    videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
        public void onPrepared(MediaPlayer mp) {
            int videoWidth = mp.getVideoWidth();
            int videoHeight = mp.getVideoHeight();
            
            // 调整 VideoView 高度以保持原始比例
            if (videoWidth > 0 && videoHeight > 0) {
                videoView.post(new Runnable() {
                    public void run() {
                        int viewWidth = videoView.getWidth(); // 当前 VideoView 宽度（MATCH_PARENT）
                        if (viewWidth > 0) {
                            int newHeight = viewWidth * videoHeight / videoWidth;
                            LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) videoView.getLayoutParams();
                            params.height = newHeight;
                            videoView.setLayoutParams(params);
                        }
                    }
                });
            }
            
            mp.setLooping(true);
            sb.setMax(videoView.getDuration());
            tvTime.setText("0:00 / " + formatTime(videoView.getDuration()));
            videoView.start();
        }
    });

    // 定期更新进度条
    Runnable updateTask = new Runnable() {
        public void run() {
            if (pd.isShowing()) {
                try {
                    int cur = videoView.getCurrentPosition();
                    int dur = videoView.getDuration();
                    sb.setProgress(cur);
                    tvTime.setText(formatTime(cur) + " / " + formatTime(dur));
                    
                    if (videoView.isPlaying()) {
                        btnPlay.setText("暂停");
                    } else {
                        btnPlay.setText("播放");
                    }
                    
                    handler.postDelayed(this, 200);
                } catch (Exception e) {}
            }
        }
    };
    handler.post(updateTask);

    sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
        public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
            if (fromUser) videoView.seekTo(p);
        }
        public void onStartTrackingTouch(SeekBar s) {}
        public void onStopTrackingTouch(SeekBar s) {}
    });

    btnPlay.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            if (videoView.isPlaying()) {
                videoView.pause();
                btnPlay.setText("播放");
            } else {
                videoView.start();
                btnPlay.setText("暂停");
            }
        }
    });

    swBtn.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            String state = (String) v.getTag();
            if (state.equals("0")) {
                v.setTag("1");
                ((TextView)v).setText("转码MP3");
                ((TextView)v).setTextColor(Color.WHITE);
                v.setBackground(makeGlassDrawable(ctx, Theme.COLOR_PRIMARY, Theme.COLOR_PRIMARY, 12));
                btnSend.setText("发送 (MP3文件)");
                btnSend.setTextColor(Color.WHITE);
                btnSend.setBackground(makePressableGlass(ctx, Theme.COLOR_PRIMARY, Color.parseColor("#4D000000"), Theme.COLOR_GLASS_BORDER, 50));
            } else if (state.equals("1")) {
                v.setTag("2");
                ((TextView)v).setText("转码Silk");
                ((TextView)v).setTextColor(Color.WHITE);
                v.setBackground(makeGlassDrawable(ctx, Theme.COLOR_PRIMARY, Theme.COLOR_PRIMARY, 12));
                btnSend.setText("发送 (语音Silk)");
                btnSend.setTextColor(Color.WHITE);
                btnSend.setBackground(makePressableGlass(ctx, Theme.COLOR_PRIMARY, Color.parseColor("#4D000000"), Theme.COLOR_GLASS_BORDER, 50));
            } else {
                v.setTag("0");
                ((TextView)v).setText("原文件");
                ((TextView)v).setTextColor(Theme.COLOR_TEXT_SUB);
                v.setBackground(makeGlassDrawable(ctx, Color.TRANSPARENT, Color.parseColor("#66FFFFFF"), 12));
                btnSend.setText("发送 (原文件)");
                btnSend.setTextColor(Theme.COLOR_PRIMARY);
                btnSend.setBackground(makePressableGlass(ctx, Color.parseColor("#E6FFFFFF"), Color.parseColor("#CCFFFFFF"), Theme.COLOR_GLASS_BORDER, 50));
            }
        }
    });

    btnSend.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            String mode = (String) swBtn.getTag();
            pd.dismiss();
            videoView.stopPlayback();
            handler.removeCallbacks(updateTask);

            Object contact = getContact();
            if (contact == null) { Toast("请先在聊天窗口点击一下"); return; }

            if (mode.equals("0")) {
                video(contact, safePath);
                Toast("视频已发送");
            } else if (mode.equals("1")) {
                // 转码 MP3
                if (act == null || act.isFinishing()) { Toast("无法获取Activity"); return; }
                act.runOnUiThread(new Runnable() {
                    public void run() {
                        Dialog loadingDialog = new Dialog(act);
                        loadingDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        loadingDialog.setCancelable(false);
                        LinearLayout loadingRoot = new LinearLayout(act);
                        loadingRoot.setOrientation(LinearLayout.VERTICAL);
                        loadingRoot.setBackground(makeAuroraBg(act, 20));
                        loadingRoot.setPadding(dp(act, 35), dp(act, 35), dp(act, 35), dp(act, 35));
                        loadingRoot.setGravity(Gravity.CENTER);
                        ProgressBar pb = new ProgressBar(act);
                        loadingRoot.addView(pb);
                        TextView tv = new TextView(act);
                        tv.setText("正在提取音频为 MP3...");
                        tv.setTextColor(Theme.COLOR_TEXT_MAIN);
                        tv.setTextSize(14f);
                        tv.setTypeface(Typeface.DEFAULT_BOLD);
                        tv.setGravity(Gravity.CENTER);
                        tv.setPadding(0, dp(act, 15), 0, 0);
                        loadingRoot.addView(tv);
                        loadingDialog.setContentView(loadingRoot);
                        loadingDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                        loadingDialog.show();

                        new Thread(new Runnable() {
                            public void run() {
                                String mp3Path = getScriptPath() + "/temp_video_audio.mp3";
                                new File(mp3Path).delete();
                                boolean success = extractAudioToMp3(safePath, mp3Path);
                                act.runOnUiThread(new Runnable() {
                                    public void run() {
                                        loadingDialog.dismiss();
                                        if (success) {
                                            voice(contact, mp3Path);
                                            Toast("MP3 已发送");
                                        } else {
                                            Toast("转码 MP3 失败");
                                        }
                                    }
                                });
                            }
                        }).start();
                    }
                });
            } else {
                // 转码 Silk
                if (act == null || act.isFinishing()) { Toast("无法获取Activity"); return; }
                act.runOnUiThread(new Runnable() {
                    public void run() {
                        Dialog loadingDialog = new Dialog(act);
                        loadingDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        loadingDialog.setCancelable(false);
                        LinearLayout loadingRoot = new LinearLayout(act);
                        loadingRoot.setOrientation(LinearLayout.VERTICAL);
                        loadingRoot.setBackground(makeAuroraBg(act, 20));
                        loadingRoot.setPadding(dp(act, 35), dp(act, 35), dp(act, 35), dp(act, 35));
                        loadingRoot.setGravity(Gravity.CENTER);
                        ProgressBar pb = new ProgressBar(act);
                        loadingRoot.addView(pb);
                        TextView tv = new TextView(act);
                        tv.setText("正在转码 Silk...");
                        tv.setTextColor(Theme.COLOR_TEXT_MAIN);
                        tv.setTextSize(14f);
                        tv.setTypeface(Typeface.DEFAULT_BOLD);
                        tv.setGravity(Gravity.CENTER);
                        tv.setPadding(0, dp(act, 15), 0, 0);
                        loadingRoot.addView(tv);
                        loadingDialog.setContentView(loadingRoot);
                        loadingDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                        loadingDialog.show();

                        new Thread(new Runnable() {
                            public void run() {
                                String silkPath = getScriptPath() + "/temp_video.silk";
                                new File(silkPath).delete();
                                boolean success = toSilk(safePath, silkPath);
                                act.runOnUiThread(new Runnable() {
                                    public void run() {
                                        loadingDialog.dismiss();
                                        if (success) {
                                            voice(contact, silkPath);
                                            Toast("Silk 语音已发送");
                                        } else {
                                            Toast("转码 Silk 失败");
                                        }
                                    }
                                });
                            }
                        }).start();
                    }
                });
            }
        }
    });

    pd.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
        public void onDismiss(android.content.DialogInterface d) {
            videoView.stopPlayback();
            handler.removeCallbacks(updateTask);
        }
    });

    pd.setContentView(root);
    pd.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
    pd.getWindow().setLayout((int)(ctx.getResources().getDisplayMetrics().widthPixels * 0.88), -2);
    pd.show();
}

// ========== 辅助方法：提取视频音频为 MP3（需要 FFmpeg） ==========
boolean extractAudioToMp3(String videoPath, String mp3Path) {
    try {
        File ffmpegBin = new File(context.getFilesDir(), "ffmpeg");
        if (!ffmpegBin.exists()) ffmpegBin = new File(context.getFilesDir(), "libffmpeg.so");
        String linker = new File("/system/bin/linker64").exists() ? "/system/bin/linker64 " : 
                       (new File("/system/bin/linker").exists() ? "/system/bin/linker " : "");
        String cmd = linker + ffmpegBin.getAbsolutePath() + " -i \"" + videoPath + "\" -q:a 0 -map a \"" + mp3Path + "\" -y";
        Process p = Runtime.getRuntime().exec(new String[]{"sh", "-c", cmd});
        p.waitFor();
        return new File(mp3Path).exists() && new File(mp3Path).length() > 0;
    } catch (Exception e) {
        error("extractAudioToMp3 异常: " + e);
        return false;
    }
}

void startPlaybackUpdates(Dialog pd, SeekBar sb, TextView tvTime, TextView btnPlay, android.os.Handler handler, String playPath) {
    Runnable updateTask = new Runnable() {
        public void run() {
            if (pd.isShowing() && AudioPlayer.mp != null) {
                try {
                    int cur = AudioPlayer.getCurrent();
                    int dur = AudioPlayer.getDuration();
                    sb.setMax(dur); sb.setProgress(cur);
                    tvTime.setText(formatTime(cur) + " / " + formatTime(dur));
                    
                    if (AudioPlayer.mp.isPlaying()) {
                        btnPlay.setText("暂停");
                        handler.postDelayed(this, 200); 
                    } else {
                        btnPlay.setText("播放");
                    }
                } catch(Exception e) {}
            }
        }
    };
    handler.post(updateTask);

    sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
        public void onProgressChanged(SeekBar s, int p, boolean fromUser) { if (fromUser) AudioPlayer.seekTo(p); }
        public void onStartTrackingTouch(SeekBar s) {}
        public void onStopTrackingTouch(SeekBar s) {}
    });

    btnPlay.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            if (AudioPlayer.mp != null && AudioPlayer.mp.isPlaying()) {
                AudioPlayer.pause(); btnPlay.setText("播放");
            } else {
                if (AudioPlayer.mp == null) AudioPlayer.play(playPath);
                else AudioPlayer.mp.start();
                btnPlay.setText("暂停");
                handler.post(updateTask);
            }
        }
    });
}
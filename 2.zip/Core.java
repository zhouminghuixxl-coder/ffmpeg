// ==========================================
// 文件：Core.java
// 极光核心引擎：UI状态、网络请求、PB发包 (全整合版)
// ==========================================
import android.app.*;
import android.content.*;
import android.view.*;
import android.widget.*;
import android.graphics.*;
import android.graphics.drawable.*;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;
import org.json.JSONObject;
import org.json.JSONArray;
import android.media.MediaPlayer;
import java.lang.reflect.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import com.tencent.common.app.BaseApplicationImpl;
import com.tencent.qphone.base.remote.ToServiceMsg;
import android.os.SystemClock;

// 1. 全局配置与变量
String GLOBAL_COOKIE = null;
String CURRENT_UID = null;
String COOKIE_FILE = "netease_vip_cookie.txt";
String GLOBAL_PEER_UIN = "";
int GLOBAL_CHAT_TYPE = 0;

// 网络请求常量
static final int CONNECT_TIMEOUT = 10000;
static final int READ_TIMEOUT = 15000;
static final int MAX_RETRY = 3;

// 2. [核心修复] UI状态机：解决 main.java 找不到 panelDialog 的报错
class UIState {
    static int ballX = 0;
    static int ballY = 300;
    static boolean isDragging = false;
    static Dialog ballDialog = null;
    static Dialog panelDialog = null;
    static ArrayList dirList = new ArrayList(); 
    static int currentDirIndex = 0;             
}

// 3. 音乐播放器控制器
static class AudioPlayer {
    static MediaPlayer mp = null;
    static String currentPath = "";
    
    static void play(String path) {
        try {
            if (mp != null) { 
                mp.stop(); 
                mp.release(); 
                mp = null; 
            }
            mp = new MediaPlayer();
            mp.setDataSource(path);
            mp.prepare();
            mp.start();
            currentPath = path;
        } catch(Exception e){
            android.util.Log.e("AudioPlayer", "播放失败：" + e.getMessage());
            Toast("音频播放失败：" + e.getMessage());
        }
    }
    
    static void pause() { 
        if (mp != null) mp.pause(); 
    }
    
    static void stop() { 
        if (mp != null) { 
            mp.stop(); 
            mp.release(); 
            mp = null; 
        }
    }
    
    static boolean isPlaying() { 
        return mp != null && mp.isPlaying(); 
    }
    
    static int getCurrent() { 
        return mp != null ? mp.getCurrentPosition() : 0; 
    }
    
    static int getDuration() { 
        return mp != null ? mp.getDuration() : 0; 
    }
    
    static void seekTo(int p) { 
        if (mp != null) mp.seekTo(p); 
    }
    
    // 新增：资源清理方法
    static void release() {
        stop();
        mp = null;
    }
}

// ==========================================
// 🚀 [核心修复] 网络请求函数：解决 Update.java 找不到 httpGet 的报错
// ==========================================
String httpGet(String urlStr) {
    return httpGetWithCookie(urlStr, "");
}

String httpGetWithCookie(String urlStr, String cookie) {
    int maxRetries = 3;
    for (int i = 0; i < maxRetries; i++) {
        try {
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(CONNECT_TIMEOUT);
            conn.setReadTimeout(READ_TIMEOUT);
            conn.setRequestProperty("User-Agent", "Mozilla/5.0");
            if(cookie != null && !cookie.isEmpty()) conn.setRequestProperty("Cookie", cookie);
            
            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            return sb.toString();
        } catch (Exception e) {
            if (i == maxRetries - 1) {
                android.util.Log.e("Network", "GET 请求失败：" + urlStr + ", 错误：" + e.getMessage());
                return "";
            }
        }
    }
    return "";
}

String httpPost(String urlStr, String body, String cookie) {
    int maxRetries = 3;
    for (int i = 0; i < maxRetries; i++) {
        try {
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setConnectTimeout(CONNECT_TIMEOUT);
            conn.setReadTimeout(READ_TIMEOUT);
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            if(cookie != null && !cookie.isEmpty()) conn.setRequestProperty("Cookie", cookie);
            
            OutputStream os = conn.getOutputStream();
            os.write(body.getBytes());
            os.flush(); os.close();
            
            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            return sb.toString();
        } catch (Exception e) {
            if (i == maxRetries - 1) {
                android.util.Log.e("Network", "POST 请求失败：" + urlStr + ", 错误：" + e.getMessage());
                return "";
            }
        }
    }
    return "";
}

// ==========================================
// 🚀 满血 PB 引擎：免疫暗抽版 sendMusic
// ==========================================
void sendMusic(String targetUin, String title, String artist, String jumpUrl, String musicUrl, String picUrl, String platform, String mode, int chatType) {
    Activity act = getThreadActivity();
    try {
        long peerUid = 0;
        int mtype = 0;
        Object contact = getContact();
        if (contact != null) {
            try {
                mtype = contact.getClass().getField("chatType").getInt(contact);
                peerUid = Long.parseLong((String) contact.getClass().getField("peerUid").get(contact));
            } catch(Exception e) {
                mtype = contact.chatType; peerUid = Long.parseLong(contact.peerUid);
            }
        } else { Toast("❌ 请在聊天界面内发送！"); return; }
        
        int pbChatType = (mtype == 2) ? 1 : 0;
        JSONObject json = new JSONObject();
        json.put("1", 2935); json.put("2", 9); json.put("6", "android 9.0.0");
        JSONObject obj4 = new JSONObject();
        obj4.put("1", 100495085L); obj4.put("2", 1); obj4.put("3", 4);
        obj4.put("20", 0); obj4.put("21", 0); obj4.put("11", peerUid); obj4.put("10", pbChatType); 
        JSONObject obj5 = new JSONObject();
        obj5.put("1", 1); obj5.put("2", "0.0.0"); obj5.put("3", "com.netease.cloudmusic");
        obj5.put("4", "da6b069da1e2982db3e386233f68d76d"); // 万能 Token
        obj4.put("5", obj5);
        JSONObject obj7 = new JSONObject(); obj7.put("15", (int)(Math.random() * 90000)); obj4.put("7", obj7);
        JSONObject obj12 = new JSONObject();
        obj12.put("16", musicUrl); obj12.put("10", title); obj12.put("11", artist);
        obj12.put("13", jumpUrl); obj12.put("14", picUrl);
        obj4.put("12", obj12);
        obj4.put("22", new JSONObject()); obj4.put("23", new JSONObject());
        json.put("4", obj4);

        MiniProtoData protoData = new MiniProtoData();
        protoData.fromJSON(json);
        byte[] sendBuffer = protoData.toBytes();

        Object app = BaseApplicationImpl.getApplication().getRuntime();
        ToServiceMsg toServiceMsg = new ToServiceMsg("com.tencent.mobileqq.msf.service.MsfService", myUin, "OidbSvc.0xb77_9");
        
        try {
            Method m1 = toServiceMsg.getClass().getDeclaredMethod("setRequestSsoSeq", new Class[]{int.class});
            m1.invoke(toServiceMsg, new Object[]{ (int)(Math.random() * 10000 + 60000) });
            Method m2 = toServiceMsg.getClass().getDeclaredMethod("putWupBuffer", new Class[]{byte[].class});
            m2.invoke(toServiceMsg, new Object[]{sendBuffer});
            Method addAttr = toServiceMsg.getClass().getDeclaredMethod("addAttribute", new Class[]{String.class, Object.class});
            addAttr.invoke(toServiceMsg, new Object[]{"appTimeoutReq", "371"});
            addAttr.invoke(toServiceMsg, new Object[]{"req_pb_protocol_flag", true});
            addAttr.invoke(toServiceMsg, new Object[]{"to_SenderProcessName", "com.tencent.mobileqq"});
            addAttr.invoke(toServiceMsg, new Object[]{"to_SendTime", System.currentTimeMillis()});
            addAttr.invoke(toServiceMsg, new Object[]{"fastresend", false});
            addAttr.invoke(toServiceMsg, new Object[]{"binder_start_send_time", SystemClock.elapsedRealtime()});
        } catch (Exception ex) {}

        Object mobileQQService = app.getMobileQQService();
        mobileQQService.getClass().getMethod("handleRequest", new Class[]{ToServiceMsg.class}).invoke(mobileQQService, new Object[]{toServiceMsg});
        Toast("🎵 极光 PB 卡片发射成功！");
    } catch (Exception e) { Toast("PB 发射失败: " + e.toString()); }
}

// 辅助：Protobuf 序列化类
class MiniProtoData {
    public HashMap values = new HashMap();
    public void fromJSON(JSONObject jsonObject) {
        try {
            Iterator keys = jsonObject.keys();
            while (keys.hasNext()) {
                String key = (String) keys.next();
                int fieldNumber = Integer.parseInt(key);
                Object value = jsonObject.get(key);
                if (value instanceof JSONObject) {
                    MiniProtoData nestedData = new MiniProtoData();
                    nestedData.fromJSON((JSONObject) value);
                    putValue(fieldNumber, nestedData);
                } else if (value instanceof JSONArray) {
                    JSONArray array = (JSONArray) value;
                    for (int i = 0; i < array.length(); i++) {
                        Object item = array.get(i);
                        if (item instanceof JSONObject) {
                            MiniProtoData nestedData = new MiniProtoData();
                            nestedData.fromJSON((JSONObject) item);
                            putValue(fieldNumber, nestedData);
                        } else putValue(fieldNumber, item);
                    }
                } else putValue(fieldNumber, value);
            }
        } catch (Exception e) {}
    }
    public void putValue(int fieldNumber, Object value) {
        List list = (List) values.get(new Integer(fieldNumber));
        if (list == null) { list = new ArrayList(); values.put(new Integer(fieldNumber), list); }
        list.add(value);
    }
    public byte[] toBytes() {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try { return encodeToProtobuf(baos); } catch (Exception e) { return new byte[0]; }
    }
    public byte[] encodeToProtobuf(ByteArrayOutputStream baos) throws Exception {
        Iterator entries = values.entrySet().iterator();
        while (entries.hasNext()) {
            Map.Entry entry = (Map.Entry) entries.next();
            Integer fieldNumber = (Integer) entry.getKey();
            List fieldValues = (List) entry.getValue();
            for (int i = 0; i < fieldValues.size(); i++) encodeField(baos, fieldNumber.intValue(), fieldValues.get(i));
        }
        return baos.toByteArray();
    }
    public void encodeField(ByteArrayOutputStream baos, int fieldNumber, Object value) throws Exception {
        if (value instanceof MiniProtoData) {
            byte[] nestedBytes = ((MiniProtoData) value).toBytes();
            writeVarint(baos, (fieldNumber << 3) | 2);
            writeVarint(baos, nestedBytes.length);
            baos.write(nestedBytes);
        } else if (value instanceof Long) {
            writeVarint(baos, (fieldNumber << 3) | 0);
            writeVarint(baos, ((Long) value).longValue());
        } else if (value instanceof Integer) {
            writeVarint(baos, (fieldNumber << 3) | 0);
            writeVarint(baos, ((Integer) value).longValue());
        } else if (value instanceof String) {
            byte[] strBytes = ((String) value).getBytes("UTF-8");
            writeVarint(baos, (fieldNumber << 3) | 2);
            writeVarint(baos, strBytes.length);
            baos.write(strBytes);
        }
    }
    public void writeVarint(ByteArrayOutputStream baos, long value) throws Exception {
        while (true) {
            if ((value & ~0x7FL) == 0) { baos.write((int) value); return; } 
            else { baos.write((int) ((value & 0x7F) | 0x80)); value >>>= 7; }
        }
    }
}

// 辅助：Dashboard 模式获取
String getMusicSendMode() { 
    String mode = getString("music_send_mode", "voice");
    return mode;
}

void setMusicSendMode(String mode) {
    setData("music_send_mode", mode);
}

// 辅助：基础函数
int dp(Context ctx, int d) { return (int)(d * ctx.getResources().getDisplayMetrics().density + 0.5f); }
void Toast(String msg) {
    Activity act = getThreadActivity();
    if (act != null) act.runOnUiThread(new Runnable() { public void run() { android.widget.Toast.makeText(act, msg, 0).show(); } });
}
String formatTime(int ms) {
    int s = ms / 1000;
    return (s/60<10?"0"+s/60:s/60)+":"+(s%60<10?"0"+s%60:s%60);
}
boolean downloadFile(String urlStr, String destPath) {
    try {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestProperty("User-Agent", "Mozilla/5.0");
        if (conn.getResponseCode() == 200) {
            InputStream is = conn.getInputStream();
            FileOutputStream fos = new FileOutputStream(destPath);
            byte[] buf = new byte[8192]; int len;
            while ((len = is.read(buf)) != -1) fos.write(buf, 0, len);
            fos.close(); is.close(); return true;
        }
    } catch (Exception e) {}
    return false;
}

// ========== 网易云 API 加密函数 ==========
String[] weapiEncrypt(String json) {
    try {
        // 固定参数
        String modulus = "00e0b509f6259df8642dbc35662901477df22677ec152b5ff68ace615bb7b725152b3ab17a876aea8a5aa76d2e417629ec4ee341f56135fccf695280104e0312ecbda92557c93870114af6c9d05c4f7f0c3685b7a46bee255932575cce10b424d813cfe4875d3e82047b97ddef52741d546b8e289dc6935b3ece0462db0a22b8e7";
        String nonce = "0CoJUm6Qyw8W8jud";
        String pubKey = "010001";
        
        // 生成密钥
        String secKey = createSecretKey(16);
        
        // AES 加密
        String encText = aesEncrypt(aesEncrypt(json, nonce), secKey);
        
        // RSA 加密
        String encSecKey = rsaEncrypt(secKey, pubKey, modulus);
        
        return new String[]{encText, encSecKey};
    } catch (Exception e) {
        error("weapiEncrypt 异常：" + e);
        return new String[]{"", ""};
    }
}

String createSecretKey(int length) {
    String chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    StringBuilder sb = new StringBuilder();
    Random r = new Random();
    for (int i = 0; i < length; i++) {
        sb.append(chars.charAt(r.nextInt(chars.length())));
    }
    return sb.toString();
}

String aesEncrypt(String data, String key) throws Exception {
    javax.crypto.spec.SecretKeySpec spec = new javax.crypto.spec.SecretKeySpec(key.getBytes("UTF-8"), "AES");
    javax.crypto.Cipher cipher = javax.crypto.Cipher.getInstance("AES/CBC/PKCS5Padding");
    cipher.init(javax.crypto.Cipher.ENCRYPT_MODE, spec, new javax.crypto.spec.IvParameterSpec("0102030405060708".getBytes("UTF-8")));
    byte[] encrypted = cipher.doFinal(data.getBytes("UTF-8"));
    return java.util.Base64.getEncoder().encodeToString(encrypted);
}

String rsaEncrypt(String text, String pubKey, String modulus) throws Exception {
    String reversed = new StringBuilder(text).reverse().toString();
    StringBuilder hex = new StringBuilder();
    byte[] bytes = reversed.getBytes("UTF-8");
    for (int i = 0; i < bytes.length; i++) {
        int b = bytes[i] & 0xFF;
        if (b < 0x10) {
            hex.append("0").append(Integer.toHexString(b));
        } else {
            hex.append(Integer.toHexString(b));
        }
    }
    java.math.BigInteger m = new java.math.BigInteger(hex.toString(), 16);
    java.math.BigInteger e = new java.math.BigInteger(pubKey, 16);
    java.math.BigInteger n = new java.math.BigInteger(modulus, 16);
    java.math.BigInteger result = m.modPow(e, n);
    String encrypted = result.toString(16);
    if (encrypted.length() < 256) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 256 - encrypted.length(); i++) {
            sb.append("0");
        }
        sb.append(encrypted);
        encrypted = sb.toString();
    }
    return encrypted;
}


// 缩放图片并保存为 JPEG
boolean resizeImage(String srcPath, String dstPath, int targetWidth, int targetHeight) {
    try {
        // 如果目标文件已存在，先删除
        File dstFile = new File(dstPath);
        if (dstFile.exists()) {
            dstFile.delete();
        }
        
        // 先读取原图尺寸
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(srcPath, opts);
        
        float srcW = opts.outWidth;
        float srcH = opts.outHeight;
        float scale = Math.max(targetWidth / srcW, targetHeight / srcH);
        
        // 如果是最小模式（1x1），特殊处理
        if (targetWidth == 1 && targetHeight == 1) {
            scale = 1f / Math.min(srcW, srcH);
        }
        
        int newW = (int) (srcW * scale);
        int newH = (int) (srcH * scale);
        if (newW < 1) newW = 1;
        if (newH < 1) newH = 1;
        
        // 解码原图（使用采样率避免内存溢出）
        opts.inJustDecodeBounds = false;
        int sample = 1;
        while (srcW / sample > 2000 && srcH / sample > 2000) {
            sample *= 2;
        }
        opts.inSampleSize = sample;
        Bitmap srcBitmap = BitmapFactory.decodeFile(srcPath, opts);
        if (srcBitmap == null) return false;
        
        // 缩放
        Bitmap scaledBitmap = Bitmap.createScaledBitmap(srcBitmap, newW, newH, true);
        srcBitmap.recycle();
        
        // 保存为 JPEG
        FileOutputStream fos = new FileOutputStream(dstPath);
        scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos);
        fos.close();
        scaledBitmap.recycle();
        
        return true;
    } catch (Exception e) {
        error("resizeImage error: " + e);
        return false;
    }
}

// 判断文件是否为视频格式
boolean isVideoFile(String filePath) {
    if (filePath == null) return false;
    String lower = filePath.toLowerCase();
    return lower.endsWith(".mp4") 
        || lower.endsWith(".mov") 
        || lower.endsWith(".avi") 
        || lower.endsWith(".mkv") 
        || lower.endsWith(".3gp") 
        || lower.endsWith(".flv") 
        || lower.endsWith(".wmv") 
        || lower.endsWith(".webm") 
        || lower.endsWith(".m4v");
}
// 判断文件是否为音频格式
boolean isAudioFile(String filePath) {
    if (filePath == null) return false;
    String lower = filePath.toLowerCase();
    return lower.endsWith(".mp3") 
        || lower.endsWith(".wav") 
        || lower.endsWith(".m4a") 
        || lower.endsWith(".aac") 
        || lower.endsWith(".ogg") 
        || lower.endsWith(".flac") 
        || lower.endsWith(".ape") 
        || lower.endsWith(".amr") 
        || lower.endsWith(".silk") 
        || lower.endsWith(".slk") 
        || lower.endsWith(".opus");
}

/**
 * 线程池管理器（符合 BeanShell 语法）
 * 注意：不使用任何泛型、Lambda 或 final 修饰符
 */
class ThreadPoolManager {
    // 网络请求线程池（IO密集型，使用缓存线程池）
    private static ExecutorService networkPool = Executors.newCachedThreadPool();
    
    // CPU密集型任务线程池（固定大小，与 CPU 核心数相同）
    private static int cpuCores = Runtime.getRuntime().availableProcessors();
    private static ExecutorService cpuPool = Executors.newFixedThreadPool(cpuCores);
    
    // 通用任务线程池
    private static ExecutorService commonPool = Executors.newCachedThreadPool();

    // 提交网络任务
    public static void runOnNetwork(Runnable task) {
        networkPool.submit(task);
    }

    // 提交CPU密集型任务（如FFmpeg转码）
    public static void runOnCpu(Runnable task) {
        cpuPool.submit(task);
    }

    // 提交通用任务
    public static void runOnCommon(Runnable task) {
        commonPool.submit(task);
    }

    // 关闭所有线程池（在脚本卸载时调用）
    public static void shutdown() {
        networkPool.shutdown();
        cpuPool.shutdown();
        commonPool.shutdown();
        
        try {
            // 等待1秒让现有任务完成
            if (!networkPool.awaitTermination(1, TimeUnit.SECONDS)) {
                networkPool.shutdownNow();
            }
            if (!cpuPool.awaitTermination(1, TimeUnit.SECONDS)) {
                cpuPool.shutdownNow();
            }
            if (!commonPool.awaitTermination(1, TimeUnit.SECONDS)) {
                commonPool.shutdownNow();
            }
        } catch (InterruptedException e) {
            networkPool.shutdownNow();
            cpuPool.shutdownNow();
            commonPool.shutdownNow();
        }
    }
}

// ==========================================
// 语音保存相关函数（从 TTS.java 迁移）
// ==========================================

String getMsgText(Object msgRecord) {
    try {
        Object rawMsg = null;
        try {
            Field f = msgRecord.getClass().getField("msg");
            rawMsg = f.get(msgRecord);
        } catch (Exception e) {
            rawMsg = msgRecord;
        }
        if (rawMsg == null) return "";
        
        java.util.List elements = rawMsg.elements;
        if (elements == null) return "";
        
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < elements.size(); i++) {
            Object el = elements.get(i);
            if (el.elementType == 1 && el.textElement != null) {
                sb.append(el.textElement.content);
            }
        }
        return sb.toString();
    } catch (Exception e) { 
        return ""; 
    }
}

String getVoiceFilePathFromMsg(Object msg) {
    try {
        Object rawMsg = null;
        try {
            java.lang.reflect.Field f = msg.getClass().getField("msg");
            rawMsg = f.get(msg);
        } catch (Exception e) {
            rawMsg = msg;
        }
        if (rawMsg == null) return null;
        
        Object elementsObj = rawMsg.getClass().getField("elements").get(rawMsg);
        if (elementsObj instanceof java.util.List) {
            java.util.List elements = (java.util.List) elementsObj;
            for (int i = 0; i < elements.size(); i++) {
                Object el = elements.get(i);
                Object pttEl = el.getClass().getField("pttElement").get(el);
                if (pttEl != null) {
                    return (String) pttEl.getClass().getField("filePath").get(pttEl);
                }
            }
        }
    } catch (Exception e) {} 
    return null; 
}

String getAudioExtension(String path) {
    try {
        FileInputStream fis = new FileInputStream(path);
        byte[] header = new byte[15]; 
        fis.read(header, 0, 15);
        fis.close();
        
        String str = new String(header);
        if (str.indexOf("SILK") != -1) return ".silk";
        if (str.indexOf("AMR") != -1) return ".amr";
        if (str.indexOf("ID3") != -1 || (header[0] == (byte)0xFF && header[1] == (byte)0xFB)) return ".mp3";
        if (str.indexOf("RIFF") != -1) return ".wav";
        if (str.indexOf("OggS") != -1) return ".ogg";
        if (str.indexOf("ftyp") != -1) return ".m4a";
    } catch (Exception e) {}
    if (path.toLowerCase().endsWith(".silk")) return ".silk";
    return ".amr"; 
}

void saveVoice(Object msg) {
    try {
        String path = getVoiceFilePathFromMsg(msg);
        if (path == null) { Toast("无法获取语音源文件"); return; }
        
        String ext = getAudioExtension(path);
        boolean isSilk = ext.equals(".silk");
        String displayExt = isSilk ? ".m4a" : ext;
        
        String defaultName = "";
        try { defaultName = msg.sendNickName + "_" + System.currentTimeMillis(); } 
        catch (Exception e) { defaultName = "voice_" + System.currentTimeMillis(); }
        
        Activity act = getThreadActivity();
        if (act == null || act.isFinishing()) return;
        
        String safeSrcPath = path;
        String safeDefaultN = defaultName;
        String safeDisplayExt = displayExt;
        boolean safeIsSilk = isSilk;
        
        act.runOnUiThread(new Runnable() {
            public void run() {
                try {
                    Dialog d = new Dialog(act);
                    d.requestWindowFeature(Window.FEATURE_NO_TITLE);
                    
                    LinearLayout root = new LinearLayout(act);
                    root.setOrientation(LinearLayout.VERTICAL);
                    root.setBackground(makeAuroraBg(act, 20));
                    root.setPadding(dp(act, 25), dp(act, 25), dp(act, 25), dp(act, 25));

                    TextView title = new TextView(act);
                    title.setText("保存语音文件");
                    title.setTextSize(18f);
                    title.setTypeface(Typeface.DEFAULT_BOLD);
                    title.setTextColor(Theme.COLOR_TEXT_MAIN);
                    title.setGravity(Gravity.CENTER);
                    root.addView(title);
                    
                    TextView subTitle = new TextView(act);
                    if (safeIsSilk) {
                        subTitle.setText("检测为 Silk，将转码为 AAC(m4a) 保存");
                        subTitle.setTextColor(Theme.COLOR_PRIMARY);
                    } else {
                        subTitle.setText("格式: " + safeDisplayExt);
                        subTitle.setTextColor(Theme.COLOR_TEXT_SUB);
                    }
                    subTitle.setTextSize(12f);
                    subTitle.setGravity(Gravity.CENTER);
                    subTitle.setPadding(0, dp(act, 5), 0, dp(act, 15));
                    root.addView(subTitle);

                    EditText et = makeGlassInput(act, safeDefaultN, "输入文件名（不含后缀）");
                    root.addView(et);

                    View gap = new View(act);
                    root.addView(gap, new LinearLayout.LayoutParams(-1, dp(act, 25)));

                    LinearLayout btnLayout = new LinearLayout(act);
                    btnLayout.setOrientation(LinearLayout.HORIZONTAL);

                    TextView btnCancel = new TextView(act);
                    btnCancel.setText("取消");
                    btnCancel.setTextSize(14);
                    btnCancel.setTypeface(Typeface.DEFAULT_BOLD);
                    btnCancel.setGravity(Gravity.CENTER);
                    btnCancel.setPadding(0, dp(act, 12), 0, dp(act, 12));
                    btnCancel.setTextColor(Theme.COLOR_TEXT_MAIN);
                    btnCancel.setBackground(makePressableGlass(act, Color.parseColor("#33FFFFFF"), Color.parseColor("#66FFFFFF"), Theme.COLOR_GLASS_BORDER, 50));
                    LinearLayout.LayoutParams lpCancel = new LinearLayout.LayoutParams(0, -2, 1.0f);
                    lpCancel.rightMargin = dp(act, 10);
                    btnCancel.setLayoutParams(lpCancel);
                    btnCancel.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { d.dismiss(); } });
                    btnLayout.addView(btnCancel);

                    TextView btnSave = new TextView(act);
                    btnSave.setText("保存");
                    btnSave.setTextSize(14);
                    btnSave.setTypeface(Typeface.DEFAULT_BOLD);
                    btnSave.setGravity(Gravity.CENTER);
                    btnSave.setPadding(0, dp(act, 12), 0, dp(act, 12));
                    btnSave.setTextColor(Color.WHITE);
                    btnSave.setBackground(makePressableGlass(act, Theme.COLOR_PRIMARY, Color.parseColor("#4D000000"), Theme.COLOR_GLASS_BORDER, 50));
                    LinearLayout.LayoutParams lpSave = new LinearLayout.LayoutParams(0, -2, 1.0f);
                    btnSave.setLayoutParams(lpSave);
                    
                    btnSave.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {
                            String finalName = et.getText().toString().trim();
                            if (finalName.equals("")) finalName = safeDefaultN;
                            
                            String currentDir = "";
                            if (!UIState.dirList.isEmpty() && UIState.currentDirIndex < UIState.dirList.size()) {
                                currentDir = (String) UIState.dirList.get(UIState.currentDirIndex);
                            } else { currentDir = getScriptPath() + "/yy"; }
                            
                            File dDir = new File(currentDir);
                            if (!dDir.exists()) dDir.mkdirs();
                            
                            String targetFile = currentDir + "/" + finalName + (safeIsSilk ? ".m4a" : safeDisplayExt);
                            String showName = dDir.getName();
                            if (showName.equals("yy")) showName = "默认目录";
                            
                            d.dismiss();

                            if (safeIsSilk) {
                                new Thread(new Runnable() {
                                    public void run() {
                                        boolean success = toAac(safeSrcPath, targetFile, 16000, 1);
                                        final boolean finalSuccess = success;
                                        if (act != null && !act.isFinishing()) {
                                            act.runOnUiThread(new Runnable() {
                                                public void run() {
                                                    if (finalSuccess) {
                                                        Toast("转码成功，已保存至: " + showName);
                                                    } else {
                                                        Toast("转码失败");
                                                    }
                                                }
                                            });
                                        }
                                    }
                                }).start();
                            } else {
                                if (copyFile(safeSrcPath, targetFile)) {
                                    Toast("已保存至: " + showName);
                                } else {
                                    Toast("保存失败");
                                }
                            }
                        }
                    });
                    btnLayout.addView(btnSave);

                    root.addView(btnLayout);
                    d.setContentView(root);
                    
                    Window win = d.getWindow();
                    win.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                    win.setLayout((int)(act.getResources().getDisplayMetrics().widthPixels * 0.85), ViewGroup.LayoutParams.WRAP_CONTENT);
                    d.show();
                } catch (Exception e) {}
            }
        });
        
    } catch (Exception e) {
        error("saveVoice异常: " + e);
    }
}
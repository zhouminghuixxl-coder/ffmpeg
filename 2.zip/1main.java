// ==========================================
// 文件：Main.java
// 极光聚合引擎 - 总入口
// ==========================================
import android.app.*;
import android.content.*;
import android.view.*;
import android.widget.*;
import android.graphics.*;
import android.graphics.drawable.*;
import org.json.JSONObject;
import java.util.regex.*;
import java.util.List;
import java.lang.reflect.Field;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;

load("Core.java");
load("UI.java");
load("Netease.java");
load("Dialogs.java");
load("Dashboard.java");
load("Update.java");
load("FFmpeg.java");
load("VisualRenderer.java");
load("EmoticonManager.java");
load("FaceConfig.java");
load("SmartPanel.java");
load("自定义外显.java");
load("VideoParser.java");

String UPDATE_URL = "https://sharechain.qq.com/b78730687c048bd3cc735934478934f6";

// 上次清理日志的时间戳（毫秒）
long lastCleanTime = 0;

// 判断文件是否为日志文件（包括 script_yyyy-MM-dd.log 格式）
boolean isLogFile(File file) {
    String name = file.getName();
    if (name.equals("plugin_log.txt") || name.equals("error.txt") || name.endsWith(".log")) {
        return true;
    }
    // 匹配 script_2026-04-02.log 格式
    if (name.matches("script_\\d{4}-\\d{2}-\\d{2}\\.log")) {
        return true;
    }
    return false;
}

// 从文件名中提取日期（用于 script_yyyy-MM-dd.log）
String getDateFromFileName(String name) {
    java.util.regex.Pattern p = java.util.regex.Pattern.compile("(\\d{4}-\\d{2}-\\d{2})");
    java.util.regex.Matcher m = p.matcher(name);
    if (m.find()) {
        return m.group(1);
    }
    return null;
}

// 删除单个日志文件（根据修改时间或文件名中的日期）
void deleteLogFile(File file) {
    try {
        String name = file.getName();
        if (!isLogFile(file)) return;

        long now = System.currentTimeMillis();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String today = sdf.format(new Date(now));
        
        // 优先根据文件名中的日期判断（针对 script_yyyy-MM-dd.log）
        String fileDate = getDateFromFileName(name);
        if (fileDate == null) {
            // 如果没有日期格式，则根据文件修改时间判断
            long lastModified = file.lastModified();
            fileDate = sdf.format(new Date(lastModified));
        }
        
        long sevenDaysAgo = now - 7 * 24 * 3600 * 1000L;
        
        // 如果文件日期不是今天，或者文件修改时间超过7天，则删除
        if (!fileDate.equals(today) || file.lastModified() < sevenDaysAgo) {
            if (file.delete()) {
                // 可选：记录删除日志，但为了避免日志膨胀，可以注释
                // log("[系统] 已删除日志文件: " + file.getAbsolutePath());
            }
        }
    } catch (Exception e) {
        // 静默失败
    }
}

// 递归遍历目录，清理日志文件
void cleanLogsRecursive(File dir) {
    if (dir == null || !dir.exists()) return;
    File[] files = dir.listFiles();
    if (files == null) return;
    for (int i = 0; i < files.length; i++) {
        File f = files[i];
        if (f.isDirectory()) {
            cleanLogsRecursive(f);
        } else {
            deleteLogFile(f);
        }
    }
}

// 清理非当天的日志文件（递归扫描所有子目录）
void cleanOldLogs() {
    try {
        String scriptDir = getScriptPath();
        File dir = new File(scriptDir);
        if (dir.exists()) {
            cleanLogsRecursive(dir);
        }
    } catch (Exception e) {
        // 静默失败
    }
}

// 按需清理日志（每隔 12 小时执行一次）
void cleanLogsIfNeeded() {
    long now = System.currentTimeMillis();
    if (lastCleanTime == 0 || (now - lastCleanTime) > 12 * 3600 * 1000L) {
        cleanOldLogs();
        lastCleanTime = now;
    }
}

void applyWindowMode(Dialog d, boolean isBall, int x, int y, Activity act) {
    Window win = d.getWindow();
    win.setBackgroundDrawable(new ColorDrawable(0));
    WindowManager.LayoutParams wlp = win.getAttributes();
    
    wlp.flags &= ~WindowManager.LayoutParams.FLAG_DIM_BEHIND;
    
    if (isBall) {
        win.setGravity(Gravity.TOP | Gravity.LEFT);
        wlp.x = x;
        wlp.y = y;
        wlp.width = -2;
        wlp.height = -2;
        wlp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
        wlp.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
    } else {
        win.setGravity(Gravity.CENTER);
        wlp.x = 0; wlp.y = 0;
        wlp.width = (int)(act.getResources().getDisplayMetrics().widthPixels * 0.95);
        wlp.height = -2;
        wlp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
        wlp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
    }
    win.setAttributes(wlp);
}

void showPanelDialog(Activity act) {
    if (act == null || act.isFinishing()) return;
    act.runOnUiThread(new Runnable() {
        public void run() {
            try {
                if (UIState.ballDialog != null) {
                    UIState.ballDialog.hide();
                }
                
                if (UIState.panelDialog != null) {
                    UIState.panelDialog.dismiss();
                    UIState.panelDialog = null;
                }
                
                Dialog d = new Dialog(act);
                d.requestWindowFeature(Window.FEATURE_NO_TITLE);
                UIState.panelDialog = d;
                
                View dashboard = createMainDashboard(act, d);
                d.setContentView(dashboard);
                applyWindowMode(d, false, 0, 0, act);
                
                d.setOnCancelListener(new DialogInterface.OnCancelListener() {
                    public void onCancel(DialogInterface dialog) {
                        AudioPlayer.stop();
                        if (UIState.ballDialog != null) UIState.ballDialog.show();
                    }
                });
                
                d.show();
            } catch (Exception e) {}
        }
    });
}

void showBall() {
    Activity act = getThreadActivity();
    if (act == null || act.isFinishing()) return;
    
    act.runOnUiThread(new Runnable() {
        public void run() {
            try {
                if (UIState.ballDialog != null) {
                    UIState.ballDialog.show();
                    return;
                }
                
                Dialog d = new Dialog(act);
                d.requestWindowFeature(Window.FEATURE_NO_TITLE);
                UIState.ballDialog = d;

                LinearLayout ball = new LinearLayout(act);
                ball.setGravity(Gravity.CENTER);
                
                int randomColor = getRandomSoftColor();
                GradientDrawable ballBg = makeGlassDrawable(act, randomColor, Theme.COLOR_GLASS_BORDER, 50);
                ball.setBackground(ballBg);
                ball.setPadding(dp(act, 8), dp(act, 8), dp(act, 8), dp(act, 8));
                
                TextView tvBall = new TextView(act);
                tvBall.setText("极光"); 
                tvBall.setTextSize(14);
                tvBall.setTextColor(Color.WHITE);
                tvBall.setShadowLayer(dp(act, 8), 0, 0, Color.WHITE);
                ball.addView(tvBall);

                ball.setOnTouchListener(new View.OnTouchListener() {
                    int lastX, lastY;
                    long downTime;
                    public boolean onTouch(View v, MotionEvent event) {
                        int action = event.getAction();
                        int rawX = (int) event.getRawX();
                        int rawY = (int) event.getRawY();

                        if (action == MotionEvent.ACTION_DOWN) {
                            lastX = rawX; lastY = rawY;
                            downTime = System.currentTimeMillis();
                            UIState.isDragging = false;
                            return true;
                        } else if (action == MotionEvent.ACTION_MOVE) {
                            int dx = rawX - lastX;
                            int dy = rawY - lastY;
                            if (Math.abs(dx) > 10 || Math.abs(dy) > 10) UIState.isDragging = true;
                            
                            if (UIState.isDragging) {
                                UIState.ballX += dx;
                                UIState.ballY += dy;
                                applyWindowMode(d, true, UIState.ballX, UIState.ballY, act);
                                lastX = rawX; lastY = rawY;
                            }
                            return true;
                        } else if (action == MotionEvent.ACTION_UP) {
                            if (!UIState.isDragging && (System.currentTimeMillis() - downTime < 200)) {
                                showPanelDialog(act);
                            }
                            return true;
                        }
                        return false;
                    }
                });

                d.setContentView(ball);
                applyWindowMode(d, true, UIState.ballX, UIState.ballY, act);
                d.show();
            } catch (Exception e) {}
        }
    });
}

void onChatChanged(boolean isAIO, String peerUin, String peerName, int chatType) {
    if (isAIO) {
        showBall();
        checkUpdate();
    } else {
        AudioPlayer.stop();
        cleanupDialogs();
    }
}

// 清理所有 Dialog，防止内存泄漏
void cleanupDialogs() {
    if (UIState.panelDialog != null && UIState.panelDialog.isShowing()) {
        try {
            UIState.panelDialog.dismiss();
        } catch (Exception e) {
            android.util.Log.e("Dialog", "关闭 panelDialog 失败", e);
        }
        UIState.panelDialog = null;
    }
    if (UIState.ballDialog != null && UIState.ballDialog.isShowing()) {
        try {
            UIState.ballDialog.dismiss();
        } catch (Exception e) {
            android.util.Log.e("Dialog", "关闭 ballDialog 失败", e);
        }
        UIState.ballDialog = null;
    }
}

void onMsg(Object msg) {
    // 长时间运行自动清理日志（每隔12小时）
    cleanLogsIfNeeded();
    
    boolean isMySent = false;
    try { isMySent = msg.MySent; } catch (Exception e) { return; }
    if (!isMySent) return;
    
    // 获取消息文本
    String text = getMsgText(msg);
    
    // 检查视频解析开关和链接
    boolean videoParseEnabled = getString("video_parse_enabled", "true").equals("true");
    boolean hasLink = false;
    if (videoParseEnabled && text != null && !text.isEmpty()) {
        Matcher m = urlPattern.matcher(text);
        if (m.find()) {
            hasLink = true;
            // 执行视频解析
            parseVideoIfNeeded(msg);
            // 如果执行了解析，则不再处理点歌
            return;
        }
    }
    
    // 如果没有视频解析或没有链接，则正常处理点歌
    if (text != null && text.startsWith("点歌 ")) {
        String keyword = text.substring(3).trim();
        if (keyword.length() > 0) {
            Toast("极光引擎响应自动点歌：" + keyword);
            new Thread(new Runnable() {
                public void run() {
                    try {
                        JSONObject object = new JSONObject();
                        object.put("s", keyword); object.put("type", 1); object.put("limit", 1);
                        String[] enc = weapiEncrypt(object.toString()); 
                        String body = "params=" + URLEncoder.encode(enc[0], "UTF-8") + "&encSecKey=" + URLEncoder.encode(enc[1], "UTF-8");
                        String resp = httpPost("https://music.163.com/weapi/cloudsearch/get/web?csrf_token=", body, GLOBAL_COOKIE);
                        ArrayList songs = parseSongs(resp);
                         if (songs.size() > 0) {
                             HashMap song = (HashMap) songs.get(0);
                             String path = getScriptPath() + "/temp_auto_play.mp3";
                             String musicUrl = getRealMusicUrl((String) song.get("id"));
                             if (downloadFile(musicUrl, path)) {
                                 // 获取当前发送模式
                                 String sendMode = getMusicSendMode();
                                 if (sendMode == null || sendMode.isEmpty()) {
                                     sendMode = "voice";
                                 }
                                 processNetEaseSend(path, sendMode, song);
                             } else {
                                 android.util.Log.e("AutoPlay", "下载音乐失败：" + musicUrl);
                             }
                         } else {
                             android.util.Log.e("AutoPlay", "未找到歌曲：" + keyword);
                         }
                    } catch (Exception e) {
                        android.util.Log.e("AutoPlay", "点歌异常", e);
                        Toast("点歌失败：" + e.getMessage());
                    }
                }
            }).start();
        }
    }
}

void onUnload() {
    AudioPlayer.stop();
    cleanupDialogs();
    File resized = new File(getScriptPath() + "/resized.jpg");
    if (resized.exists()) {
        resized.delete();
    }
}

new Thread(new Runnable() {
    public void run() {
        Activity act = null;
        for (int i = 0; i < 15; i++) {
            act = getThreadActivity();
            if (act != null) break;
            try { Thread.sleep(400); } catch (Exception e) {}
        }
        
        if (act != null && !act.isFinishing()) {
            act.runOnUiThread(new Runnable() {
                public void run() {
                    try { if (getContact() != null) showBall(); } catch (Exception e) {}
                }
            });
        }
        
        // 脚本启动时清理一次日志
        cleanOldLogs();
        lastCleanTime = System.currentTimeMillis();
        
        checkUpdate();
        String saved = getString("netease_cookie", "");
        if (saved != null && saved.length() > 10) {
            GLOBAL_COOKIE = saved; ensureUid();
        } else {
            if (performQQLogin()) setData("netease_cookie", GLOBAL_COOKIE);
        }
        
        if (UIState.dirList.isEmpty()) {
            try {
                File f = new File(getScriptPath() + "/audio_paths.config");
                if (f.exists()) {
                    BufferedReader br = new BufferedReader(new FileReader(f));
                    String line;
                    while ((line = br.readLine()) != null) {
                        if (line.trim().length() > 0) UIState.dirList.add(line.trim());
                    }
                    br.close();
                } else { UIState.dirList.add(getScriptPath() + "/yy"); }
            } catch (Exception e) {}
        }
    }
}).start();

addMsgItem("智能处理", "handleSmartMsg");

boolean isVoiceMessage(Object msgRecord) {
    try {
        Object elements = msgRecord.getClass().getField("elements").get(msgRecord);
        if (elements instanceof List) {
            List list = (List) elements;
            for (int i = 0; i < list.size(); i++) {
                Object element = list.get(i);
                if (element.getClass().getField("pttElement").get(element) != null) return true;
            }
        }
    } catch (Exception e) {} return false;
}

boolean isImageMessage(Object msgRecord) {
    try {
        Object elements = msgRecord.getClass().getField("elements").get(msgRecord);
        if (elements instanceof List) {
            List list = (List) elements;
            for (int i = 0; i < list.size(); i++) {
                Object element = list.get(i);
                if (element.getClass().getField("picElement").get(element) != null) return true;
            }
        }
    } catch (Exception e) {} return false;
}

boolean isTextMessage(Object msgRecord) {
    try {
        if (isVoiceMessage(msgRecord) || isImageMessage(msgRecord)) return false;
        Object elements = msgRecord.getClass().getField("elements").get(msgRecord);
        if (elements instanceof List) {
            List list = (List) elements;
            for (int i = 0; i < list.size(); i++) {
                Object element = list.get(i);
                if (element.getClass().getField("textElement").get(element) != null) return true;
            }
        }
    } catch (Exception e) {} return false;
}

boolean isVideoMessage(Object msgRecord) {
    try {
        Object elements = msgRecord.getClass().getField("elements").get(msgRecord);
        if (elements instanceof List) {
            List list = (List) elements;
            for (int i = 0; i < list.size(); i++) {
                Object element = list.get(i);
                if (element.getClass().getField("videoElement").get(element) != null) return true;
            }
        }
    } catch (Exception e) {} return false;
}

boolean isImageTextMessage(Object msgRecord) {
    boolean hasText = false;
    boolean hasImage = false;
    try {
        Object elements = msgRecord.getClass().getField("elements").get(msgRecord);
        if (elements instanceof List) {
            List list = (List) elements;
            for (int i = 0; i < list.size(); i++) {
                Object element = list.get(i);
                if (element.getClass().getField("textElement").get(element) != null) {
                    hasText = true;
                }
                if (element.getClass().getField("picElement").get(element) != null) {
                    hasImage = true;
                }
            }
        }
    } catch (Exception e) {}
    return hasText && hasImage;
}

void handleSmartMsg(Object msgRecord) {
    cleanTempFiles();
    if (isVoiceMessage(msgRecord)) {
        showVoiceActionPanel(msgRecord);
    } else if (isImageTextMessage(msgRecord)) {
        showImageTextActionPanel(msgRecord);
    } else if (isImageMessage(msgRecord)) {
        showImageActionPanel(msgRecord);
    } else if (isTextMessage(msgRecord)) {
        showTextActionPanel(msgRecord);
    } else if (isVideoMessage(msgRecord)) {
        showVideoActionPanel(msgRecord);
    } else {
        Toast("暂不支持处理该类型的消息");
    }
}

// ==========================================
// 【终极版】高清头像下载器 (实时更新，无痕不留垃圾)
// ==========================================
String downloadAvatar(String uin) {
    if (uin == null || uin.equals("")) return "";
    
    // 全局只用这一个固定文件，绝不产生多余的垃圾缓存
    String avatarPath = getScriptPath() + "/temp_avatar.png";
    File f = new File(avatarPath);
    
    // 【核心黑科技】：删掉原有的 exists 拦截！每次运行强制删除老图，确保接下来拉取的是实时最新图
    if (f.exists()) {
        f.delete();
    }

    try {
        // 请求腾讯官方高清头像接口
        URL url = new URL("http://q1.qlogo.cn/g?b=qq&nk=" + uin + "&s=640");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setConnectTimeout(5000);
        conn.setRequestMethod("GET");
        
        // 强制绕过网络缓存，每次必拉取最新头像
        conn.setRequestProperty("Cache-Control", "no-cache");
        
        if (conn.getResponseCode() == 200) {
            InputStream is = conn.getInputStream();
            FileOutputStream fos = new FileOutputStream(f);
            byte[] buf = new byte[8192];
            int len;
            while ((len = is.read(buf)) != -1) fos.write(buf, 0, len);
            fos.close(); is.close();
            return avatarPath;
        }
    } catch (Exception e) {} 
    
    return "";
}


void cleanTempFiles() {
    try {
        File dir = new File(getScriptPath());
        File[] files = dir.listFiles();
        if (files != null) {
            for (int i = 0; i < files.length; i++) {
                String name = files[i].getName();
                if ((name.startsWith("temp_") || name.endsWith(".srt") || name.endsWith(".wav")) 
                    && !name.startsWith("temp_avatar_")) {
                    files[i].delete();
                }
            }
        }
    } catch (Exception e) {}
}

// ==========================================
// 修改点：onSendMsg 返回值改为 boolean，并增加表情最大化处理
// ==========================================
boolean onSendMsg(Object contact, java.util.ArrayList msgElements) {
    // ========== 0. 检查是否需要将官方表情转换为大/小表情（根据图片模式） ==========
    String imageSizeMode = getString("image_size_mode", "0");
    // 当模式为“最小”(1)或“最大”(2)时处理官方表情
    if ("1".equals(imageSizeMode) || "2".equals(imageSizeMode)) {
        // 遍历消息元素，查找 marketFaceElement
        for (int i = 0; i < msgElements.size(); i++) {
            Object el = msgElements.get(i);
            try {
                // 尝试获取 marketFaceElement 字段（可能存在）
                Field marketField = el.getClass().getField("marketFaceElement");
                Object marketFace = marketField.get(el);
                if (marketFace != null) {
                    // 提取所需字段
                    String name = "";
                    String id = "";
                    String key = "";
                    try {
                        name = (String) marketFace.getClass().getField("faceName").get(marketFace);
                        id = (String) marketFace.getClass().getField("emojiId").get(marketFace);
                        key = (String) marketFace.getClass().getField("key").get(marketFace);
                    } catch (Exception e) {
                        // 字段不存在，跳过
                        continue;
                    }
                    if (name != null && id != null && key != null) {
                        // 根据模式构造不同的 JSON
                        String json = "";
                        if ("1".equals(imageSizeMode)) {
                            // 最小模式：修改 "11":1000 为 "11":100
                            json = "{\"6\":{\"1\":\"" + name + "\",\"2\":6,\"3\":1,\"4\":\"" + id + "\",\"5\":0,\"6\":3,\"7\":\"" + key + "\",\"8\":1,\"9\":0,\"10\":1000,\"11\":100}}";
                        } else {
                            // 最大模式：保持原样
                            json = "{\"6\":{\"1\":\"" + name + "\",\"2\":6,\"3\":1,\"4\":\"" + id + "\",\"5\":0,\"6\":3,\"7\":\"" + key + "\",\"8\":1,\"9\":0,\"10\":1000,\"11\":1000}}";
                        }
                        // 获取目标群号（contact 的 peerUid）
                        String peerUid = "";
                        try {
                            // 尝试通过反射获取 peerUid
                            Field peerField = findField(contact.getClass(), "peerUid");
                            if (peerField != null) {
                                peerField.setAccessible(true);
                                peerUid = (String) peerField.get(contact);
                            } else {
                                // 直接访问字段（如果存在）
                                peerUid = (String) contact.getClass().getField("peerUid").get(contact);
                            }
                        } catch (Exception e) {
                            // 获取失败，放弃处理
                        }
                        if (peerUid != null && !peerUid.isEmpty()) {
                            // 发送表情（sendPbMsgLong 是框架提供的全局方法）
                            boolean sent = sendPbMsgLong(json, peerUid);
                            if (sent) {
                                return true; // 拦截原消息
                            }
                        }
                    }
                }
            } catch (Exception e) {
                // 没有 marketFaceElement 字段，继续
            }
        }
    }

    // ========== 1. 图片尺寸缩放（最小/最大） ==========
    if (!imageSizeMode.equals("0")) {
        int targetSize = imageSizeMode.equals("1") ? 1 : 1080; // 最大设为1080（可调整）
        for (int i = 0; i < msgElements.size(); i++) {
            Object el = msgElements.get(i);
            try {
                Object picEl = el.getClass().getField("picElement").get(el);
                if (picEl == null) continue;
                
                // 获取原图路径（优先 thumbPath 中的 720）
                String srcPath = null;
                try {
                    Object thumbPathObj = picEl.getClass().getField("thumbPath").get(picEl);
                    if (thumbPathObj != null && thumbPathObj instanceof java.util.Map) {
                        java.util.Map thumbMap = (java.util.Map) thumbPathObj;
                        srcPath = (String) thumbMap.get("720");
                    }
                } catch (Exception e) {}
                if (srcPath == null) {
                    try {
                        srcPath = (String) picEl.getClass().getField("sourcePath").get(picEl);
                    } catch (Exception e) {}
                }
                if (srcPath == null) continue;
                
                File srcFile = new File(srcPath);
                if (!srcFile.exists()) continue;
                
                // 缩放图片到固定文件 resized.jpg
                String dstPath = getScriptPath() + "/resized.jpg";
                boolean success = resizeImage(srcPath, dstPath, targetSize, targetSize);
                if (!success) continue;
                
                File dstFile = new File(dstPath);
                if (!dstFile.exists()) continue;
                
                // 修改 picElement 字段指向新文件
                try {
                    Field sourcePathField = picEl.getClass().getField("sourcePath");
                    sourcePathField.set(picEl, dstPath);
                } catch (Exception e) {}
                try {
                    Field widthField = picEl.getClass().getField("picWidth");
                    widthField.set(picEl, targetSize);
                    Field heightField = picEl.getClass().getField("picHeight");
                    heightField.set(picEl, targetSize);
                } catch (Exception e) {}
                try {
                    Field sizeField = picEl.getClass().getField("fileSize");
                    sizeField.set(picEl, (int) dstFile.length());
                } catch (Exception e) {}
                // 设置 picType 和 picSubType（参考第三条消息）
                try {
                    Field typeField = picEl.getClass().getField("picType");
                    typeField.set(picEl, 1000);
                } catch (Exception e) {}
                try {
                    Field subTypeField = picEl.getClass().getField("picSubType");
                    subTypeField.set(picEl, 0);
                } catch (Exception e) {}
            } catch (Exception e) {
                error("图片缩放失败: " + e);
            }
        }
    }

    // ========== 2. 图片外显（修改文件名和摘要） ==========
    handleImageShow(msgElements);

    // ========== 3. 原有自动卡片逻辑 ==========
    if (getString("auto_quote_card", "false").equals("true")) {
        boolean hasMultimedia = false;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < msgElements.size(); i++) {
            Object el = msgElements.get(i);
            try {
                if (el.getClass().getField("picElement").get(el) != null) hasMultimedia = true;
                if (el.getClass().getField("pttElement").get(el) != null) hasMultimedia = true;
                if (el.getClass().getField("videoElement").get(el) != null) hasMultimedia = true;
                
                Object textEl = el.getClass().getField("textElement").get(el);
                if (textEl != null) {
                    Object content = textEl.getClass().getField("content").get(textEl);
                    if (content != null) sb.append(content.toString());
                }
            } catch (Exception e) {}
        }
        String text = sb.toString().trim();
        if (!hasMultimedia && text.length() > 0 && !text.startsWith("点歌")) {
            for (int i = 0; i < msgElements.size(); i++) {
                Object el = msgElements.get(i);
                try {
                    Object textEl = el.getClass().getField("textElement").get(el);
                    if (textEl != null) {
                        textEl.getClass().getField("content").set(textEl, "");
                    }
                } catch (Exception e) {}
            }
            Activity act = getThreadActivity();
            sendMyTextAsGlassCard(text, contact, act);
        }
    }

    // ========== 4. 如果外显开启，发送后延迟1秒更新文案 ==========
    if (getString("image_show_text", "false").equals("true")) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    Thread.sleep(1000);
                    fetchAndUpdate();  // 更新外显文案
                } catch (Exception e) {}
            }
        }).start();
    }

    return false; // 默认不拦截
}

// 递归查找字段（反射用）
Field findField(Class clazz, String fieldName) {
    try {
        return clazz.getDeclaredField(fieldName);
    } catch (NoSuchFieldException e) {
        Class superClass = clazz.getSuperclass();
        if (superClass != null && superClass != Object.class) {
            return findField(superClass, fieldName);
        }
        return null;
    }
}

// 缩放图片并保存为固定文件 resized.jpg
boolean resizeImage(String srcPath, String dstPath, int targetWidth, int targetHeight) {
    try {
        File dstFile = new File(dstPath);
        if (dstFile.exists()) {
            dstFile.delete();
        }
        
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(srcPath, opts);
        float srcW = opts.outWidth;
        float srcH = opts.outHeight;
        float scale = Math.max(targetWidth / srcW, targetHeight / srcH);
        
        if (targetWidth == 1 && targetHeight == 1) {
            scale = 1f / Math.min(srcW, srcH);
        }
        
        int newW = (int) (srcW * scale);
        int newH = (int) (srcH * scale);
        if (newW < 1) newW = 1;
        if (newH < 1) newH = 1;
        
        opts.inJustDecodeBounds = false;
        int sample = 1;
        while (srcW / sample > 2000 && srcH / sample > 2000) {
            sample *= 2;
        }
        opts.inSampleSize = sample;
        Bitmap srcBitmap = BitmapFactory.decodeFile(srcPath, opts);
        if (srcBitmap == null) return false;
        
        Bitmap scaledBitmap = Bitmap.createScaledBitmap(srcBitmap, newW, newH, true);
        srcBitmap.recycle();
        
        FileOutputStream fos = new FileOutputStream(dstPath);
        scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos);
        fos.close();
        scaledBitmap.recycle();
        
        return true;
    } catch (Exception e) {
        error("resizeImage error: " + e);
        return false;
    }
}

// 处理图片外显（修改 fileName 和 summary）
void handleImageShow(ArrayList msgElements) {
    String showEnabled = getString("image_show_text", "false");
    if (!showEnabled.equals("true")) return;
    
    // 从外显脚本获取当前文案（全局变量）
    String text = 当前外显;
    if (text == null || text.isEmpty()) return;
    
    for (int i = 0; i < msgElements.size(); i++) {
        Object el = msgElements.get(i);
        try {
            Object picEl = el.getClass().getField("picElement").get(el);
            if (picEl != null) {
                // 设置 fileName
                try {
                    Field fileNameField = findField(picEl.getClass(), "fileName");
                    if (fileNameField != null) {
                        fileNameField.setAccessible(true);
                        fileNameField.set(picEl, text);
                    }
                } catch (Exception e) {}
                // 设置 summary
                try {
                    Field summaryField = findField(picEl.getClass(), "summary");
                    if (summaryField != null) {
                        summaryField.setAccessible(true);
                        summaryField.set(picEl, text);
                    }
                } catch (Exception e) {}
            }
        } catch (Exception e) {}
    }
}
// ==========================================
// 文件：Update.java
// 版本公告检测模块
// ==========================================
import java.util.regex.*;

String[] parseAnnounce(String content) {
    String[] result = new String[]{"", ""};
    if (content == null || content.isEmpty()) return result;
    
    try {
        Pattern versionPattern = Pattern.compile("极光版本\\s*=\\s*『(.*?)』", Pattern.DOTALL);
        Matcher vm = versionPattern.matcher(content);
        if (vm.find()) {
            result[0] = vm.group(1).trim();
        }
        
        Pattern announcePattern = Pattern.compile("极光公告\\s*=\\s*『(.*?)』", Pattern.DOTALL);
        Matcher am = announcePattern.matcher(content);
        if (am.find()) {
            result[1] = am.group(1).trim();
        }
    } catch (Exception e) {
        // 静默失败，不输出错误日志
    }
    return result;
}

double getLocalVersionFromInfoProp() {
    try {
        String path = getScriptPath() + "/info.prop";
        File f = new File(path);
        if (!f.exists()) {
            // 不输出错误日志
            return 0.0;
        }
        BufferedReader br = new BufferedReader(new FileReader(f));
        String line;
        while ((line = br.readLine()) != null) {
            line = line.trim();
            if (line.startsWith("version=")) {
                String verStr = line.substring(8).trim();
                br.close();
                return Double.parseDouble(verStr);
            }
        }
        br.close();
    } catch (Exception e) {
        // 静默失败，不输出错误日志
    }
    return 0.0;
}

void showUpdateDialog(String version, String announceText) {
    Activity act = getThreadActivity();
    if (act == null || act.isFinishing()) return;

    act.runOnUiThread(new Runnable() {
        public void run() {
            try {
                Dialog d = new Dialog(act);
                d.requestWindowFeature(Window.FEATURE_NO_TITLE);
                d.getWindow().setBackgroundDrawable(new ColorDrawable(0));

                LinearLayout root = new LinearLayout(act);
                root.setOrientation(LinearLayout.VERTICAL);
                root.setBackground(makeAuroraBg(act, 20));
                root.setPadding(dp(act, 25), dp(act, 25), dp(act, 25), dp(act, 25));

                TextView title = new TextView(act);
                title.setText("发现新版本");
                title.setTextSize(18);
                title.setTypeface(Typeface.DEFAULT_BOLD);
                title.setTextColor(Theme.COLOR_TEXT_MAIN);
                title.setGravity(Gravity.CENTER);
                root.addView(title);

                TextView versionTv = new TextView(act);
                versionTv.setText("最新版本: v" + version);
                versionTv.setTextSize(14);
                versionTv.setTextColor(Theme.COLOR_PRIMARY);
                versionTv.setGravity(Gravity.CENTER);
                versionTv.setPadding(0, dp(act, 5), 0, dp(act, 15));
                root.addView(versionTv);

                ScrollView scroll = new ScrollView(act);
                scroll.setVerticalScrollBarEnabled(false);
                TextView msgTv = new TextView(act);
                if (announceText == null || announceText.isEmpty()) {
                    msgTv.setText("暂无更新说明");
                } else {
                    msgTv.setText(announceText);
                }
                msgTv.setTextSize(13);
                msgTv.setTextColor(Theme.COLOR_TEXT_SUB);
                msgTv.setLineSpacing(dp(act, 2), 1.0f);
                msgTv.setPadding(dp(act, 5), 0, dp(act, 5), 0);
                scroll.addView(msgTv);
                
                LinearLayout.LayoutParams lpScroll = new LinearLayout.LayoutParams(-1, dp(act, 200));
                lpScroll.bottomMargin = dp(act, 20);
                root.addView(scroll, lpScroll);

                TextView btnConfirm = new TextView(act);
                btnConfirm.setText("确定");
                btnConfirm.setTextSize(14);
                btnConfirm.setTypeface(Typeface.DEFAULT_BOLD);
                btnConfirm.setGravity(Gravity.CENTER);
                btnConfirm.setPadding(0, dp(act, 12), 0, dp(act, 12));
                btnConfirm.setTextColor(Color.WHITE);
                btnConfirm.setBackground(makePressableGlass(act, Theme.COLOR_PRIMARY, Color.parseColor("#4D000000"), Theme.COLOR_GLASS_BORDER, 50));
                btnConfirm.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
                btnConfirm.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        d.dismiss();
                    }
                });
                root.addView(btnConfirm);

                d.setContentView(root);
                d.getWindow().setLayout((int)(act.getResources().getDisplayMetrics().widthPixels * 0.85), -2);
                d.show();
            } catch (Exception e) {}
        }
    });
}

void checkUpdate() {
    new Thread(new Runnable() {
        public void run() {
            try {
                String content = httpGet(UPDATE_URL);
                if (content == null || content.isEmpty()) return;
                
                String[] parsed = parseAnnounce(content);
                String cloudVersionStr = parsed[0];
                String announceText = parsed[1];
                
                if (cloudVersionStr.isEmpty()) return;
                
                double cloudVersion = Double.parseDouble(cloudVersionStr);
                double localVersion = getLocalVersionFromInfoProp();
                if (localVersion == 0.0) {
                    // 静默跳过，不输出错误日志
                    return;
                }
                if (cloudVersion > localVersion) {
                    showUpdateDialog(cloudVersionStr, announceText);
                }
            } catch (Exception e) {
                // 静默失败，不输出错误日志
            }
        }
    }).start();
}